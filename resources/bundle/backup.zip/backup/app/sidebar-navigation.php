<!-- Sidebar navigation-->
<nav class="sidebar-nav">
                    <ul id="sidebarnav">
                         <li class="nav-devider"></li>
                        <?php include_once 'menu.generate.php'?>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->