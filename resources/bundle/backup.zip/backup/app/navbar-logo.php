<!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">
                        <!-- Logo icon --><b>
                            <!-- You can put here icon as well -->
                            <i class="mdi mdi-desktop-mac dark-logo"></i>
                            <i class="mdi mdi-desktop-mac light-logo"></i>
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                         <!-- dark Logo text -->
                         <img src="<?php echo Core::getInstance()->assetspath?>/images/logo-text.png" class="dark-logo" alt="<?php echo Core::getInstance()->title?>" />
                         <!-- Light Logo text -->    
                         <img src="<?php echo Core::getInstance()->assetspath?>/images/logo-light-text.png" class="light-logo" alt="<?php echo Core::getInstance()->title?>" /></span> </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->