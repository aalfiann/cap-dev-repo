<?php 
            //Configurations
            $config['title'] = 'CAP Express'; //Your title website
            $config['keyword'] = 'CAP Express, Logistics, Blog, Transport, Corporate, Cargo, Truck, Jasa Pengiriman, Pengiriman Barang Murah, Ekspedisi'; //Your keyword website
            $config['description'] = 'CAP Express adalah jasa pengiriman barang murah yang handal dan terpercaya.'; //Your description website
            $config['email'] = 'cs@cap-express.co.id'; //Your default email
            $config['basepath'] = 'https://cap-express.co.id/app'; //Your folder website
            $config['homepath'] = 'https://cap-express.co.id/app'; //Your folder frontend website
            $config['assetspath'] = 'https://cdn.jsdelivr.net/gh/aalfiann/cap-dev-repo@master/website/app/assets'; //Your folder assets website
            $config['fixedpath'] = ''; //Your path of main rest api, this is required only if you are running multiple reSlim rest api
            $config['api'] = 'https://global.cap-express.co.id/api'; //Your path of rest api
            $config['apikey'] = 'bjOR28f04qug9anJ6b4YCJcgFDzKNN7uhoDDr2dslpXMEeBzRQtuyT2zrqtkAk'; //Your api key, you can leave this blank and fill this later
            $config['disqus'] = 'cap-express'; //Your disqus username, you can leave this blank and fill this later
            $config['sharethis'] = '598da1b6ea00a30012ce67a0'; //Your sharethis key, you can leave this blank and fill this later
            $config['facebook'] = ''; //Your facebook page, you can leave this blank and fill this later
            $config['twitter'] = ''; //Your twitter page, you can leave this blank and fill this later
            $config['gplus'] = ''; //Your google plus page, you can leave this blank and fill this later
            $config['gpub'] = ''; //Your google publisher page, you can leave this blank and fill this later
            $config['googleanalytics'] = 'UA-115447110-1'; //Your google analytics, you can leave this blank and fill this later
            $config['googlewebmaster'] = 'yMEiLbpEuZ7T9X6S8pEESMS3lxxaOEXyt82wslsSgu0'; //Your google webmaster, you can leave this blank and fill this later
            $config['bingwebmaster'] = 'E07263D1C1A592703787713EF54A2DA2'; //Your bing webmaster, you can leave this blank and fill this later
            $config['yandexwebmaster'] = ''; //Your yandex webmaster, you can leave this blank and fill this later
            $config['seopage'] = ''; //Keyword for dynamic page, you can leave this blank and fill this later
            $config['seosite'] = ''; //Keyword for competitor site, you can leave this blank and fill this later
            $config['recaptcha_sitekey'] = '6LcmlmcUAAAAAPe0GLorOqEQi3VMkIonkwITDN5g'; //This is for get response reCaptcha on html, you can leave this blank and fill this later
            $config['recaptcha_secretkey'] = '6LcmlmcUAAAAAJbxVKr8G8yoPOK_IK-p5pD8RA64'; //This is for verify request reCaptcha on server side, you can leave this blank and fill this later