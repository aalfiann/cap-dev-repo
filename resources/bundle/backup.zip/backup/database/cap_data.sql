/*
Navicat MariaDB Data Transfer

Source Server         : CAP-EXPRESS
Source Server Version : 100131
Source Host           : server.cap-express.co.id:3306
Source Database       : cap_data

Target Server Type    : MariaDB
Target Server Version : 100131
File Encoding         : 65001

Date: 2019-01-14 03:12:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for agent_config
-- ----------------------------
DROP TABLE IF EXISTS `agent_config`;
CREATE TABLE `agent_config` (
  `KeyID` varchar(50) NOT NULL,
  `Config` text,
  `Description` varchar(255) DEFAULT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Created_by` varchar(50) DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`KeyID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_config
-- ----------------------------

-- ----------------------------
-- Table structure for agent_log_data
-- ----------------------------
DROP TABLE IF EXISTS `agent_log_data`;
CREATE TABLE `agent_log_data` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_log_data
-- ----------------------------

-- ----------------------------
-- Table structure for agent_transaction_waybill
-- ----------------------------
DROP TABLE IF EXISTS `agent_transaction_waybill`;
CREATE TABLE `agent_transaction_waybill` (
  `Waybill` varchar(20) NOT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Consignor_name` varchar(50) NOT NULL,
  `Consignor_alias` varchar(50) DEFAULT NULL,
  `Consignor_address` varchar(255) NOT NULL,
  `Consignor_phone` varchar(15) NOT NULL,
  `Consignor_fax` varchar(15) DEFAULT NULL,
  `Consignor_email` varchar(50) DEFAULT NULL,
  `ReferenceID` varchar(20) DEFAULT NULL,
  `Consignee_name` varchar(50) NOT NULL,
  `Consignee_attention` varchar(50) DEFAULT NULL,
  `Consignee_address` varchar(255) NOT NULL,
  `Consignee_phone` varchar(15) NOT NULL,
  `Consignee_fax` varchar(15) DEFAULT NULL,
  `Mode` varchar(50) NOT NULL,
  `Instruction` varchar(255) DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Goods_data` varchar(1000) NOT NULL,
  `Goods_koli` decimal(5,0) NOT NULL,
  `Goods_value` decimal(10,0) NOT NULL,
  `Weight` decimal(7,2) NOT NULL,
  `Weight_real` decimal(7,2) NOT NULL,
  `Origin` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Estimation` varchar(7) NOT NULL,
  `Insurance_rate` decimal(7,2) NOT NULL,
  `Shipping_cost` decimal(10,0) NOT NULL,
  `Shipping_insurance` decimal(10,0) NOT NULL,
  `Shipping_packing` decimal(10,0) NOT NULL,
  `Shipping_forward` decimal(10,0) NOT NULL,
  `Shipping_handling` decimal(10,0) NOT NULL,
  `Shipping_surcharge` decimal(10,0) NOT NULL,
  `Shipping_admin` decimal(10,0) NOT NULL,
  `Shipping_discount` decimal(10,0) NOT NULL,
  `Shipping_cost_total` decimal(10,0) NOT NULL,
  `Payment` varchar(50) NOT NULL,
  `Signature` varchar(50) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Company_logo` varchar(255) DEFAULT NULL,
  `Company_name` varchar(50) DEFAULT NULL,
  `Company_address` varchar(255) DEFAULT NULL,
  `Company_phone` varchar(15) DEFAULT NULL,
  `Company_fax` varchar(15) DEFAULT NULL,
  `Company_email` varchar(50) DEFAULT NULL,
  `Company_TIN` varchar(50) DEFAULT NULL,
  `Recipient` varchar(50) DEFAULT NULL,
  `Relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Waybill`),
  KEY `Waybill` (`Waybill`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Consignor_name` (`Consignor_name`),
  KEY `Consignor_phone` (`Consignor_phone`),
  KEY `ReferenceID` (`ReferenceID`),
  KEY `Consignee_name` (`Consignee_name`),
  KEY `Consignee_phone` (`Consignee_phone`),
  KEY `Destination` (`Destination`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Mode` (`Mode`),
  KEY `Payment` (`Payment`),
  KEY `Signature` (`Signature`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_transaction_waybill
-- ----------------------------

-- ----------------------------
-- Table structure for core_status
-- ----------------------------
DROP TABLE IF EXISTS `core_status`;
CREATE TABLE `core_status` (
  `StatusID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` varchar(255) NOT NULL,
  PRIMARY KEY (`StatusID`),
  KEY `StatusID` (`StatusID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of core_status
-- ----------------------------
INSERT INTO `core_status` VALUES ('1', 'active');
INSERT INTO `core_status` VALUES ('2', 'allocated');
INSERT INTO `core_status` VALUES ('3', 'approved');
INSERT INTO `core_status` VALUES ('4', 'authorized');
INSERT INTO `core_status` VALUES ('5', 'banned');
INSERT INTO `core_status` VALUES ('6', 'blank');
INSERT INTO `core_status` VALUES ('7', 'canceled');
INSERT INTO `core_status` VALUES ('8', 'checked');
INSERT INTO `core_status` VALUES ('9', 'closed');
INSERT INTO `core_status` VALUES ('10', 'commented');
INSERT INTO `core_status` VALUES ('11', 'compared');
INSERT INTO `core_status` VALUES ('12', 'deleted');
INSERT INTO `core_status` VALUES ('13', 'disabled');
INSERT INTO `core_status` VALUES ('14', 'downloaded');
INSERT INTO `core_status` VALUES ('15', 'edited');
INSERT INTO `core_status` VALUES ('16', 'enabled');
INSERT INTO `core_status` VALUES ('17', 'error');
INSERT INTO `core_status` VALUES ('18', 'expired');
INSERT INTO `core_status` VALUES ('19', 'failed');
INSERT INTO `core_status` VALUES ('20', 'hidden');
INSERT INTO `core_status` VALUES ('21', 'installed');
INSERT INTO `core_status` VALUES ('22', 'listed');
INSERT INTO `core_status` VALUES ('23', 'locked');
INSERT INTO `core_status` VALUES ('24', 'maintenance');
INSERT INTO `core_status` VALUES ('25', 'merged');
INSERT INTO `core_status` VALUES ('26', 'moved');
INSERT INTO `core_status` VALUES ('27', 'ok');
INSERT INTO `core_status` VALUES ('28', 'on hold');
INSERT INTO `core_status` VALUES ('29', 'on process');
INSERT INTO `core_status` VALUES ('30', 'on request');
INSERT INTO `core_status` VALUES ('31', 'open');
INSERT INTO `core_status` VALUES ('32', 'outstanding');
INSERT INTO `core_status` VALUES ('33', 'overdue');
INSERT INTO `core_status` VALUES ('34', 'paid');
INSERT INTO `core_status` VALUES ('35', 'pending');
INSERT INTO `core_status` VALUES ('36', 'registered');
INSERT INTO `core_status` VALUES ('37', 'rejected');
INSERT INTO `core_status` VALUES ('38', 'removed');
INSERT INTO `core_status` VALUES ('39', 'signed');
INSERT INTO `core_status` VALUES ('40', 'stopped');
INSERT INTO `core_status` VALUES ('41', 'success');
INSERT INTO `core_status` VALUES ('42', 'suspended');
INSERT INTO `core_status` VALUES ('43', 'unauthorized');
INSERT INTO `core_status` VALUES ('44', 'unknown');
INSERT INTO `core_status` VALUES ('45', 'uploaded');
INSERT INTO `core_status` VALUES ('46', 'viewed');
INSERT INTO `core_status` VALUES ('47', 'void');
INSERT INTO `core_status` VALUES ('48', 'waiting');
INSERT INTO `core_status` VALUES ('49', 'public');
INSERT INTO `core_status` VALUES ('50', 'private');
INSERT INTO `core_status` VALUES ('51', 'publish');
INSERT INTO `core_status` VALUES ('52', 'draft');
INSERT INTO `core_status` VALUES ('53', 'return');

-- ----------------------------
-- Table structure for customer_company
-- ----------------------------
DROP TABLE IF EXISTS `customer_company`;
CREATE TABLE `customer_company` (
  `BranchID` varchar(10) NOT NULL,
  `CompanyID` varchar(20) NOT NULL,
  `Company_name` varchar(50) NOT NULL,
  `Company_name_alias` varchar(50) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `PIC` varchar(50) NOT NULL,
  `TIN` varchar(50) DEFAULT NULL,
  `Discount` decimal(7,2) NOT NULL,
  `Tax` decimal(7,2) NOT NULL,
  `Admin_cost` decimal(10,2) NOT NULL,
  `IndustryID` int(11) NOT NULL,
  `SalesID` varchar(20) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CompanyID`),
  KEY `BranchID` (`BranchID`),
  KEY `IndustryID` (`IndustryID`),
  KEY `StatusID` (`StatusID`),
  KEY `SalesID` (`SalesID`),
  KEY `Name` (`CompanyID`,`Company_name`,`Company_name_alias`) USING BTREE,
  KEY `Created_by` (`Created_by`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_company
-- ----------------------------
INSERT INTO `customer_company` VALUES ('cgk', 'CC0430992879', 'PT. Trans Retail Indonesia', 'Carrefour', 'Jl. Lebak Bulus No. 08\nJakarta Selatan', '02127585800', '', '', 'MBA YULI', '', '0.00', '0.00', '0.00', '12', '', '1', '2018-10-06 15:59:04', 'rendi', '2018-12-03 05:40:05', 'aziz');

-- ----------------------------
-- Table structure for customer_mas_industry
-- ----------------------------
DROP TABLE IF EXISTS `customer_mas_industry`;
CREATE TABLE `customer_mas_industry` (
  `IndustryID` int(11) NOT NULL AUTO_INCREMENT,
  `Industry` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IndustryID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_mas_industry
-- ----------------------------
INSERT INTO `customer_mas_industry` VALUES ('1', 'Others');
INSERT INTO `customer_mas_industry` VALUES ('2', 'Banking');
INSERT INTO `customer_mas_industry` VALUES ('3', 'Insurance');
INSERT INTO `customer_mas_industry` VALUES ('4', 'Logistics');
INSERT INTO `customer_mas_industry` VALUES ('5', 'Entertainment');
INSERT INTO `customer_mas_industry` VALUES ('6', 'Hospital / Health Care');
INSERT INTO `customer_mas_industry` VALUES ('7', 'Advertising');
INSERT INTO `customer_mas_industry` VALUES ('8', 'Automotive');
INSERT INTO `customer_mas_industry` VALUES ('9', 'Publishing');
INSERT INTO `customer_mas_industry` VALUES ('10', 'Outsourcing');
INSERT INTO `customer_mas_industry` VALUES ('11', 'Transportation');
INSERT INTO `customer_mas_industry` VALUES ('12', 'Retail');
INSERT INTO `customer_mas_industry` VALUES ('13', 'Goverment');
INSERT INTO `customer_mas_industry` VALUES ('14', 'Manufacturing');
INSERT INTO `customer_mas_industry` VALUES ('15', 'Chemical / Pharmacy');
INSERT INTO `customer_mas_industry` VALUES ('16', 'Food and Beverages');
INSERT INTO `customer_mas_industry` VALUES ('17', 'Financial Institutions');
INSERT INTO `customer_mas_industry` VALUES ('18', 'General Trading');
INSERT INTO `customer_mas_industry` VALUES ('19', 'Consultant');
INSERT INTO `customer_mas_industry` VALUES ('20', 'Electronic');
INSERT INTO `customer_mas_industry` VALUES ('21', 'Aviation / Airlines');
INSERT INTO `customer_mas_industry` VALUES ('22', 'Business Supplies');
INSERT INTO `customer_mas_industry` VALUES ('23', 'Package / Courier / Delivery');
INSERT INTO `customer_mas_industry` VALUES ('24', 'Political Organization');
INSERT INTO `customer_mas_industry` VALUES ('25', 'Venture Capital');

-- ----------------------------
-- Table structure for customer_member
-- ----------------------------
DROP TABLE IF EXISTS `customer_member`;
CREATE TABLE `customer_member` (
  `BranchID` varchar(10) NOT NULL,
  `MemberID` varchar(20) NOT NULL,
  `Member_name` varchar(50) NOT NULL,
  `Member_name_alias` varchar(50) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Discount` decimal(7,2) NOT NULL,
  `Admin_cost` decimal(10,2) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MemberID`),
  KEY `BranchID` (`BranchID`),
  KEY `Name` (`MemberID`,`Member_name`,`Member_name_alias`),
  KEY `StatusID` (`StatusID`),
  KEY `Phone` (`Phone`),
  KEY `Created_by` (`Created_by`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_member
-- ----------------------------

-- ----------------------------
-- Table structure for data_bank
-- ----------------------------
DROP TABLE IF EXISTS `data_bank`;
CREATE TABLE `data_bank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Bank_name` varchar(50) NOT NULL,
  `Bank_fullname` varchar(50) DEFAULT NULL,
  `Account_name` varchar(50) NOT NULL,
  `Account_no` varchar(20) NOT NULL,
  `Bank_address` varchar(253) DEFAULT NULL,
  `Custom_id` varchar(255) DEFAULT NULL,
  `Custom_field` text,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Custom_id` (`Custom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of data_bank
-- ----------------------------
INSERT INTO `data_bank` VALUES ('1', 'Mandiri', 'Bank Mandiri', 'PT, CIPTA AMANAH PERSADA', '124-0007406029', 'Jl. Lapangan Ros Tebet Jakarta Selatan', '{\"BranchID\":\"cgk\"}', '', '2018-11-24 13:17:38', 'ajimulia', null, null, '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for data_page
-- ----------------------------
DROP TABLE IF EXISTS `data_page`;
CREATE TABLE `data_page` (
  `PageID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Content` text NOT NULL,
  `Tags` varchar(500) DEFAULT NULL,
  `Viewer` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Last_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PageID`),
  KEY `PageID` (`PageID`),
  KEY `Title` (`Title`),
  KEY `Tags` (`Tags`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `Created_at` (`Created_at`),
  CONSTRAINT `data_page_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `data_page_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of data_page
-- ----------------------------

-- ----------------------------
-- Table structure for deposit_balance
-- ----------------------------
DROP TABLE IF EXISTS `deposit_balance`;
CREATE TABLE `deposit_balance` (
  `DepositID` varchar(50) NOT NULL,
  `Balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`DepositID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_balance
-- ----------------------------

-- ----------------------------
-- Table structure for deposit_history
-- ----------------------------
DROP TABLE IF EXISTS `deposit_history`;
CREATE TABLE `deposit_history` (
  `ReferenceID` varchar(50) NOT NULL,
  `Balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ReferenceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_history
-- ----------------------------

-- ----------------------------
-- Table structure for deposit_mutation
-- ----------------------------
DROP TABLE IF EXISTS `deposit_mutation`;
CREATE TABLE `deposit_mutation` (
  `DepositID` varchar(50) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `ReferenceID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Task` varchar(2) NOT NULL,
  `Mutation` decimal(10,2) NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`ReferenceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_mutation
-- ----------------------------

-- ----------------------------
-- Table structure for imagehoster_data
-- ----------------------------
DROP TABLE IF EXISTS `imagehoster_data`;
CREATE TABLE `imagehoster_data` (
  `ID` varchar(20) NOT NULL,
  `ClientID` varchar(20) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Link` varchar(255) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Size` double DEFAULT NULL,
  `Width` double DEFAULT NULL,
  `Height` double DEFAULT NULL,
  `Data` text NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`,`ClientID`),
  KEY `Title` (`Title`) USING BTREE,
  KEY `Created_by` (`Created_by`),
  KEY `Created_at` (`Created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of imagehoster_data
-- ----------------------------
INSERT INTO `imagehoster_data` VALUES ('w7tpV6F', '', 'Transformer', 'https://i.imgur.com/w7tpV6F.jpg', 'image/jpeg', '182827', '825', '464', '{\"id\":\"w7tpV6F\",\"title\":\"Transformer\",\"description\":null,\"datetime\":1542303815,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":825,\"height\":464,\"size\":182827,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"NgggpdNuKYaxiJy\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/w7tpV6F.jpg\"}', '2018-11-16 00:39:57', 'aziz', null, null, null);

-- ----------------------------
-- Table structure for invoice_data
-- ----------------------------
DROP TABLE IF EXISTS `invoice_data`;
CREATE TABLE `invoice_data` (
  `InvoiceID` varchar(20) NOT NULL,
  `From_name` varchar(50) NOT NULL,
  `From_name_company` varchar(50) DEFAULT NULL,
  `From_address` varchar(255) NOT NULL,
  `From_phone` varchar(15) NOT NULL,
  `From_fax` varchar(15) DEFAULT NULL,
  `From_email` varchar(50) DEFAULT NULL,
  `From_website` varchar(50) DEFAULT NULL,
  `To_name` varchar(50) NOT NULL,
  `To_name_company` varchar(50) DEFAULT NULL,
  `To_address` varchar(255) NOT NULL,
  `To_phone` varchar(15) NOT NULL,
  `To_fax` varchar(15) DEFAULT NULL,
  `To_email` varchar(50) DEFAULT NULL,
  `To_website` varchar(50) DEFAULT NULL,
  `Custom_id` varchar(1000) DEFAULT NULL,
  `Custom_field` text,
  `Data_table` text NOT NULL,
  `Total_sub` decimal(20,2) NOT NULL,
  `Total` decimal(20,2) NOT NULL,
  `Term` int(11) NOT NULL,
  `Signature` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`InvoiceID`),
  KEY `From` (`From_name`,`From_name_company`),
  KEY `To` (`To_name`,`To_name_company`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Custom_id` (`Custom_id`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of invoice_data
-- ----------------------------
INSERT INTO `invoice_data` VALUES ('CGK201811240001', 'Aji Mulia', 'CAP Express', 'Jl. Manggarai Utara VIII F2B No.8 Rt.8 Rw.1\nTebet Jakarta Selatan', '0218290569', '', 'cs@cap-express.co.id', 'cap-express.co.id', 'MBA YULI', 'PT. Trans Retail Indonesia', 'Jl. Lebak Bulus No. 08\nJakarta Selatan', '02127585800', '', '', '', '{\"BranchID\":\"CGK\",\"CustomerID\":\"CC0430992879\"}', '{\"Tax_rate\":\"0\",\"Tax_total\":\"0.00\",\"Bank_name\":\"Mandiri\",\"Bank_account_name\":\"PT, CIPTA AMANAH PERSADA\",\"Bank_account_no\":\"124-0007406029\",\"Bank_address\":\"Jl. Lapangan Ros Tebet Jakarta Selatan\"}', '[{\"date\":\"2018-11-24\",\"po\":\"12345\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-24\",\"po\":\"4567\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"},{\"date\":\"2018-11-25\",\"po\":\"4554\",\"desc\":\"Pengiriman barang ke daerah\",\"qty\":\"1\",\"amount\":\"1000000\",\"total\":\"1000000\"}]', '16000000.00', '16000000.00', '14', 'Aji Mulia', '35', '2018-11-24 13:20:54', 'ajimulia', '2018-12-03 05:41:34', 'aziz', '2018-12-03 05:41:34');

-- ----------------------------
-- Table structure for log_data
-- ----------------------------
DROP TABLE IF EXISTS `log_data`;
CREATE TABLE `log_data` (
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Username` varchar(50) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data
-- ----------------------------
INSERT INTO `log_data` VALUES ('CGK2323263470', 'Menunggu proses pengiriman', '2018-04-27 14:21:29', 'aziz', '29', '1');
INSERT INTO `log_data` VALUES ('CGK3801370267', 'Menunggu proses pengiriman', '2018-05-05 13:48:28', 'aziz', '29', '2');
INSERT INTO `log_data` VALUES ('CGK3801370267', 'Barang telah diterima oleh: A (ADIK)', '2018-05-05 14:06:07', 'aziz', '41', '3');
INSERT INTO `log_data` VALUES ('CGK3270004421', 'Menunggu proses pengiriman', '2018-05-05 14:26:32', 'aziz', '29', '4');
INSERT INTO `log_data` VALUES ('CGK3623349554', 'Menunggu proses pengiriman', '2018-07-14 14:58:46', 'ayu', '29', '5');
INSERT INTO `log_data` VALUES ('CGK3623349554', 'Alamat tidak ketemu', '2018-07-14 15:06:07', 'ayu', '19', '6');
INSERT INTO `log_data` VALUES ('CGK3713886250', 'Menunggu proses pengiriman', '2018-07-14 15:35:06', 'ayu', '29', '7');
INSERT INTO `log_data` VALUES ('CGK0417320688', 'Menunggu proses pengiriman', '2018-07-21 16:35:27', 'rendi', '29', '8');
INSERT INTO `log_data` VALUES ('CGK0417320688', 'Barang telah diterima oleh: DESI (YBS)', '2018-07-21 16:51:48', 'rendi', '41', '9');
INSERT INTO `log_data` VALUES ('CGK1833951474', 'Menunggu proses pengiriman', '2018-08-11 15:02:51', 'ayu', '29', '10');
INSERT INTO `log_data` VALUES ('CGK1833951474', 'Barang telah diterima oleh: IQBAL (YBS)', '2018-08-11 15:07:39', 'ayu', '41', '11');
INSERT INTO `log_data` VALUES ('CGK1753904148', 'Menunggu proses pengiriman', '2018-08-28 14:50:06', 'bunga', '29', '12');
INSERT INTO `log_data` VALUES ('SUB2283909274', 'Menunggu proses pengiriman', '2018-09-05 15:22:46', 'massub', '29', '13');
INSERT INTO `log_data` VALUES ('CGK1753904148', 'Barang telah diterima oleh: PARAF (SAUDARA)', '2018-09-08 13:54:03', 'ayu', '41', '14');
INSERT INTO `log_data` VALUES ('CGK3987933966', 'Menunggu proses pengiriman', '2018-09-14 13:11:02', 'ayu', '29', '15');
INSERT INTO `log_data` VALUES ('CGK3215887398', 'Menunggu proses pengiriman', '2018-09-14 15:49:24', 'ayu', '29', '16');
INSERT INTO `log_data` VALUES ('CGK1239657810', 'Menunggu proses pengiriman', '2018-09-18 15:18:00', 'ayu', '29', '17');
INSERT INTO `log_data` VALUES ('CGK3215887398', 'Barang telah diterima oleh: KANAPI (STAFF)', '2018-09-21 11:14:03', 'ayu', '41', '18');
INSERT INTO `log_data` VALUES ('CGK1239657810', 'Barang telah diterima oleh: ADE R (YBS)', '2018-09-21 11:19:31', 'ayu', '41', '19');
INSERT INTO `log_data` VALUES ('CGK1339890841', 'Menunggu proses pengiriman', '2018-09-25 16:52:27', 'ayu', '29', '20');
INSERT INTO `log_data` VALUES ('CGK2346061885', 'Menunggu proses pengiriman', '2018-09-25 16:57:34', 'ayu', '29', '21');
INSERT INTO `log_data` VALUES ('CGK1619763389', 'Menunggu proses pengiriman', '2018-09-26 09:53:04', 'ayu', '29', '22');
INSERT INTO `log_data` VALUES ('CGK2346061885', 'Barang telah diterima oleh: YUDI IRAWAN (STAFF)', '2018-09-29 10:34:51', 'ayu', '41', '23');
INSERT INTO `log_data` VALUES ('CGK1619763389', 'Barang telah diterima oleh: RAFI (YBS)', '2018-10-01 14:31:07', 'ayu', '41', '24');
INSERT INTO `log_data` VALUES ('CGK1339890841', 'Barang telah diterima oleh: IBU RIA (YBS)', '2018-10-01 14:32:03', 'ayu', '41', '25');
INSERT INTO `log_data` VALUES ('CGK4120392791', 'Menunggu proses pengiriman', '2018-11-27 11:39:07', 'ayu', '29', '26');
INSERT INTO `log_data` VALUES ('CGK4120392791', 'Barang telah diterima oleh: PARAF (STAFF)', '2018-12-07 10:27:12', 'ayu', '41', '27');
INSERT INTO `log_data` VALUES ('CGK2505850410', 'Menunggu proses pengiriman', '2019-01-05 10:13:55', 'bunga', '29', '28');
INSERT INTO `log_data` VALUES ('CGK1009830033', 'Menunggu proses pengiriman', '2019-01-05 12:57:36', 'ayu', '29', '29');
INSERT INTO `log_data` VALUES ('CGK1009830033', 'Barang telah diterima oleh: MS. DESY HEC 2 OFFICE (STAFF)', '2019-01-10 14:59:18', 'bunga', '41', '30');
INSERT INTO `log_data` VALUES ('CGK2505850410', 'Barang telah diterima oleh: ENCANG (SAUDARA)', '2019-01-10 15:00:16', 'bunga', '41', '31');

-- ----------------------------
-- Table structure for log_data_pod
-- ----------------------------
DROP TABLE IF EXISTS `log_data_pod`;
CREATE TABLE `log_data_pod` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `BranchID` varchar(10) DEFAULT NULL,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `WayBill` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Recipient` varchar(50) DEFAULT NULL,
  `Relation` varchar(255) DEFAULT NULL,
  `DeliveryID` varchar(15) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `ItemID` (`ItemID`),
  KEY `WayBill` (`WayBill`) USING BTREE,
  KEY `BranchID` (`BranchID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_pod
-- ----------------------------
INSERT INTO `log_data_pod` VALUES ('1', 'cgk', '2018-05-05 14:06:07', 'CGK3801370267', 'Barang telah diterima oleh:', 'A', 'ADIK', 'CGK3801370267', '41', 'aziz', null, null, null);
INSERT INTO `log_data_pod` VALUES ('2', 'cgk', '2018-07-14 15:06:07', 'CGK3623349554', 'Alamat tidak ketemu', '', '', 'CGK3623349554', '19', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('3', 'cgk', '2018-07-21 16:51:48', 'CGK0417320688', 'Barang telah diterima oleh:', 'DESI', 'YBS', 'CGK0417320688', '41', 'rendi', null, null, null);
INSERT INTO `log_data_pod` VALUES ('4', 'cgk', '2018-08-11 15:07:39', 'CGK1833951474', 'Barang telah diterima oleh:', 'IQBAL', 'YBS', 'CGK1833951474', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('5', 'cgk', '2018-09-08 13:54:03', 'CGK1753904148', 'Barang telah diterima oleh:', 'PARAF', 'SAUDARA', 'CGK1753904148', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('6', 'cgk', '2018-09-21 11:14:03', 'CGK3215887398', 'Barang telah diterima oleh:', 'KANAPI', 'STAFF', 'CGK3215887398', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('7', 'cgk', '2018-09-21 11:19:31', 'CGK1239657810', 'Barang telah diterima oleh:', 'ADE R', 'YBS', 'CGK1239657810', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('8', 'cgk', '2018-09-29 10:34:51', 'CGK2346061885', 'Barang telah diterima oleh:', 'YUDI IRAWAN', 'STAFF', 'CGK2346061885', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('9', 'cgk', '2018-10-01 14:31:07', 'CGK1619763389', 'Barang telah diterima oleh:', 'RAFI', 'YBS', 'CGK1619763389', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('10', 'cgk', '2018-10-01 14:32:03', 'CGK1339890841', 'Barang telah diterima oleh:', 'IBU RIA', 'YBS', 'CGK1339890841', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('11', 'cgk', '2018-12-07 10:27:12', 'CGK4120392791', 'Barang telah diterima oleh:', 'PARAF', 'STAFF', 'CGK4120392791', '41', 'ayu', null, null, null);
INSERT INTO `log_data_pod` VALUES ('12', 'cgk', '2019-01-10 14:59:18', 'CGK1009830033', 'Barang telah diterima oleh:', 'MS. DESY HEC 2 OFFICE', 'STAFF', 'CGK1009830033', '41', 'bunga', null, null, null);
INSERT INTO `log_data_pod` VALUES ('13', 'cgk', '2019-01-10 15:00:16', 'CGK2505850410', 'Barang telah diterima oleh:', 'ENCANG', 'SAUDARA', 'CGK2505850410', '41', 'bunga', null, null, null);

-- ----------------------------
-- Table structure for log_data_void
-- ----------------------------
DROP TABLE IF EXISTS `log_data_void`;
CREATE TABLE `log_data_void` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_void
-- ----------------------------

-- ----------------------------
-- Table structure for mas_insurance
-- ----------------------------
DROP TABLE IF EXISTS `mas_insurance`;
CREATE TABLE `mas_insurance` (
  `InsuranceID` int(11) NOT NULL AUTO_INCREMENT,
  `Insurance` varchar(255) NOT NULL,
  `Premium` decimal(10,0) NOT NULL,
  `Min_Premium` decimal(10,0) NOT NULL,
  PRIMARY KEY (`InsuranceID`),
  KEY `InsuranceID` (`InsuranceID`),
  KEY `Insurance` (`Insurance`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_insurance
-- ----------------------------

-- ----------------------------
-- Table structure for mas_mode
-- ----------------------------
DROP TABLE IF EXISTS `mas_mode`;
CREATE TABLE `mas_mode` (
  `ModeID` int(11) NOT NULL AUTO_INCREMENT,
  `Mode` varchar(20) NOT NULL,
  PRIMARY KEY (`ModeID`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_mode
-- ----------------------------
INSERT INTO `mas_mode` VALUES ('1', 'Air Freight');
INSERT INTO `mas_mode` VALUES ('2', 'Road Freight');
INSERT INTO `mas_mode` VALUES ('3', 'Sea Freight');

-- ----------------------------
-- Table structure for mas_payment
-- ----------------------------
DROP TABLE IF EXISTS `mas_payment`;
CREATE TABLE `mas_payment` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `Payment` varchar(50) NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `PaymentID` (`PaymentID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_payment
-- ----------------------------
INSERT INTO `mas_payment` VALUES ('1', 'Cash');
INSERT INTO `mas_payment` VALUES ('2', 'Cheque');
INSERT INTO `mas_payment` VALUES ('3', 'Cod');
INSERT INTO `mas_payment` VALUES ('4', 'Credit');
INSERT INTO `mas_payment` VALUES ('5', 'Transfer Bank');
INSERT INTO `mas_payment` VALUES ('6', 'Transfer Form');

-- ----------------------------
-- Table structure for mas_relation
-- ----------------------------
DROP TABLE IF EXISTS `mas_relation`;
CREATE TABLE `mas_relation` (
  `RelationID` int(11) NOT NULL AUTO_INCREMENT,
  `Relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RelationID`),
  KEY `RelationID` (`RelationID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_relation
-- ----------------------------
INSERT INTO `mas_relation` VALUES ('1', 'YBS');
INSERT INTO `mas_relation` VALUES ('2', 'AYAH');
INSERT INTO `mas_relation` VALUES ('3', 'IBU');
INSERT INTO `mas_relation` VALUES ('4', 'ANAK');
INSERT INTO `mas_relation` VALUES ('5', 'KAKAK');
INSERT INTO `mas_relation` VALUES ('6', 'ADIK');
INSERT INTO `mas_relation` VALUES ('7', 'KAKEK');
INSERT INTO `mas_relation` VALUES ('8', 'NENEK');
INSERT INTO `mas_relation` VALUES ('9', 'SAUDARA');
INSERT INTO `mas_relation` VALUES ('10', 'PEMBANTU');
INSERT INTO `mas_relation` VALUES ('11', 'SECURITY');
INSERT INTO `mas_relation` VALUES ('12', 'TETANGGA');
INSERT INTO `mas_relation` VALUES ('13', 'SUAMI');
INSERT INTO `mas_relation` VALUES ('14', 'ISTRI');
INSERT INTO `mas_relation` VALUES ('15', 'TEMAN');
INSERT INTO `mas_relation` VALUES ('16', 'CS');
INSERT INTO `mas_relation` VALUES ('17', 'STAFF');
INSERT INTO `mas_relation` VALUES ('18', 'FO');

-- ----------------------------
-- Table structure for sys_company
-- ----------------------------
DROP TABLE IF EXISTS `sys_company`;
CREATE TABLE `sys_company` (
  `BranchID` varchar(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Owner` varchar(50) DEFAULT NULL,
  `PIC` varchar(50) DEFAULT NULL,
  `TIN` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BranchID`),
  KEY `BranchID` (`BranchID`),
  KEY `StatusID` (`StatusID`),
  KEY `Name` (`Name`),
  KEY `Phone` (`Phone`),
  KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_company
-- ----------------------------
INSERT INTO `sys_company` VALUES ('cgk', 'Jakarta', 'Jl. Manggarai Utara VIII F2B No.8 Rt.8 Rw.1\nTebet Jakarta Selatan', '0218290569', '', 'cs@cap-express.co.id', 'Turiman Winata', 'Aji Mulya', '', '1', '2018-03-21 01:18:59', 'aziz', '2018-12-03 05:38:05', 'aziz');
INSERT INTO `sys_company` VALUES ('sub', 'Surabaya', 'Jl. Raya Sedati Gede\nPabean Ruko Pasar Wisata\nBandara Juanda Blok C-18\nSurabaya.', '03199683213', '', 'surabaya@cap-express.co.id', '', '', '', '1', '2018-09-05 11:45:39', 'aziz', '2018-12-03 05:39:37', 'aziz');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `Username` varchar(50) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('ajimulia', 'cgk', '1', '2018-11-24 13:15:26', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('ayu', 'cgk', '1', '2018-07-14 14:40:23', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('aziz', 'cgk', '1', '2018-03-23 12:21:17', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('bunga', 'cgk', '1', '2018-07-14 14:40:10', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('hanunys', 'sub', '1', '2018-09-05 14:00:18', 'massub', null, null);
INSERT INTO `sys_user` VALUES ('hendro', 'cgk', '1', '2018-07-21 16:19:46', 'rendi', null, null);
INSERT INTO `sys_user` VALUES ('massub', 'sub', '1', '2018-09-05 11:48:22', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('rendi', 'cgk', '1', '2018-07-16 12:04:39', 'aziz', null, null);
INSERT INTO `sys_user` VALUES ('reslim', 'cgk', '1', '2018-03-21 01:31:11', 'aziz', null, null);

-- ----------------------------
-- Table structure for tariff_data
-- ----------------------------
DROP TABLE IF EXISTS `tariff_data`;
CREATE TABLE `tariff_data` (
  `BranchID` varchar(10) NOT NULL,
  `Kabupaten` varchar(255) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  `Estimasi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`BranchID`,`Kabupaten`,`ModeID`),
  KEY `BranchID` (`BranchID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_data
-- ----------------------------
INSERT INTO `tariff_data` VALUES ('cgk', 'abepura', '1', '73080', '73080', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'aceh besar', '2', '100000', '14000', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'agats', '1', '101640', '101640', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'air molek', '1', '46200', '46200', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Air Molek', '2', '31080', '31080', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'airmadidi', '1', '48888', '48888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'airmadidi', '2', '23750', '23750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'ajibara', '1', '4500', '4500', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'ajibarang', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ajibarang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'alor', '1', '55608', '55608', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'ambarawa', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'ambarawa', '2', '50000', '4000', '100', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ambon', '1', '44520', '44520', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'ambon', '2', '21875', '21875', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'ampana/tojo una una', '2', '31725', '31725', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'ampenan', '1', '32760', '32760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ampenan', '2', '17550', '17550', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'amuntai', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'amuntai', '2', '21000', '21000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'amurang', '1', '50568', '50568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'amurang', '2', '25625', '25625', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'anyar', '1', '11300', '11300', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'anyar', '2', '7500', '7500', '100', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'argamakmur', '1', '29400', '29400', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'argamakmur', '2', '19500', '19500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'atambua', '1', '50568', '50568', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'bajawa', '1', '55608', '55608', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'balaraja', '1', '9200', '9200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'balik papan', '2', '11000', '11000', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'balikpapan', '1', '31080', '31080', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'balikpapan', '2', '11000', '11000', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'banawa/donggala', '2', '29700', '29700', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'banawa/tojo una-una', '1', '51408', '51408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banda aceh', '1', '35280', '35280', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Banda Aceh', '2', '12500', '12500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandar jaya', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandar jaya', '2', '11400', '11400', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandar lampung', '1', '20328', '20328', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandar lampung', '2', '7500', '7500', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandung', '1', '8540', '8540', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'bandung', '2', '35000', '2500', '5', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'Bangansiapi - api', '2', '26040', '26040', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangansiapi-api', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'banggai', '1', '51408', '51408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banggai', '2', '29700', '29700', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangka', '2', '100000', '13000', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangka belitung', '2', '10100', '10100', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangka/belitung', '1', '21168', '21168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangkalan', '1', '39648', '39648', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangkalan', '2', '75000', '6000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangli', '1', '29400', '29400', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bangli', '2', '100000', '14700', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjamasin', '2', '12500', '12500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjar', '1', '9590', '9590', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjar', '2', '35000', '4500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarbaru', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarbaru', '2', '14000', '14000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarmasin', '1', '26880', '26880', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarmasin', '2', '12500', '12500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarnegara', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banjarnegara', '2', '50000', '4000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bankinang', '1', '41160', '41160', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Bankinang', '2', '26040', '26040', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bantaeng', '1', '47040', '47040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bantaeng', '2', '23750', '23750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bantul', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bantul', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyuasin', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyuasin', '2', '13200', '13200', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyumas', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyumas', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyuwangi', '1', '39648', '39648', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'banyuwangi', '2', '75000', '7000', '5', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'barebai', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'barebai', '2', '23400', '23400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'baroko', '1', '50568', '50568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'baroko', '2', '25625', '25625', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'baros', '1', '10600', '10600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Baros', '2', '50000', '6000', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'barru', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'barru', '2', '20600', '20600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'batam', '1', '21840', '21840', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'batam', '2', '10500', '10500', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'batang hari', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batang hari', '2', '10600', '10600', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu', '1', '39648', '39648', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu aji', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu aji', '2', '10500', '10500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu licin', '1', '47040', '47040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu licin', '2', '31800', '31800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'batu raja', '2', '16800', '16800', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'baturaja', '1', '27720', '27720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batusangkar', '1', '30240', '30240', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'batusangkar', '2', '16200', '16200', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bekasi', '1', '11200', '11200', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'belawan', '1', '26880', '26880', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Belawan', '2', '16900', '16900', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'belitang', '1', '27720', '27720', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'belitang', '2', '16800', '16800', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'belopa', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'belopa', '2', '15000', '15000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bengkalis', '1', '54600', '54600', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Bengkalis', '2', '39400', '39400', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bengkayang', '1', '32088', '32088', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bengkayang', '2', '21800', '21800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bengkulu', '1', '21000', '21000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'bengkulu', '2', '10500', '10500', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'benteng', '1', '40320', '40320', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'benteng', '2', '16800', '16800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'betung', '1', '29400', '29400', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'betung', '2', '16800', '16800', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'biak kota', '1', '97440', '97440', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'biereun', '1', '55440', '55440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Biereun', '2', '31300', '31300', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bima', '1', '32760', '32760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bima', '2', '17500', '17500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'binjai', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Binjai', '2', '16600', '16600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bintuhan', '1', '36120', '36120', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bintuhan', '2', '22900', '22900', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'bintuni', '1', '140280', '140280', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'bitung', '1', '50568', '50568', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'bitung', '2', '25600', '25600', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'blangkejeren', '1', '48720', '48720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Blangkejeren', '2', '24900', '24900', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'blangpidie', '1', '52080', '52080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Blangpidie', '2', '28200', '28200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'blitar', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'blitar', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'blora', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'blora', '2', '50000', '4000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bogor', '1', '11200', '11200', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'bojonegoro', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bojonegoro', '2', '50000', '4000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bondowoso', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bondowoso', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'bontang', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bontang', '2', '13500', '13500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'botawa', '1', '97440', '97440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'boven digoel/tanah merah', '1', '152040', '152040', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'boyolali', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'boyolali', '2', '50000', '4000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'brebes', '1', '34440', '34440', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'brebes', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bual', '1', '46368', '46368', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bual', '2', '23600', '23600', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bujubang', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bujubang', '2', '18300', '18300', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'bukit tinggi', '1', '26880', '26880', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Bukit Tinggi', '2', '15600', '15600', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'bulukumba', '1', '40320', '40320', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bulukumba', '2', '16800', '16800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'bumiayu', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bumiayu', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bungku/kolonedale', '1', '49728', '49728', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'bungku/kolonedale', '2', '27675', '27675', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'buntok', '1', '33600', '33600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'buntok', '2', '24600', '24600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'caruban', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'caruban', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'cepu', '1', '29400', '29400', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'cepu', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ciamis', '1', '13650', '13650', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ciamis', '2', '35000', '3500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'cianjur', '1', '12950', '12950', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cianjur', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cibinong', '1', '11200', '11200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cikarang', '1', '11200', '11200', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'cilacap', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cilacap', '2', '50000', '4500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'cilegon', '1', '11300', '11300', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Cilegon', '2', '50000', '6000', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cimahi', '1', '8540', '8540', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cimahi', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cimareme', '1', '8540', '8540', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cimareme', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'cirebon', '1', '11620', '11620', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'cirebon', '2', '35000', '3500', '5', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'curup', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'curup', '2', '19800', '19800', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'dabo singkep', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'dabo singkep', '2', '22700', '22700', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'demak', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'demak', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'denpasar', '1', '18480', '18480', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'denpasar', '2', '100000', '6000', '50', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'depok', '1', '11200', '11200', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'Dumai', '2', '15600', '15600', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'duri', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Duri', '2', '15600', '15600', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'empat lawang', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'empat lawang', '2', '18200', '18200', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'ende', '1', '47208', '47208', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'enrekang', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'enrekang', '2', '20625', '20625', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'fak fak', '1', '157080', '157080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'garut', '1', '9590', '9590', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'garut', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'gedang tataan', '1', '29568', '29568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'gedang tataan', '2', '16600', '16600', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'gendang tataan', '1', '16625', '16625', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'gerung', '1', '37800', '37800', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'gerung', '2', '22950', '22950', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'gianyar', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'gianyar', '2', '100000', '10000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'gn. pengsong', '1', '37800', '37800', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'gn. pengsong', '2', '37800', '37800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'gn. sari', '1', '32400', '32400', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'gn. sari', '2', '32400', '32400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'gorontalo', '1', '44520', '44520', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'gorontalo', '2', '15500', '15500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'gresik', '1', '21168', '21168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'gresik', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'grobogan', '1', '28000', '28000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'grobogan', '2', '50000', '5000', '10', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'gunung sitoli', '1', '40320', '40320', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Gunung Sitoli', '2', '29700', '29700', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'halmahera', '1', '80808', '80808', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Halmahera', '2', '49200', '49200', '100', '14');
INSERT INTO `tariff_data` VALUES ('cgk', 'hamparan perak', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Hamparan Perak', '2', '31400', '31400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'haruku', '1', '73080', '73080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Haruku', '2', '38125', '38125', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'indralaya', '1', '34440', '34440', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'indralaya', '2', '16875', '16875', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'indramayu', '1', '11900', '11900', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'indramayu', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jailolo', '1', '67368', '67368', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jailolo', '2', '36225', '36225', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'jalukomendalo', '1', '44688', '44688', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jalukomendalo', '2', '32375', '32375', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'jambi', '1', '20328', '20328', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jambi', '2', '8500', '8500', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatibarang', '1', '14700', '14700', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatibarang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatinangor', '1', '9590', '9590', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatinangor', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatiwangi', '1', '12600', '12600', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jatiwangi', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jayapura', '1', '76440', '76440', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jember', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jember', '2', '75000', '6000', '5', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'jeneponto', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jeneponto', '2', '18750', '18750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'jepara', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jepara', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jimbaran', '1', '21000', '21000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jimbaran', '2', '100000', '14000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'jodoh', '1', '24360', '24360', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'jodoh', '2', '12250', '12250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'jombang', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'jombang', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kadipaten', '1', '10290', '10290', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kadipaten', '2', '50000', '4500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kaimana', '1', '190680', '190680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kairatu', '1', '73080', '73080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Kairatu', '2', '38125', '38125', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'kalianda', '1', '26208', '26208', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kalianda', '2', '10625', '10625', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'kalirejo', '1', '26208', '26208', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kalirejo', '2', '13125', '13125', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'kandangan', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kandangan', '2', '21000', '21000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kapahiyang', '1', '24360', '24360', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kapahiyang', '2', '17955', '17955', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'karang anyar', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'karang anyar', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'karawang', '1', '11200', '11200', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'karawang', '2', '35000', '3500', '5', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'kartosuro', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kartosuro', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'karubaga', '1', '93240', '93240', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kasongan', '1', '33600', '33600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kasongan', '2', '24600', '24600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kayu agung', '1', '31080', '31080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kayu agung', '2', '16875', '16875', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'kebumen', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kebumen', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kedang', '1', '55608', '55608', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kediri', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kediri', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kefa', '1', '50568', '50568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kendal', '1', '21000', '21000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kendal', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kendari', '1', '39648', '39648', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kendari', '2', '14000', '14000', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'kepanjen', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kepanjen', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'keppi', '1', '152040', '152040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kerinci', '1', '39648', '39648', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kerinci', '2', '19375', '19375', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'kerobokan', '1', '24360', '24360', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kerobokan', '2', '100000', '10500', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'kertapati', '1', '39480', '39480', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kertapati', '2', '26325', '26325', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'ketapang', '1', '30408', '30408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ketapang', '2', '20125', '20125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kijang', '1', '24360', '24360', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kijang', '2', '12250', '12250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'kisaran', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Kisaran', '2', '21735', '21735', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'klaten', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'klaten', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'koba', '1', '39648', '39648', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'koba', '2', '28560', '28560', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'kosongan', '1', '24600', '24600', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kota agung', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kota agung', '2', '11375', '11375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotabaru', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotabaru', '2', '17500', '17500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotabumi', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotabumi', '2', '11375', '11375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotamubago', '1', '55608', '55608', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kotamubago', '2', '30625', '30625', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kraksaan', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kraksaan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuala kapuas', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuala kapuas', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuala pembuang', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuala simpang', '1', '58800', '58800', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Kuala Simpang', '2', '34615', '34615', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuara pembuangan', '2', '28200', '28200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kudus', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kudus', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuningan', '1', '13300', '13300', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuningan', '2', '35000', '4000', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kupang', '1', '40488', '40488', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kurun', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kurun', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuta', '1', '19320', '19320', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'kuta', '2', '100000', '6500', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'kutacane', '1', '72240', '72240', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Kutacane', '2', '47495', '47495', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'kwandang', '1', '64680', '64680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'kwandang', '2', '37800', '37800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'labuan bajo', '1', '52248', '52248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'labuha', '1', '74088', '74088', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Labuha', '2', '42665', '42665', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'lagoi', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'lagoi', '2', '10500', '10500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'lahat', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lahat', '2', '16875', '16875', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'lamandau/nangabulik', '1', '37800', '37800', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lamandau/nangabulik', '2', '37800', '37800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lamno', '1', '63840', '63840', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Lamno', '2', '39445', '39445', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lamongan', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lamongan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung barat', '1', '27888', '27888', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung barat', '2', '11250', '11250', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung tengah', '1', '27888', '27888', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung tengah', '2', '11250', '11250', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung timur', '1', '27888', '27888', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lampung timur', '2', '11250', '11250', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'langsa', '1', '58800', '58800', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'langsa', '2', '34615', '34615', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'larantuka', '1', '52248', '52248', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lati/baerau', '1', '70560', '70560', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lati/baerau', '2', '27500', '27500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lawuji', '1', '72408', '72408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Lawuji', '2', '41055', '41055', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'lembang', '1', '8540', '8540', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'lembang', '2', '4500', '4500', '10', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'lembar', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lembar', '2', '27000', '27000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lembata', '1', '53928', '53928', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lhoksomawe', '1', '42000', '42000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Lhoksomawe', '2', '15525', '15525', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'limboto', '1', '56280', '56280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'limboto', '2', '29400', '29400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lingga', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lingga', '2', '22750', '22750', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'lingsar', '1', '37800', '37800', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lingsar', '2', '22950', '22950', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'liwa', '1', '36288', '36288', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'liwa', '2', '18125', '18125', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'loa kulu', '1', '57960', '57960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'loa kulu', '2', '31875', '31875', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lobam', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'lobam', '2', '14000', '14000', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'lombok barat', '2', '100000', '10000', '50', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'lombok timur', '2', '100000', '8000', '50', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuk linggau', '1', '39480', '39480', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuk linggau', '2', '16875', '16875', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuk pakam', '1', '40320', '40320', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Lubuk Pakam', '2', '29785', '29785', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuk sekaping', '1', '35280', '35280', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuk sekaping', '2', '18125', '18125', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuklinggau', '1', '32760', '32760', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'lubuklinggau', '2', '19575', '19575', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'lumajang', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'lumajang', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'luwuk', '1', '42840', '42840', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'luwuk', '2', '14000', '14000', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'maba', '1', '77448', '77448', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Maba', '2', '45885', '45885', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'madiun', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'madiun', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'magelang', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'magelang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'magetan', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'magetan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'majalaya', '1', '10290', '10290', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'majalaya', '2', '35000', '3500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'majalengka', '1', '10290', '10290', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'majalengka', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'majenang', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'majenang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'majene', '1', '46200', '46200', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'makale', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'makale', '2', '18750', '18750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'makassar', '1', '31920', '31920', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'makassar', '2', '9500', '9500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'malang', '1', '27552', '27552', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'malang', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'malili', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'malili', '2', '12500', '12500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'malinau', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'malinau', '2', '16800', '16800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'mamasa', '1', '49560', '49560', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'mamuju', '1', '49560', '49560', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'manado', '1', '42168', '42168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'manado', '2', '16500', '16500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'manggar', '1', '36288', '36288', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'manggar', '2', '25200', '25200', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'manna', '1', '29400', '29400', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'manna', '2', '19575', '19575', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'manokwari', '1', '98280', '98280', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'marabaham', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'marabaham', '2', '21000', '21000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'marelan', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Marelan', '2', '27125', '27125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'marisa', '1', '59640', '59640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'marisa', '2', '33000', '33000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'maros', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'maros', '2', '12500', '12500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'marotai', '1', '72408', '72408', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'marotai', '2', '41055', '41055', '100', '14');
INSERT INTO `tariff_data` VALUES ('cgk', 'marta pura', '2', '18225', '18225', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'martapura', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'martapura/banjar', '1', '26400', '26400', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'martapura/banjar', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'masamba', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'masamba', '2', '12500', '12500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'masohi', '1', '68040', '68040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Masohi', '2', '31875', '31875', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'mataram', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'mataram', '2', '10500', '10500', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'maumere', '1', '50568', '50568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'medan', '1', '25200', '25200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Medan', '2', '9500', '9500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'mempawah', '1', '37128', '37128', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'mempawah', '2', '27600', '27600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'menggala', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'menggala', '2', '11375', '11375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'merak', '1', '12000', '12000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'merak', '2', '50000', '7000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'merangin', '1', '32928', '32928', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'merangin', '2', '16875', '16875', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'merauke', '1', '97440', '97440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'merawang', '1', '34608', '34608', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'merawang', '2', '23520', '23520', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'metro', '1', '22848', '22848', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'metro', '2', '9625', '9625', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'meulaboh', '1', '55440', '55440', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Meulaboh', '2', '31395', '31395', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'minas', '1', '41160', '41160', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Minas', '2', '26040', '26040', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'mojokerto', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'mojokerto', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'monokwari', '1', '98280', '98280', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'moro', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'moro', '2', '10500', '10500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara aman', '1', '27720', '27720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara aman', '2', '21735', '21735', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara badak', '1', '52920', '52920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara badak', '2', '26250', '26250', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara dua', '1', '37800', '37800', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara dua', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara enim', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara enim', '2', '16875', '16875', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara jambi', '1', '26208', '26208', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara jambi', '2', '13125', '13125', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara tebo', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara tebo', '2', '16875', '16875', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara teweh', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muara teweh', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'muaro bungo', '1', '32928', '32928', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muaro bungo', '2', '16875', '16875', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'muka kuning', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'muka kuning', '2', '10500', '10500', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'muko muko', '2', '19575', '19575', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'muko-muko', '1', '32760', '32760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'mulia', '1', '194040', '194040', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'mungkid', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'mungkid', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'muntok', '1', '44688', '44688', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'muntok', '2', '33600', '33600', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'nabire', '1', '126840', '126840', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'nagoya', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'nagoya', '2', '10500', '10500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'namlea', '1', '64680', '64680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Namlea', '2', '27500', '27500', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'narmada', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'narmada', '2', '18900', '18900', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'natar', '1', '24528', '24528', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'natar', '2', '11375', '11375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'natuna', '1', '51240', '51240', '10', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'natuna', '2', '40250', '40250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngabang', '1', '40488', '40488', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngabang', '2', '29900', '29900', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngajuk', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngajuk', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngawi', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ngawi', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'nunukan', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'nunukan', '2', '22200', '22200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'nusadua', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'nusadua', '2', '100000', '12000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'oksibil', '1', '160440', '160440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'p kerinci', '1', '46200', '46200', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'p sambu', '1', '42840', '42840', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'p siantar', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'p sidempuan', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'P. kerinci', '2', '15625', '15625', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'P. sambu', '2', '31500', '31500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'P. Siantar', '2', '15525', '15525', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'P. Sidempuan', '2', '21735', '21735', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pacitan', '1', '34608', '34608', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pacitan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'padang', '1', '20160', '20160', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Padang', '2', '9000', '9000', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'padang panjang', '1', '28560', '28560', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'padang panjang', '2', '15625', '15625', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'padangbulan', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Padangbulan', '2', '27125', '27125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pagar alam', '1', '39480', '39480', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pagar alam', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'painan', '1', '45360', '45360', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'painan', '2', '23125', '23125', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'paiton', '1', '39648', '39648', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'paiton', '2', '75000', '6000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'palangkaraya', '1', '26880', '26880', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'palangkaraya', '2', '14400', '14400', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'palaran', '1', '52920', '52920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'palaran', '2', '26250', '26250', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'palembang', '1', '19320', '19320', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'palembang', '2', '7500', '7500', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'palimanan', '1', '12600', '12600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'palimanan', '2', '35000', '3500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'palopo', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'palopo', '2', '13125', '13125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'palu', '1', '41328', '41328', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'palu', '2', '14000', '14000', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'pamekasan', '1', '39648', '39648', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pamekasan', '2', '75000', '6000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'panajam', '1', '52080', '52080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'panajam', '2', '30600', '30600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pancur', '1', '31080', '31080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pancur', '2', '19250', '19250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pandaan', '1', '31248', '31248', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pandaan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pandau', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Pandau', '2', '26040', '26040', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pandeglang', '1', '9900', '9900', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pandeglang', '2', '50000', '7000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkajene', '1', '40320', '40320', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkajene', '2', '16875', '16875', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkal pinang', '1', '21168', '21168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkal pinang', '2', '8500', '8500', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkalan balai', '1', '39480', '39480', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkalan balai', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkalan bun', '1', '31920', '31920', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pangkalan bun', '2', '16200', '16200', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'panjang', '1', '24528', '24528', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'panjang', '2', '11375', '11375', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pantai/emorotari', '1', '177240', '177240', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pare pare', '1', '42000', '42000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pare pare', '2', '18750', '18750', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'pariaman', '1', '26880', '26880', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Pariaman', '2', '15625', '15625', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'paringin/balangan', '1', '19800', '19800', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'paringin/balangan', '2', '19800', '19800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pasangkayu', '1', '49560', '49560', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pasuruan', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pasuruan', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pati', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pati', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'payahkumbuh', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'payahkumbuh', '2', '16875', '16875', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'payakumbuh', '2', '16875', '16875', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pekalongan', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pekalongan', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pekanbaru', '1', '25200', '25200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Pekanbaru', '2', '8500', '8500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pelabuhan ratu', '1', '17500', '17500', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pelabuhan ratu', '2', '50000', '7500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pelaihari', '1', '33600', '33600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pelaihari', '2', '18000', '18000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pemalang', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pemalang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pendopo tl ubi', '1', '19575', '19575', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'pendopo tl ubi', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'perawang', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Perawang', '2', '15000', '15000', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'perigi', '1', '48048', '48048', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'perigi', '2', '23625', '23625', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pesisir selatan', '1', '35280', '35280', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pesisir selatan', '2', '18125', '18125', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'pinang baris', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Pinang Baris', '2', '31395', '31395', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'pinrang', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pinrang', '2', '15000', '15000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'polewali', '1', '46200', '46200', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ponorogo', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ponorogo', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pontianak', '1', '25368', '25368', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'pontianak', '2', '100000', '8000', '50', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'posso', '1', '46368', '46368', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'posso', '2', '22275', '22275', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'prabumulih', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'prabumulih', '2', '16875', '16875', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'prambanan', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'prambanan', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pringsewu', '1', '41328', '41328', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'pringsewu', '2', '10625', '10625', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'probolinggo', '1', '27888', '27888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'probolinggo', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'pulang pisau', '1', '36960', '36960', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'pulang pisau', '2', '28200', '28200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'purbalingga', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'purbalingga', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'puruk cahu', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'puruk cahu', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwakarta', '1', '11200', '11200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwakarta', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwodadi', '1', '26000', '26000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwodadi', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwokerto', '1', '18480', '18480', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'purwokerto', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'purworejo', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'purworejo', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'putussibau', '1', '35448', '35448', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'putussibau', '2', '25300', '25300', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'puwodadi', '1', '4500', '4500', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'rajabasa', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rajabasa', '2', '11375', '11375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'ramba', '1', '34440', '34440', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'ramba', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'rancaekek', '1', '8540', '8540', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'rancaekek', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'rangkasbitung', '1', '9900', '9900', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rangkasbitung', '2', '50000', '7500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rantau', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rantau', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'rantepao', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rantepao', '2', '18750', '18750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'rasel', '1', '148680', '148680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ratahan', '1', '55608', '55608', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ratahan', '2', '30625', '30625', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'rembang', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rembang', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'rengat', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Rengat', '2', '15625', '15625', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'renon', '1', '29400', '29400', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'renon', '2', '100000', '14700', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'rumbai', '1', '27720', '27720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Rumbai', '2', '12600', '12600', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'ruteng', '1', '52248', '52248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sabang', '1', '50400', '50400', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sabang', '2', '26565', '26565', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'salat panjang', '2', '31500', '31500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'salatiga', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'salatiga', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'samarinda', '1', '36960', '36960', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'samarinda', '2', '14500', '14500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'sambas', '1', '35448', '35448', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sambas', '2', '25300', '25300', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sampang', '1', '39648', '39648', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sampang', '2', '75000', '6000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sampit', '1', '30240', '30240', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sampit', '2', '16200', '16200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanana', '1', '77448', '77448', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sanana', '2', '45885', '45885', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanga sanga', '1', '52920', '52920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanga sanga', '2', '26250', '26250', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sangatta', '2', '19375', '19375', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanggau', '1', '40488', '40488', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanggau', '2', '29900', '29900', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sangtta', '1', '40320', '40320', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanur', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sanur', '2', '100000', '10000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'sarmi', '1', '135240', '135240', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'saroako', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sau siu', '1', '77448', '77448', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sau Siu', '2', '45885', '45885', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'saumlaki', '1', '64680', '64680', '10', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Saumlaki', '2', '27500', '27500', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'sawahlunto', '1', '30240', '30240', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sawahlunto', '2', '16250', '16250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'sebatik', '1', '46200', '46200', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sebatik', '2', '19375', '19375', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekadau hilir', '1', '45528', '45528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekadau hilir', '2', '35075', '35075', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekayu', '1', '31080', '31080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekayu', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekupang', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sekupang', '2', '14000', '14000', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'selat panjang', '1', '42840', '42840', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'seluma', '1', '29400', '29400', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'seluma', '2', '19575', '19575', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'semarang', '1', '18480', '18480', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'semarang', '2', '50000', '4000', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'senayang', '1', '32760', '32760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'senayang', '2', '21000', '21000', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'sendawar', '1', '45360', '45360', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sendawar', '2', '25000', '25000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'senggigi', '1', '34440', '34440', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'senggigi', '2', '18900', '18900', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'sengkang', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sengkang', '2', '15000', '15000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sentani', '1', '74760', '74760', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'serang', '1', '9900', '9900', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'serang', '2', '50000', '6000', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'serolangun', '1', '36288', '36288', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'serolangun', '2', '16875', '16875', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'serpong/bsd', '1', '9200', '9200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'serui/yapen waropen', '1', '143640', '143640', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'siak', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Siak', '2', '15625', '15625', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'sibolga', '1', '31920', '31920', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sibolga', '2', '16675', '16675', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sidenreng', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sidenreng', '2', '18750', '18750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sidoarjo', '1', '21168', '21168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sidoarjo', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sigli', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sigli', '2', '20125', '20125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sijungjung', '1', '31920', '31920', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sijungjung', '2', '16250', '16250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'singaparna', '1', '17500', '17500', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'singaparna', '2', '35000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'singaraja', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'singaraja', '2', '100000', '12000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'singkawang', '1', '32088', '32088', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'singkawang', '2', '21850', '21850', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sinjal', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sinjal', '2', '15000', '15000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sintang', '1', '32088', '32088', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sintang', '2', '21850', '21850', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'situbondo', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'situbondo', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'slawi', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'slawi', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sleman', '1', '24360', '24360', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sleman', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'soe', '1', '50568', '50568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'soffi', '1', '75768', '75768', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Soffi', '2', '44275', '44275', '100', '114');
INSERT INTO `tariff_data` VALUES ('cgk', 'solo', '1', '18480', '18480', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'solo', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'solok', '1', '40320', '40320', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'solok', '2', '18125', '18125', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'solok selatan', '1', '40320', '40320', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'solok selatan', '2', '18750', '18750', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'soreang', '1', '8540', '8540', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'soreang', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sorendiwesi', '1', '152040', '152040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'soroako', '2', '20625', '20625', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sorong', '1', '98280', '98280', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sragen', '1', '26040', '26040', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sragen', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'stabat', '1', '30240', '30240', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Stabat', '2', '21875', '21875', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'subang', '1', '9590', '9590', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'subang', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukabumi', '1', '13300', '13300', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukabumi', '2', '35000', '6000', '5', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukadana', '1', '37128', '37128', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukadana', '2', '27025', '27025', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukamara', '1', '33600', '33600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukamara', '2', '24600', '24600', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukoharjo', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sukoharjo', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumbawa besar', '1', '29400', '29400', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumbawa besar', '2', '14500', '14500', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumber', '1', '12250', '12250', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumber', '2', '35000', '3500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumedang', '1', '10290', '10290', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumedang', '2', '35000', '3500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumenep', '1', '36288', '36288', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumenep', '2', '75000', '7000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sumonhai', '1', '152040', '152040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai danau', '1', '47040', '47040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai danau', '2', '31200', '31200', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai gerong', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai gerong', '2', '26325', '26325', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai liat', '1', '37968', '37968', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai liat', '2', '26880', '26880', '100', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai lilin', '1', '34440', '34440', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai lilin', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai raya/kubu raya', '1', '35075', '35075', '1', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungai raya/kubu raya', '2', '35075', '35075', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungguminasa', '1', '38640', '38640', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'sungguminasa', '2', '15000', '15000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'surabaya', '1', '20000', '20000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'surabaya', '2', '75000', '5000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'suranadi', '1', '20925', '20925', '1', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'surandi', '2', '20925', '20925', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'suwawa', '1', '59640', '59640', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'suwawa', '2', '33000', '33000', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 't.j redeh/berau', '2', '11000', '11000', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'tahuna', '1', '53928', '53928', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tahuna', '2', '29375', '29375', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tais', '1', '27720', '27720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tais', '2', '18900', '18900', '100', '8');
INSERT INTO `tariff_data` VALUES ('cgk', 'takalar', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'takalar', '2', '18750', '18750', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'takengon', '1', '63840', '63840', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Takengon', '2', '39445', '39445', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'talang putri salju', '1', '29025', '29025', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'talang putri salju', '2', '29025', '29025', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tambanan', '1', '24360', '24360', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tambanan', '2', '100000', '10500', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tambolaka', '1', '50568', '50568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tamiang layang', '1', '35280', '35280', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tamiang layang', '2', '26400', '26400', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanah grogot', '1', '48720', '48720', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanah grogot', '2', '18125', '18125', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'tangerang', '1', '9200', '9200', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanjab timur', '1', '36288', '36288', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanjab timur', '2', '18125', '18125', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanjung', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tanjung', '2', '18900', '18900', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tarahan', '1', '22848', '22848', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tarahan', '2', '9375', '9375', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tarakan', '1', '41160', '41160', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tarakan', '2', '18125', '18125', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tasikmalaya', '1', '9590', '9590', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tasikmalaya', '2', '35000', '3500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tebing tinggi', '1', '31920', '31920', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tebing Tinggi', '2', '15525', '15525', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tegal', '1', '36120', '36120', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tegal', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'teluk kuantan', '1', '46200', '46200', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Teluk Kuantan', '2', '31080', '31080', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'teluk pandan', '1', '44520', '44520', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'teluk pandan', '2', '17500', '17500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'temanggung', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'temanggung', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tembaga pura', '1', '158760', '158760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tembilahan', '1', '41160', '41160', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tembilahan', '2', '26040', '26040', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tembung', '1', '28560', '28560', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tembung', '2', '18515', '18515', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tenggamus', '1', '29568', '29568', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tenggamus', '2', '13125', '13125', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tenggarong', '1', '44520', '44520', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tenggarong', '2', '17500', '17500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'terminabuan', '1', '158760', '158760', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ternate', '1', '55608', '55608', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Ternate', '2', '24955', '24955', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'tg batu', '1', '51240', '51240', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'TG. batu', '2', '40250', '40250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tigaraksa', '1', '9900', '9900', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tilamuta', '1', '64680', '64680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tilamuta', '2', '37800', '37800', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'timika', '1', '126000', '126000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj balai karimun', '1', '37800', '37800', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj morowa', '1', '42000', '42000', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj pandan', '1', '21168', '21168', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj pinang', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj uban', '1', '42840', '42840', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj ucang', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. balai karimun', '1', '26250', '26250', '1', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'TJ. balai karimun', '2', '26250', '26250', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. bintan', '1', '11250', '11250', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. bintan', '2', '11250', '11250', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. enim', '1', '18225', '18225', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. enim', '2', '18225', '18225', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tj. Morowa', '2', '31395', '31395', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. pandan', '2', '10080', '10080', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tj. pinang', '2', '10500', '10500', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. raja', '1', '19575', '19575', '1', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. raja', '2', '19575', '19575', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. redeh/berau', '1', '54600', '54600', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. selor', '1', '73080', '73080', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tj. selor', '2', '30000', '30000', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tj. uban', '2', '31500', '31500', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tobelo', '1', '72408', '72408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tobelo', '2', '41055', '41055', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'toboali', '1', '44688', '44688', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'toboali', '2', '33600', '33600', '100', '6');
INSERT INTO `tariff_data` VALUES ('cgk', 'toli toli', '1', '51408', '51408', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'toli toli', '2', '29700', '29700', '100', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'tomohon', '1', '53928', '53928', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tomohon', '2', '29375', '29375', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'tondano', '1', '57288', '57288', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tondano', '2', '32500', '32500', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'trenggalek', '1', '31248', '31248', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'trenggalek', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tual', '1', '81480', '81480', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Tual', '2', '43750', '43750', '100', '10');
INSERT INTO `tariff_data` VALUES ('cgk', 'tuban', '1', '24528', '24528', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'tuban', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tulang bawang', '1', '26208', '26208', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'tulang bawang', '2', '13125', '13125', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'tulung agung', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'tulungagung', '1', '26208', '26208', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ubud', '1', '22680', '22680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'ubud', '2', '100000', '10000', '50', '7');
INSERT INTO `tariff_data` VALUES ('cgk', 'unggaran', '1', '22680', '22680', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'unggaran', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'waikabubak', '1', '52248', '52248', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'waingapu', '1', '55608', '55608', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'waisai', '1', '148680', '148680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wajok', '1', '48888', '48888', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wajok', '2', '37950', '37950', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'wamena', '1', '96600', '96600', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'watampone', '1', '43680', '43680', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'watampone', '2', '20625', '20625', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'watansoppeng', '1', '45360', '45360', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'watansoppeng', '2', '21875', '21875', '100', '9');
INSERT INTO `tariff_data` VALUES ('cgk', 'wates/kulonprogo', '1', '4500', '4500', '1', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'wates/kulonprogo', '2', '50000', '4000', '10', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'watis', '1', '15600', '15600', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'way kanan', '1', '29568', '29568', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'way kanan', '2', '16625', '16625', '100', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'weda', '1', '75768', '75768', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Weda', '2', '44275', '44275', '100', '12');
INSERT INTO `tariff_data` VALUES ('cgk', 'wingi', '1', '37968', '37968', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wingi', '2', '75000', '5000', '5', '4');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonogiri', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonogiri', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonosari', '1', '27720', '27720', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonosari', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonosobo', '1', '26040', '26040', '1', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'wonosobo', '2', '50000', '4000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'yogjakarta', '1', '19320', '19320', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'yogjakarta', '2', '50000', '4000', '5', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BANDUNG', '1', '50000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BANDUNG', '2', '50000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'bangkalan', '2', '20000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BANJARNEGARA', '1', '110000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BANJARNEGARA', '2', '110000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BANYUMAS', '1', '150000', '3500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'BANYUMAS', '2', '150000', '6000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'banyuwangi', '2', '45000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BATANG', '1', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BATANG', '2', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BEKASI', '1', '50000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BEKASI', '2', '50000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'blitar', '2', '25000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BLORA', '1', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BLORA', '2', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'BOGOR', '1', '60000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BOGOR', '2', '60000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'bojonegoro', '2', '30000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'bondowoso', '2', '30000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BOYOLALI', '1', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BOYOLALI', '2', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'BREBES', '1', '125000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'BREBES', '2', '125000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'CIAMIS', '1', '100000', '5000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'CIAMIS', '2', '100000', '5000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'CIANJUR', '1', '80000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'CIANJUR', '2', '80000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'CILACAP', '1', '150000', '6000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'CILACAP', '2', '150000', '6000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'CILEGON', '1', '70000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'CILEGON', '2', '70000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'CIMAHI', '1', '60000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'CIMAHI', '2', '60000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'CIREBON', '1', '70000', '4000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'CIREBON', '2', '70000', '4000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'DEMAK', '1', '75000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'DEMAK', '2', '75000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'DEPOK', '1', '50000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'DEPOK', '2', '50000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'GARUT', '1', '80000', '4500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'GARUT', '2', '80000', '4500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'gresik', '2', '15000', '1500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'GROBOGAN', '1', '80000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'GROBOGAN', '2', '80000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'INDRAMAYU', '1', '70000', '4000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'JAKARTA', '1', '50000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'JAKARTA', '2', '50000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'JEMBER', '2', '35000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'JEPARA', '1', '80000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'JEPARA', '2', '80000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'JOMBANG', '2', '25000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'KARANGANYAR', '1', '65000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KARANGANYAR', '2', '65000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KARAWANG', '1', '60000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KARAWANG', '2', '60000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'KEBUMEN', '1', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KEBUMEN', '2', '100000', '3500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'KEDIRI', '2', '25000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'KENDAL', '1', '75000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KENDAL', '2', '75000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KLATEN', '1', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KLATEN', '2', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KUDUS', '1', '65000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'KUDUS', '2', '65000', '2500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'KUNINGAN', '1', '100000', '5000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'KUNINGAN', '2', '100000', '5000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'LAMONGAN', '2', '20000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'LUMAJANG', '2', '30000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'MADIUN', '2', '35000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'MAGELANG', '1', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'MAGELANG', '2', '85000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'MAGETAN', '2', '40000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'MALANG', '2', '20000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'MOJOKERTO', '2', '15000', '1500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'NGANJUK', '2', '30000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'NGAWI', '2', '35000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PACITAN', '2', '45000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PAMEKASAN', '2', '30000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PANDEGLANG', '1', '75000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PANDEGLANG', '2', '75000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PANGANDARAN', '1', '125000', '6000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PANGANDARAN', '2', '125000', '6000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PASURUAN', '2', '20000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PATI', '1', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PATI', '2', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PEKALONGAN', '1', '80000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PEKALONGAN', '2', '80000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PEMALANG', '1', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PEMALANG', '2', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PERBALINGGA', '1', '110000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PONOROGO', '2', '30000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PROBOLINGGO', '2', '30000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'PURBALINGGA', '2', '110000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PURWAKARTA', '1', '70000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PURWAKARTA', '2', '70000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'PURWOREJO', '1', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'PURWOREJO', '2', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'RANGKAS BITUNG', '1', '75000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'RANGKAS BITUNG', '2', '75000', '4500', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'REMBANG', '1', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'REMBANG', '2', '60000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SAMPANG', '2', '35000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SEMARANG', '1', '50000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SEMARANG', '2', '50000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SERANG', '1', '65000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SERANG', '2', '65000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SIDOARJO', '2', '10000', '1000', '20', '1');
INSERT INTO `tariff_data` VALUES ('sub', 'SITUBONDO', '2', '35000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SOLO', '1', '50000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SOLO', '2', '50000', '2000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SRAGEN', '1', '65000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SRAGEN', '2', '65000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SUBANG', '1', '60000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SUBANG', '2', '60000', '3500', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'SUKABUMI', '1', '80000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SUKABUMI', '2', '80000', '4500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SUMEDANG', '1', '70000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SUMEDANG', '2', '70000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SUMENEP', '2', '40000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'SURABAYA ', '2', '10000', '1000', '20', '1');
INSERT INTO `tariff_data` VALUES ('sub', 'TANGERANG', '1', '60000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TANGERANG', '2', '60000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TASIKAMALAYA', '2', '100000', '5000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TASIKMALAYA', '1', '100000', '50000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TEGAL', '1', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TEGAL', '2', '100000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TEMANGGUNG', '1', '75000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TEMANGGUNG', '2', '75000', '2500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'TRENGGALEK', '2', '40000', '4000', '20', '4');
INSERT INTO `tariff_data` VALUES ('sub', 'TUBAN', '2', '30000', '3000', '20', '2');
INSERT INTO `tariff_data` VALUES ('sub', 'TULUNAGUNG', '2', '30000', '3000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'WONOGIRI', '1', '75000', '3500', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'WONOGIRI', '2', '75000', '35000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'WONOSOBO', '1', '100000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'WONOSOBO', '2', '100000', '4000', '20', '3');
INSERT INTO `tariff_data` VALUES ('sub', 'YOGYAKARTA', '2', '50000', '2500', '20', '2');

-- ----------------------------
-- Table structure for tariff_handling
-- ----------------------------
DROP TABLE IF EXISTS `tariff_handling`;
CREATE TABLE `tariff_handling` (
  `Kabupaten` varchar(50) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  PRIMARY KEY (`Kabupaten`,`ModeID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_handling
-- ----------------------------

-- ----------------------------
-- Table structure for transaction_waybill
-- ----------------------------
DROP TABLE IF EXISTS `transaction_waybill`;
CREATE TABLE `transaction_waybill` (
  `Waybill` varchar(20) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `DestID` varchar(10) NOT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Consignor_name` varchar(50) NOT NULL,
  `Consignor_alias` varchar(50) DEFAULT NULL,
  `Consignor_address` varchar(255) NOT NULL,
  `Consignor_phone` varchar(15) NOT NULL,
  `Consignor_fax` varchar(15) DEFAULT NULL,
  `Consignor_email` varchar(50) DEFAULT NULL,
  `ReferenceID` varchar(20) DEFAULT NULL,
  `Consignee_name` varchar(50) NOT NULL,
  `Consignee_attention` varchar(50) DEFAULT NULL,
  `Consignee_address` varchar(255) NOT NULL,
  `Consignee_phone` varchar(15) NOT NULL,
  `Consignee_fax` varchar(15) DEFAULT NULL,
  `ModeID` int(11) NOT NULL,
  `Instruction` varchar(255) DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Goods_data` varchar(1000) NOT NULL,
  `Goods_koli` decimal(5,0) NOT NULL,
  `Goods_value` decimal(10,0) NOT NULL,
  `Weight` decimal(7,2) NOT NULL,
  `Weight_real` decimal(7,2) NOT NULL,
  `Origin` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Estimation` varchar(7) NOT NULL,
  `Insurance_rate` decimal(7,2) NOT NULL,
  `Shipping_cost` decimal(10,0) NOT NULL,
  `Shipping_insurance` decimal(10,0) NOT NULL,
  `Shipping_packing` decimal(10,0) NOT NULL,
  `Shipping_forward` decimal(10,0) NOT NULL,
  `Shipping_handling` decimal(10,0) NOT NULL,
  `Shipping_surcharge` decimal(10,0) NOT NULL,
  `Shipping_admin` decimal(10,0) NOT NULL,
  `Shipping_discount` decimal(10,0) NOT NULL,
  `Shipping_cost_total` decimal(10,0) NOT NULL,
  `Tariff_kgp` decimal(10,0) NOT NULL,
  `Tariff_kgs` decimal(10,0) NOT NULL,
  `Tariff_kgp_min` decimal(4,0) NOT NULL,
  `Tariff_hkgp` decimal(10,0) NOT NULL,
  `Tariff_hkgs` decimal(10,0) NOT NULL,
  `Tariff_hkgp_min` decimal(4,0) NOT NULL,
  `PaymentID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Waybill`),
  KEY `Waybill` (`Waybill`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Consignor_name` (`Consignor_name`),
  KEY `Consignor_phone` (`Consignor_phone`),
  KEY `ReferenceID` (`ReferenceID`),
  KEY `Consignee_name` (`Consignee_name`),
  KEY `Consignee_phone` (`Consignee_phone`),
  KEY `ModeID` (`ModeID`),
  KEY `Destination` (`Destination`),
  KEY `PaymentID` (`PaymentID`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `BranchID` (`BranchID`),
  KEY `DestID` (`DestID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of transaction_waybill
-- ----------------------------
INSERT INTO `transaction_waybill` VALUES ('CGK0417320688', 'cgk', 'cgk', '', 'PT CIPTA AMANAH PERSADA', 'CAP', 'JAKARTA', '083824679611', '', '', '', 'RS BAKTI TIMAH', 'IBU DESI', 'JL CANGGAI PUTRI KEL TELUK UMA KEC TEBING KAB KARIMUN', '081364070037', '', '1', 'URGENT', 'ALKES', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"4\",\"volume\":\"0.00\",\"total\":\"4\"}]', '1', '100000', '4.00', '4.00', 'Jakarta', 'batam', '2', '0.03', '87360', '1000', '0', '0', '0', '0', '0', '5000', '83360', '21840', '21840', '1', '0', '0', '0', '1', '41', '2018-07-21 16:35:27', 'rendi', '2018-07-21 16:51:48', 'rendi', '2018-07-21 16:51:48');
INSERT INTO `transaction_waybill` VALUES ('CGK1009830033', 'cgk', 'cgk', '', 'khadijah', '', 'jakarta', '085814295286', '', '', '', 'Kantor HEC 3', 'Muhammad Ali Alatas', 'Jl. Pinang 3 C Singgahan Palem, Pare - Kediri\nJawa Timur. 64213', '088803179097', '', '2', 'Segera Dikirim', 'Pakaian', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"4\",\"volume\":\"0.00\",\"total\":\"4\"}]', '1', '0', '4.00', '4.00', 'Jakarta', 'kediri', '4', '0.00', '75000', '0', '0', '0', '0', '0', '0', '0', '75000', '75000', '5000', '5', '0', '0', '0', '1', '41', '2019-01-05 12:57:36', 'ayu', '2019-01-10 14:59:18', 'bunga', '2019-01-10 14:59:18');
INSERT INTO `transaction_waybill` VALUES ('CGK1239657810', 'cgk', 'cgk', '', 'TIARA', '', 'JAKARTA', '01', '', '', '', 'ADE RUSWANDI', '', 'JL. S. PARMAN GG. HUNI NO. 15 RT23/07, KEL. SOKLAT, KEC. SUBANG,\nSUBANG - JAWA BARAT', '085224049448', '', '2', 'URGENT & JANGAN DIBANTING', 'HP', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"10\",\"volume\":\"0.00\",\"total\":\"10\"}]', '1', '0', '10.00', '10.00', 'Jakarta', 'subang', '2', '0.00', '52500', '0', '0', '0', '0', '0', '0', '0', '52500', '35000', '3500', '5', '0', '0', '0', '1', '41', '2018-09-18 15:18:00', 'ayu', '2018-09-21 11:19:30', 'ayu', '2018-09-21 11:19:30');
INSERT INTO `transaction_waybill` VALUES ('CGK1339890841', 'cgk', 'cgk', '', 'PT. VIDYA CITRA MECHATRONIC', '', 'JL. TEBET RAYA NO. 45 D, TEBET,\nJAKARTA SELATAN 12820\n', '083717994443', '', '', '', 'CITIMALL BATU RAJA', 'IBU RIA', 'JL. JEND A. YANI, DESA TANJUNG BARU, KEC. BATU RAJA TIMUR,\nKAB. OGAN KOMERING ULU, SUMATERA SELATAN 32121\n', '082279099995', '', '1', 'URGENT', 'KABEL', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"10\",\"volume\":\"0.00\",\"total\":\"10\"}]', '1', '0', '10.00', '10.00', 'Jakarta', 'baturaja', '3', '0.00', '277200', '0', '0', '0', '0', '0', '0', '0', '277200', '27720', '27720', '1', '0', '0', '0', '1', '41', '2018-09-25 16:52:27', 'ayu', '2018-10-01 14:32:03', 'ayu', '2018-10-01 14:32:03');
INSERT INTO `transaction_waybill` VALUES ('CGK1619763389', 'cgk', 'cgk', '', 'ZULIYAN GITAR@SECOND', '', 'JAKARTA', '083875320724', '', '', '', 'RAFI IZUDDIN AL ALAWI', '', 'RT06/02 DESA SIWALAN KEC. PANCENG KAB. GRESIK 61156', '081338043477', '', '2', 'JANGAN DIBANTING', 'GITAR', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"24\",\"volume\":\"0.00\",\"total\":\"24\"}]', '1', '0', '24.00', '24.00', 'Jakarta', 'gresik', '4', '0.00', '170000', '0', '100000', '0', '0', '0', '0', '0', '270000', '75000', '5000', '5', '0', '0', '0', '1', '41', '2018-09-26 09:53:04', 'ayu', '2018-10-01 14:31:07', 'ayu', '2018-10-01 14:31:07');
INSERT INTO `transaction_waybill` VALUES ('CGK1753904148', 'cgk', 'cgk', '', 'SRI WAHYUNI', '', 'JAKARTA', '085693155534', '', '', '', 'BU MIEM', '', 'DUSUN SUMBERAGUNG RT004/001, KEL. SUMBERAGUNG, GODONG, GROBOGAN', '085693155534', '', '2', 'SEGERA DIANTAR', 'HANDPHONE', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"10\",\"volume\":\"0.00\",\"total\":\"10\"}]', '1', '0', '10.00', '10.00', 'Jakarta', 'semarang', '2', '0.00', '50000', '0', '0', '0', '0', '0', '0', '0', '50000', '50000', '4000', '10', '0', '0', '0', '1', '41', '2018-08-28 14:50:06', 'bunga', '2018-09-08 13:54:03', 'ayu', '2018-09-08 13:54:03');
INSERT INTO `transaction_waybill` VALUES ('CGK1833951474', 'cgk', 'cgk', '', 'ibnu', '', 'jakarta', '1234', '', '', '', 'iqbal', '', 'jogja', '123', '', '2', 'segera', 'motor ninja 250cc', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"125\",\"volume\":\"0.00\",\"total\":\"125\"}]', '1', '0', '125.00', '125.00', 'Jakarta', 'yogjakarta', '2', '0.00', '510000', '0', '0', '0', '0', '0', '0', '10000', '500000', '50000', '4000', '10', '0', '0', '0', '1', '41', '2018-08-11 15:02:51', 'ayu', '2018-08-11 15:07:39', 'ayu', '2018-08-11 15:07:39');
INSERT INTO `transaction_waybill` VALUES ('CGK2323263470', 'cgk', 'cgk', '', 'M Abd Aziz Alfian', '', 'Jl. I Gusti Ngurah Rai Blok 1J Lt.2\nKlender Jakarta Timur\n(Samping Citra Mall Klender)', '083806075400', '', '', '', 'Tika Amelia Putri', '', 'Jl. H. Taiman Ujung No. 08 RT. 06 RW. 04\nKel. Tengah Kec. Kramat Jati\nJakarta Timur - 15740', '083804709333', '', '2', 'Segera Diantar', 'Pesanan Makanan', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '1', '0.00', '25000', '0', '0', '0', '0', '0', '0', '0', '25000', '25000', '1500', '5', '0', '0', '0', '1', '29', '2018-04-27 03:21:29', 'aziz', null, null, '2018-04-27 03:21:29');
INSERT INTO `transaction_waybill` VALUES ('CGK2346061885', 'cgk', 'cgk', '', 'PT. VIDYA CITRA MECHATRONIC', '', 'JL. TEBET RAYA NO. 45 D, TEBET, JAKARTA SELATAN 12820', '083717994443', '', '', '', 'CITIMALL LAHAT', 'BPK FENZRIAL / RAHMAD', 'JL. LEMBAYUNG AIR APUL, DESA MANGGUL, KEC. LAHAT, KAB. OGAN KOMERING ULU, SUMATERA SELATAN 31414', '7313200399', '', '1', 'URGENT', 'KABEL', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"13\",\"volume\":\"0.00\",\"total\":\"13\"}]', '1', '0', '13.00', '13.00', 'Jakarta', 'lahat', '3', '0.00', '447720', '0', '0', '0', '0', '0', '0', '0', '447720', '34440', '34440', '1', '0', '0', '0', '1', '41', '2018-09-25 16:57:34', 'ayu', '2018-09-29 10:34:50', 'ayu', '2018-09-29 10:34:50');
INSERT INTO `transaction_waybill` VALUES ('CGK2505850410', 'cgk', 'cgk', '', 'Ibu Tia', '', 'Jakarta selatan', '08129487287', '', '', '', 'Bapak Encang', '', 'Kampung jangari, Rt.001/Rw.011 Desa bobojong kec.mande kab.cianjur Jawa barat', '085295124477', '087714377583', '2', 'segera di antar', 'Bahan pakaian', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"7\",\"volume\":\"0.00\",\"total\":\"7\"}]', '1', '0', '7.00', '7.00', 'Jakarta', 'cianjur', '2', '0.00', '42000', '0', '0', '0', '0', '0', '0', '0', '42000', '35000', '3500', '5', '0', '0', '0', '1', '41', '2019-01-05 10:13:55', 'bunga', '2019-01-10 15:00:16', 'bunga', '2019-01-10 15:00:16');
INSERT INTO `transaction_waybill` VALUES ('CGK3215887398', 'cgk', 'cgk', '', 'BP. ARUNDONO WICAKSONO P', '', 'PT. SECCO GROUP NUSANTARA\nJL. WOLTERMONGINSIDI BLOK Q NO. 106 C\nKEL. PETOGOGAN, KEC. KEBAYORAN BARU\nJAKARTA SELATAN', '01', '', '', '', 'SUJAK ULHAQ', '', 'PT. HAMSINA JAYA MPPG BREBES\nJL. RAYA BREBES CIREBON KM. 12\nDESA KARANGSARI, KEC. BULUKUMBA\nBREBES', '01', '', '2', 'URGENT', 'PAKET', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"30\",\"volume\":\"0.00\",\"total\":\"30\"}]', '1', '0', '30.00', '30.00', 'Jakarta', 'brebes', '3', '0.00', '150000', '0', '0', '0', '0', '25000', '0', '0', '175000', '50000', '4000', '5', '0', '0', '0', '1', '41', '2018-09-14 15:49:24', 'ayu', '2018-09-21 11:14:03', 'ayu', '2018-09-21 11:14:03');
INSERT INTO `transaction_waybill` VALUES ('CGK3270004421', 'cgk', 'cgk', '', 'Aji', 'Lia', 'Jln bogor', '1', '', '', '', 'Lia', 'Lia', 'Depok', '1', '', '2', '', 'Kondom', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"9\",\"volume\":\"0.00\",\"total\":\"9\"}]', '1', '0', '9.00', '9.00', 'Jakarta', 'Jakarta Barat', '1', '0.00', '31000', '0', '1000', '0', '0', '0', '0', '0', '32000', '25000', '1500', '5', '0', '0', '0', '1', '29', '2018-05-05 14:26:32', 'aziz', null, null, '2018-05-05 14:26:32');
INSERT INTO `transaction_waybill` VALUES ('CGK3623349554', 'cgk', 'cgk', '', 'Budi', '', 'Jakarta', '123', '', '', '', 'Joko', '', 'Banten', '123', '', '2', 'Segera Diantar', 'Voucher', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"15\",\"volume\":\"0.00\",\"total\":\"15\"}]', '10', '0', '15.00', '15.00', 'Jakarta', 'Baros', '2', '0.00', '110000', '0', '0', '0', '0', '0', '0', '9000', '101000', '50000', '6000', '5', '0', '0', '0', '1', '19', '2018-07-14 14:58:46', 'ayu', '2018-07-14 15:06:07', 'ayu', '2018-07-14 15:06:07');
INSERT INTO `transaction_waybill` VALUES ('CGK3713886250', 'cgk', 'cgk', '', 'Ayu', '', 'Jakarta', '0222', '', '', '', 'Sifa', '', 'Cilegon', '323', '', '2', 'Sefera diantar', 'Paket', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"7\",\"volume\":\"0.00\",\"total\":\"7\"}]', '1', '0', '7.00', '7.00', 'Jakarta', 'Cilegon', '2', '0.00', '62000', '0', '0', '0', '0', '0', '0', '0', '62000', '50000', '6000', '5', '0', '0', '0', '1', '29', '2018-07-14 15:35:06', 'ayu', null, null, '2018-07-14 15:35:06');
INSERT INTO `transaction_waybill` VALUES ('CGK3801370267', 'cgk', 'cgk', '', 'A', '', 'A', '1', '', '', '', '1', '', '1', '1', '', '2', '', 'Surat', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '10000000', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '1', '0.02', '25000', '2000', '0', '0', '0', '0', '0', '2000', '25000', '25000', '1500', '5', '0', '0', '0', '1', '41', '2018-05-05 13:48:28', 'aziz', '2018-05-05 14:06:07', 'aziz', '2018-05-05 14:06:07');
INSERT INTO `transaction_waybill` VALUES ('CGK3987933966', 'cgk', 'cgk', '', 'PT. SECCO GROUP NUSANTARA', 'BP. ARUNDONO WICAKSONO P', 'JL. WOLTERMONGINSIDI BLOK Q NO. 106 C \nKEL. PETOGOAN, KEC. KEBAYORAN BARU\nJAKARTA SELATAN', '01', '', '', '', 'RIZKY KOMARI', '', 'PT. TANJUNG ODI MPPG SUMENEP\nJL. RAYA PAMEKASAN SUMENEP KM. 05\nDESA GEDUNGAN, KEC. BATUAN\nSUMENEP', '01', '', '2', 'SEGERA', 'PAKET', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"30\",\"volume\":\"0.00\",\"total\":\"30\"}]', '1', '0', '30.00', '30.00', 'Jakarta', 'sumenep', '4', '0.00', '250000', '0', '0', '0', '0', '0', '0', '30000', '220000', '75000', '7000', '5', '0', '0', '0', '1', '29', '2018-09-14 13:11:02', 'ayu', null, null, '2018-09-14 13:11:02');
INSERT INTO `transaction_waybill` VALUES ('CGK4120392791', 'cgk', 'cgk', '', 'PT. Kharisma Berkah Nusantara', '', 'Jakarta', '02218292720', '', '', '', 'CV. Karya Terampil - Kalijati SC', '', 'Jl. Kalijati Purwadadi, Desa Kaliangsang RT07/01, Kec. Kali Jati Kab. Subang', '0260461779', '', '2', 'segera', 'doc', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"50\",\"volume\":\"0.00\",\"total\":\"50\"}]', '1', '0', '50.00', '50.00', 'Jakarta', 'subang', '2', '0.00', '192500', '0', '0', '0', '0', '0', '0', '0', '192500', '35000', '3500', '5', '0', '0', '0', '1', '41', '2018-11-27 11:39:07', 'ayu', '2018-12-07 10:27:11', 'ayu', '2018-12-07 10:27:11');
INSERT INTO `transaction_waybill` VALUES ('SUB2283909274', 'sub', 'sub', '', 'cf', '', 'sidoarjo', '00', '', '', '', 'cf k', '', 'madiun', '00', '', '2', '', 'plastik', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"20\",\"volume\":\"0.00\",\"total\":\"20\"}]', '1', '0', '20.00', '20.00', 'Surabaya', 'madiun', '3', '0.00', '35000', '0', '0', '0', '0', '0', '0', '0', '35000', '35000', '3500', '20', '0', '0', '0', '1', '29', '2018-09-05 15:22:46', 'massub', null, null, '2018-09-05 15:22:46');

-- ----------------------------
-- Table structure for user_api
-- ----------------------------
DROP TABLE IF EXISTS `user_api`;
CREATE TABLE `user_api` (
  `Domain` varchar(50) NOT NULL,
  `ApiKey` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Domain`),
  KEY `Domain` (`Domain`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `ApiKey` (`ApiKey`),
  CONSTRAINT `user_api_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_api_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_api
-- ----------------------------
INSERT INTO `user_api` VALUES ('http://cap-express.co.id', '2JYgIAycWEL48BgxjEjUjmfwGyQKyFlNpmJdBk0JnDiUmoVj0J7hMTVrmywVO', '1', '2018-07-17 17:31:20', 'aziz', null, null);
INSERT INTO `user_api` VALUES ('http://localhost:1337', '2pHslKjfVdHiJAf0cFRfNq5oZXBJRjHOdOQMifccm9GK3kq0z10UMWaCJ', '1', '2018-03-14 12:47:29', 'aziz', null, null);
INSERT INTO `user_api` VALUES ('https://cap-express.co.id', 'bjOR28f04qug9anJ6b4YCJcgFDzKNN7uhoDDr2dslpXMEeBzRQtuyT2zrqtkAk', '1', '2018-07-17 17:31:04', 'aziz', null, null);
INSERT INTO `user_api` VALUES ('https://fiddle.jshell.net', 'bjOR28f04quh4CdoZGZDmPQYaCIxu7r444S4ns4fSBSDSAluLLVw0NpTM5CDOq', '1', '2018-03-14 15:34:32', 'aziz', null, null);
INSERT INTO `user_api` VALUES ('https://www.test-cors.org', 'bjOR28f04qumhRE0Afgr65m1hBiTTPRHZxluZeYO8LH5PqYfWCtBEjWXBl7X0l', '1', '2018-03-14 12:51:49', 'aziz', '2018-03-14 17:59:36', 'aziz');
INSERT INTO `user_api` VALUES ('localhost', '1vvyhfz3RtubHk4qWstEBFiOmO1Iuk6vmQClQMEwS', '1', '2018-03-10 12:01:36', 'reslim', null, null);

-- ----------------------------
-- Table structure for user_auth
-- ----------------------------
DROP TABLE IF EXISTS `user_auth`;
CREATE TABLE `user_auth` (
  `Username` varchar(50) NOT NULL,
  `RS_Token` varchar(255) NOT NULL,
  `Created` datetime NOT NULL,
  `Expired` datetime NOT NULL,
  PRIMARY KEY (`Username`,`RS_Token`),
  KEY `token` (`Username`,`RS_Token`,`Expired`) USING BTREE,
  CONSTRAINT `user_token` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_auth
-- ----------------------------
INSERT INTO `user_auth` VALUES ('ayu', '13cAlk1ZGIwLZv7hVGjhL7h3JrBz9UC1G', '2019-01-05 12:54:00', '2019-01-12 12:54:00');
INSERT INTO `user_auth` VALUES ('aziz', '4leBDmLG6JmY9MIYyXqAGFXkofLZ1Dwc81', '2019-01-08 02:25:21', '2019-01-15 02:25:21');
INSERT INTO `user_auth` VALUES ('aziz', '4leBDmLG6JmY9MIYyXqAGxaPdmgIIzeS4A', '2019-01-02 22:56:54', '2019-01-09 22:56:54');
INSERT INTO `user_auth` VALUES ('aziz', '4leBDmLG6JmY9MIYyXqAMyqjoCq5HAfX6H', '2019-01-11 16:09:33', '2019-01-18 16:09:33');
INSERT INTO `user_auth` VALUES ('aziz', '4leBDmLG6JmY9MIYyXqAMzT3X991OMN0Gi', '2019-01-12 13:28:36', '2019-01-19 13:28:36');
INSERT INTO `user_auth` VALUES ('aziz', '4leBDmLG6JmY9MIYyXqAMzT42rSCNitfTj', '2019-01-12 22:41:19', '2019-01-19 22:41:19');
INSERT INTO `user_auth` VALUES ('bunga', 'i6RD4L7I7phJAQBQagsbVsidEX8nkXp3LAE', '2019-01-05 10:06:54', '2019-01-12 10:06:54');
INSERT INTO `user_auth` VALUES ('bunga', 'i6RD4L7I7phJAQBQagsbVsmBUCVrqfIhfeY', '2019-01-08 11:27:24', '2019-01-15 11:27:24');
INSERT INTO `user_auth` VALUES ('bunga', 'i6RD4L7I7phJAQBQagsbVydC8ZmbmTeiiHl', '2019-01-10 14:57:07', '2019-01-17 14:57:07');
INSERT INTO `user_auth` VALUES ('bunga', 'i6RD4L7I7phJAQzXaQQ08slnZiHPtTCyzuT', '2018-12-31 14:06:27', '2019-01-07 14:06:27');

-- ----------------------------
-- Table structure for user_data
-- ----------------------------
DROP TABLE IF EXISTS `user_data`;
CREATE TABLE `user_data` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fullname` varchar(50) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Aboutme` varchar(255) DEFAULT NULL,
  `Avatar` text,
  `BranchID` varchar(7) DEFAULT NULL,
  `RoleID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`UserID`,`Username`),
  KEY `user_data_ibfk_1` (`StatusID`),
  KEY `user_data_ibfk_2` (`RoleID`),
  KEY `Username` (`Username`),
  KEY `Fullname` (`Fullname`) USING BTREE,
  KEY `Password` (`Password`),
  KEY `Email` (`Email`),
  KEY `BranchID` (`BranchID`) USING BTREE,
  CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_data_ibfk_2` FOREIGN KEY (`RoleID`) REFERENCES `user_role` (`RoleID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_data
-- ----------------------------
INSERT INTO `user_data` VALUES ('1', 'reslim', '$2y$11$D9ZWJOhKvLoor7RyUA70hOVzbwJ9RA.nk909QLENotxq26F6k/Qxu', 'Master', 'INDONESIA', '12345', 'your@yourdomain.com', 'Master of reSlim Project', '', null, '2', '42', '2016-12-28 20:17:12', '2018-07-24 10:14:34');
INSERT INTO `user_data` VALUES ('2', 'aziz', '$2y$11$js..q9o5.b1YTax7PJARFeDTjK0PjyoFB59ordsMI7YlpCBftN4e2', 'M ABD AZIZ ALFIAN', '', '', 'aalfiann@gmail.com', '', 'https://s3.narvii.com/image/eavr6kt3s6e7jfukaqe5ccfqppixtjnm_hq.jpg', null, '1', '1', '2018-03-12 04:34:53', '2018-07-27 19:58:06');
INSERT INTO `user_data` VALUES ('3', 'webmaster', '$2y$11$TWJA42PlYRrFak7Gi0KeFOyX4o3N.cMByL7WyxG9qCcw3w/aZIsHy', 'webmaster', '', '', 'webmaster@gmail.com', '', '', null, '5', '1', '2018-03-12 07:57:06', null);
INSERT INTO `user_data` VALUES ('4', 'ayu', '$2y$08$wGjPLP6M8QB2HrS0uwrSx.8yJkDIG2odTiGLb3vB0BwC5UyQp2RI6', 'ayu', '', '', 'ayulestarianggraini@gmail.com', '', '', null, '7', '1', '2018-07-14 14:37:46', '2018-08-23 19:10:10');
INSERT INTO `user_data` VALUES ('5', 'bunga', '$2y$08$pwxwmHezA9vVKf/S7moD8uchG/vKvxM1Mlu31bxLc6PNZYMUq74Ta', 'bunga', '', '', 'bungaardilya27@gmail.com', '', '', null, '2', '1', '2018-07-14 14:39:33', '2018-08-29 09:31:28');
INSERT INTO `user_data` VALUES ('7', 'rendi', '$2y$08$Zq1J5WZagycQF3rPbqYcHeHPkVEiL4wP0TpMM2Z5GQlUjdmylnUQW', 'rendi', '', '', 'rendy.cap27@gmail.com', '', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxTKesxKFV0Dh3XIaAabpNsyo5TxXZVmB4bLqmsCh-95XJnPPWZg', null, '2', '1', '2018-07-16 12:04:06', '2018-07-22 02:14:05');
INSERT INTO `user_data` VALUES ('8', 'hendro', '$2y$08$XvJIqrK4gEvsN4.z1Ha3zus4BpbhE0ItL75khkhBwzgLb08ICUD9O', 'hendro', '', '', 'hendro.cap@gmail.com', '', '', null, '7', '1', '2018-07-21 16:18:48', null);
INSERT INTO `user_data` VALUES ('9', 'hanun', '$2y$08$7lYXMbJBDndf5bNQ/Brc/eEBYC/yGkn.ASH3vLmC742g2yiiUbogy', 'hanun', '', '', 'hanunsiswindar@gmail.com', '', '', null, '7', '1', '2018-09-05 11:27:45', '2018-09-05 13:35:44');
INSERT INTO `user_data` VALUES ('10', 'massub', '$2y$08$odxCC/a7H4Zj4dF3mZZaJ.GnrLlsXPTwX48uUmRry7EO0hRZXDA0W', 'massub', '', '', 'surabaya@cap-express.co.id', '', '', null, '6', '1', '2018-09-05 11:47:49', null);
INSERT INTO `user_data` VALUES ('11', 'hanunys', '$2y$08$qoZ7XxGswa3uDcFk.X476elqNvMRLIQGVXWIEPqJqlxBKAS6lzZyi', 'hanunys', '', '', 'hyusryya@gmail.com', '', '', null, '7', '1', '2018-09-05 13:35:08', '2018-09-05 13:40:51');
INSERT INTO `user_data` VALUES ('12', 'kutu', '$2y$08$YeFWgfk3e075Qb2Gz1rYP.ei3UGlSEBaPDtptRyLUuk0EGvdY9Dum', 'kutu', '', '', 'feriharjulianto@gmail.com', '', '', null, '1', '1', '2018-11-01 11:32:53', '2018-11-01 11:35:05');
INSERT INTO `user_data` VALUES ('13', 'ajimulia', '$2y$08$sT9jw3BDC/Pn4wrxkp68EejJNAhKP8QzDD4ShQT5lAkulqLVBddBu', 'ajimulia', '', '', 'ajimulia86@ymail.com', '', '', null, '2', '1', '2018-11-24 13:13:44', '2018-12-04 18:53:40');

-- ----------------------------
-- Table structure for user_forgot
-- ----------------------------
DROP TABLE IF EXISTS `user_forgot`;
CREATE TABLE `user_forgot` (
  `Email` varchar(50) NOT NULL,
  `Verifylink` varchar(255) NOT NULL,
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `Expired` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Email`,`Verifylink`),
  KEY `Email` (`Email`),
  KEY `Verifylink` (`Verifylink`),
  CONSTRAINT `user_forgot_ibfk_1` FOREIGN KEY (`Email`) REFERENCES `user_data` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_forgot
-- ----------------------------
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFCw7bpFBS6Qr5RDAXz', '2018-07-21 16:06:05', '2018-07-24 16:06:05');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24PN9K3IpFWTEeB', '2018-05-04 15:58:51', '2018-05-07 15:58:51');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24RfUtjE6mLJsHe', '2018-05-06 23:43:30', '2018-05-09 23:43:30');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWxDrm47nXb', '2018-05-07 11:28:29', '2018-05-10 11:28:29');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWxDrqDYg5O', '2018-05-07 11:32:38', '2018-05-10 11:32:38');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWxDrvjv6Ly', '2018-05-07 11:41:34', '2018-05-10 11:41:34');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWxDrvjv6PE', '2018-05-07 11:41:42', '2018-05-10 11:41:42');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWxDrvrrSlb', '2018-05-07 11:48:21', '2018-05-10 11:48:21');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWyVmNQhJsx', '2018-05-07 12:14:55', '2018-05-10 12:14:55');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWyVmNSywqR', '2018-05-07 12:16:41', '2018-05-10 12:16:41');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFzc24SIEWyVmNUPjl9', '2018-05-07 12:18:23', '2018-05-10 12:18:23');
INSERT INTO `user_forgot` VALUES ('rendy.cap27@gmail.com', '2DWNQ1XE5gLZtxBTyOgn7p1jO6gqvn5CxFmqq1qqKekgKjweHiU9OUsmN', '2018-07-21 16:03:25', '2018-07-24 16:03:25');
INSERT INTO `user_forgot` VALUES ('rendy.cap27@gmail.com', '2DWNQ22xkZtpRkyiknSQY6Bg0mqIKc1J8xg8A93MS89cy5156JlFhvsgG', '2018-07-21 16:13:24', '2018-07-21 16:13:24');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `RoleID` int(11) NOT NULL AUTO_INCREMENT,
  `Role` varchar(255) NOT NULL,
  PRIMARY KEY (`RoleID`),
  KEY `ID` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', 'superuser');
INSERT INTO `user_role` VALUES ('2', 'admin');
INSERT INTO `user_role` VALUES ('3', 'member');
INSERT INTO `user_role` VALUES ('4', 'developer');
INSERT INTO `user_role` VALUES ('5', 'applicant');
INSERT INTO `user_role` VALUES ('6', 'master');
INSERT INTO `user_role` VALUES ('7', 'standart');
INSERT INTO `user_role` VALUES ('8', 'customer');
INSERT INTO `user_role` VALUES ('9', 'agent');

-- ----------------------------
-- Table structure for user_upload
-- ----------------------------
DROP TABLE IF EXISTS `user_upload`;
CREATE TABLE `user_upload` (
  `ItemID` int(11) NOT NULL AUTO_INCREMENT,
  `Date_Upload` datetime NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Alternate` varchar(255) DEFAULT NULL,
  `External_link` varchar(255) DEFAULT NULL,
  `Filename` varchar(255) NOT NULL,
  `Filepath` varchar(255) NOT NULL,
  `Filetype` varchar(255) NOT NULL,
  `Filesize` double NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  PRIMARY KEY (`ItemID`),
  KEY `ItemID` (`ItemID`),
  KEY `Date_Upload` (`Date_Upload`),
  KEY `Filename` (`Filename`),
  KEY `Filetype` (`Filetype`),
  KEY `Username` (`Username`) USING BTREE,
  KEY `StatusID` (`StatusID`) USING BTREE,
  CONSTRAINT `user_upload_ibfk_1` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_upload_ibfk_2` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_upload
-- ----------------------------
INSERT INTO `user_upload` VALUES ('25', '2018-07-14 15:14:59', 'awb', '', '', 'AWB 028263.jpg', 'upload/07-2018/AWB 028263.jpg', 'image/jpeg', '25951', 'ayu', null, null, '49');
INSERT INTO `user_upload` VALUES ('26', '2018-07-21 17:01:15', 'harga udara', '', '', 'HARGA UDARA PT. CAP.xlsx', 'upload/07-2018/HARGA UDARA PT. CAP.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '33804', 'rendi', null, null, '49');
INSERT INTO `user_upload` VALUES ('27', '2018-12-04 18:56:21', 'sma', '', '', 'sma 7986 LIBRATA VII 2015.xlsx', 'upload/12-2018/sma 7986 LIBRATA VII 2015.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '72665', 'ajimulia', null, null, '49');

-- ----------------------------
-- Event structure for delete_all_expired_auth
-- ----------------------------
DROP EVENT IF EXISTS `delete_all_expired_auth`;
DELIMITER ;;
CREATE DEFINER=`cap_dev`@`%` EVENT `delete_all_expired_auth` ON SCHEDULE EVERY 1 DAY STARTS '2018-02-19 18:56:11' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM user_auth WHERE DATE_ADD(Expired,INTERVAL 7 DAY) < CURRENT_TIMESTAMP
;;
DELIMITER ;
SET FOREIGN_KEY_CHECKS=1;
