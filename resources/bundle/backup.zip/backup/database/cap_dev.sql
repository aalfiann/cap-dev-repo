/*
Navicat MariaDB Data Transfer

Source Server         : CAP-EXPRESS
Source Server Version : 100131
Source Host           : server.cap-express.co.id:3306
Source Database       : cap_dev

Target Server Type    : MariaDB
Target Server Version : 100131
File Encoding         : 65001

Date: 2019-01-14 03:12:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for agent_config
-- ----------------------------
DROP TABLE IF EXISTS `agent_config`;
CREATE TABLE `agent_config` (
  `KeyID` varchar(50) NOT NULL,
  `Config` text,
  `Description` varchar(255) DEFAULT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Created_by` varchar(50) DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`KeyID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_config
-- ----------------------------
INSERT INTO `agent_config` VALUES ('agent_config_reslim', '{\"logo\":\"\",\"name\":\"Wahana Express\",\"slogan\":\"\",\"address\":\"Jakarta\",\"phone\":\"123\",\"fax\":\"\",\"email\":\"\",\"website\":\"\",\"coordinat\":\"\",\"hotline\":\"\",\"facebook\":\"\",\"twitter\":\"\",\"gplus\":\"\",\"owner\":\"\",\"signature\":\"\",\"legality\":\"\",\"bank_name\":\"Bank BCA\",\"bank_address\":\"Jakarta\",\"bank_account_name\":\"M ABD AZIZ ALFIAN\",\"bank_account_no\":\"12345\",\"origin_district\":\"\",\"admin_cost\":\"\"}', 'Agent Configuration', '2018-07-21 04:22:17', 'reslim', null, null);

-- ----------------------------
-- Table structure for agent_log_data
-- ----------------------------
DROP TABLE IF EXISTS `agent_log_data`;
CREATE TABLE `agent_log_data` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_log_data
-- ----------------------------

-- ----------------------------
-- Table structure for agent_transaction_waybill
-- ----------------------------
DROP TABLE IF EXISTS `agent_transaction_waybill`;
CREATE TABLE `agent_transaction_waybill` (
  `Waybill` varchar(20) NOT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Consignor_name` varchar(50) NOT NULL,
  `Consignor_alias` varchar(50) DEFAULT NULL,
  `Consignor_address` varchar(255) NOT NULL,
  `Consignor_phone` varchar(15) NOT NULL,
  `Consignor_fax` varchar(15) DEFAULT NULL,
  `Consignor_email` varchar(50) DEFAULT NULL,
  `ReferenceID` varchar(20) DEFAULT NULL,
  `Consignee_name` varchar(50) NOT NULL,
  `Consignee_attention` varchar(50) DEFAULT NULL,
  `Consignee_address` varchar(255) NOT NULL,
  `Consignee_phone` varchar(15) NOT NULL,
  `Consignee_fax` varchar(15) DEFAULT NULL,
  `Mode` varchar(50) NOT NULL,
  `Instruction` varchar(255) DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Goods_data` varchar(1000) NOT NULL,
  `Goods_koli` decimal(5,0) NOT NULL,
  `Goods_value` decimal(10,0) NOT NULL,
  `Weight` decimal(7,2) NOT NULL,
  `Weight_real` decimal(7,2) NOT NULL,
  `Origin` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Estimation` varchar(7) NOT NULL,
  `Insurance_rate` decimal(7,2) NOT NULL,
  `Shipping_cost` decimal(10,0) NOT NULL,
  `Shipping_insurance` decimal(10,0) NOT NULL,
  `Shipping_packing` decimal(10,0) NOT NULL,
  `Shipping_forward` decimal(10,0) NOT NULL,
  `Shipping_handling` decimal(10,0) NOT NULL,
  `Shipping_surcharge` decimal(10,0) NOT NULL,
  `Shipping_admin` decimal(10,0) NOT NULL,
  `Shipping_discount` decimal(10,0) NOT NULL,
  `Shipping_cost_total` decimal(10,0) NOT NULL,
  `Payment` varchar(50) NOT NULL,
  `Signature` varchar(50) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Company_logo` varchar(255) DEFAULT NULL,
  `Company_name` varchar(50) DEFAULT NULL,
  `Company_address` varchar(255) DEFAULT NULL,
  `Company_phone` varchar(15) DEFAULT NULL,
  `Company_fax` varchar(15) DEFAULT NULL,
  `Company_email` varchar(50) DEFAULT NULL,
  `Company_TIN` varchar(50) DEFAULT NULL,
  `Recipient` varchar(50) DEFAULT NULL,
  `Relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Waybill`),
  KEY `Waybill` (`Waybill`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Consignor_name` (`Consignor_name`),
  KEY `Consignor_phone` (`Consignor_phone`),
  KEY `ReferenceID` (`ReferenceID`),
  KEY `Consignee_name` (`Consignee_name`),
  KEY `Consignee_phone` (`Consignee_phone`),
  KEY `Destination` (`Destination`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Mode` (`Mode`),
  KEY `Payment` (`Payment`),
  KEY `Signature` (`Signature`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of agent_transaction_waybill
-- ----------------------------

-- ----------------------------
-- Table structure for core_status
-- ----------------------------
DROP TABLE IF EXISTS `core_status`;
CREATE TABLE `core_status` (
  `StatusID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` varchar(255) NOT NULL,
  PRIMARY KEY (`StatusID`),
  KEY `StatusID` (`StatusID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of core_status
-- ----------------------------
INSERT INTO `core_status` VALUES ('1', 'active');
INSERT INTO `core_status` VALUES ('2', 'allocated');
INSERT INTO `core_status` VALUES ('3', 'approved');
INSERT INTO `core_status` VALUES ('4', 'authorized');
INSERT INTO `core_status` VALUES ('5', 'banned');
INSERT INTO `core_status` VALUES ('6', 'blank');
INSERT INTO `core_status` VALUES ('7', 'canceled');
INSERT INTO `core_status` VALUES ('8', 'checked');
INSERT INTO `core_status` VALUES ('9', 'closed');
INSERT INTO `core_status` VALUES ('10', 'commented');
INSERT INTO `core_status` VALUES ('11', 'compared');
INSERT INTO `core_status` VALUES ('12', 'deleted');
INSERT INTO `core_status` VALUES ('13', 'disabled');
INSERT INTO `core_status` VALUES ('14', 'downloaded');
INSERT INTO `core_status` VALUES ('15', 'edited');
INSERT INTO `core_status` VALUES ('16', 'enabled');
INSERT INTO `core_status` VALUES ('17', 'error');
INSERT INTO `core_status` VALUES ('18', 'expired');
INSERT INTO `core_status` VALUES ('19', 'failed');
INSERT INTO `core_status` VALUES ('20', 'hidden');
INSERT INTO `core_status` VALUES ('21', 'installed');
INSERT INTO `core_status` VALUES ('22', 'listed');
INSERT INTO `core_status` VALUES ('23', 'locked');
INSERT INTO `core_status` VALUES ('24', 'maintenance');
INSERT INTO `core_status` VALUES ('25', 'merged');
INSERT INTO `core_status` VALUES ('26', 'moved');
INSERT INTO `core_status` VALUES ('27', 'ok');
INSERT INTO `core_status` VALUES ('28', 'on hold');
INSERT INTO `core_status` VALUES ('29', 'on process');
INSERT INTO `core_status` VALUES ('30', 'on request');
INSERT INTO `core_status` VALUES ('31', 'open');
INSERT INTO `core_status` VALUES ('32', 'outstanding');
INSERT INTO `core_status` VALUES ('33', 'overdue');
INSERT INTO `core_status` VALUES ('34', 'paid');
INSERT INTO `core_status` VALUES ('35', 'pending');
INSERT INTO `core_status` VALUES ('36', 'registered');
INSERT INTO `core_status` VALUES ('37', 'rejected');
INSERT INTO `core_status` VALUES ('38', 'removed');
INSERT INTO `core_status` VALUES ('39', 'signed');
INSERT INTO `core_status` VALUES ('40', 'stopped');
INSERT INTO `core_status` VALUES ('41', 'success');
INSERT INTO `core_status` VALUES ('42', 'suspended');
INSERT INTO `core_status` VALUES ('43', 'unauthorized');
INSERT INTO `core_status` VALUES ('44', 'unknown');
INSERT INTO `core_status` VALUES ('45', 'uploaded');
INSERT INTO `core_status` VALUES ('46', 'viewed');
INSERT INTO `core_status` VALUES ('47', 'void');
INSERT INTO `core_status` VALUES ('48', 'waiting');
INSERT INTO `core_status` VALUES ('49', 'public');
INSERT INTO `core_status` VALUES ('50', 'private');
INSERT INTO `core_status` VALUES ('51', 'publish');
INSERT INTO `core_status` VALUES ('52', 'draft');
INSERT INTO `core_status` VALUES ('53', 'return');

-- ----------------------------
-- Table structure for crud_mod
-- ----------------------------
DROP TABLE IF EXISTS `crud_mod`;
CREATE TABLE `crud_mod` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Telp` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Website` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of crud_mod
-- ----------------------------
INSERT INTO `crud_mod` VALUES ('2', 'Hendrawan', 'Jakarta', '', '', '');

-- ----------------------------
-- Table structure for crud_mod_adv
-- ----------------------------
DROP TABLE IF EXISTS `crud_mod_adv`;
CREATE TABLE `crud_mod_adv` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Telp` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Website` varchar(50) DEFAULT NULL,
  `Custom_id` varchar(255) DEFAULT NULL,
  `Custom_field` text,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Custom_id` (`Custom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of crud_mod_adv
-- ----------------------------
INSERT INTO `crud_mod_adv` VALUES ('1', 'ALFIAN', 'Jakarta', '', 'aalfiann@gmail.com', 'javelinee.com', '{\"ktp\":\"987\"}', '{\"city\":\"Surabaya\"}', '2018-11-16 13:06:17', 'reslim', '2018-11-16 13:24:53', 'reslim', '2018-11-16 13:24:53');
INSERT INTO `crud_mod_adv` VALUES ('2', 'M ABD AZIZ ALFIAN', '', '', '', '', '{\"ktp\":\"123\"}', '{\"city\":\"Jakarta\"}', '2018-11-16 13:10:30', 'reslim', null, null, '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for customer_company
-- ----------------------------
DROP TABLE IF EXISTS `customer_company`;
CREATE TABLE `customer_company` (
  `BranchID` varchar(10) NOT NULL,
  `CompanyID` varchar(20) NOT NULL,
  `Company_name` varchar(50) NOT NULL,
  `Company_name_alias` varchar(50) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `PIC` varchar(50) NOT NULL,
  `TIN` varchar(50) DEFAULT NULL,
  `Discount` decimal(7,2) NOT NULL,
  `Tax` decimal(7,2) NOT NULL,
  `Admin_cost` decimal(10,2) NOT NULL,
  `IndustryID` int(11) NOT NULL,
  `SalesID` varchar(20) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CompanyID`),
  KEY `BranchID` (`BranchID`),
  KEY `IndustryID` (`IndustryID`),
  KEY `StatusID` (`StatusID`),
  KEY `SalesID` (`SalesID`),
  KEY `Name` (`CompanyID`,`Company_name`,`Company_name_alias`) USING BTREE,
  KEY `Created_by` (`Created_by`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_company
-- ----------------------------
INSERT INTO `customer_company` VALUES ('cgk', 'CC1209096569', 'PT, MAJU JAYA', '', 'Jl. H. Taiman Ujung No. 08 Rt.6 Rw.4\nKampung Tengah Kramat Jati\nJakarta Timur', '02112345', '', 'majujaya@gmail.com', 'GUNAWAN', '', '5.30', '0.00', '0.00', '12', '', '42', '2018-08-15 14:18:58', 'reslim', '2018-12-03 05:49:01', 'reslim');
INSERT INTO `customer_company` VALUES ('cgk', 'CC1406593391', 'PT, MAJU MUNDUR', '', 'Jakarta', '02112345', '', 'majumundur@gmail.com', 'BUDI', '', '0.00', '0.00', '0.00', '7', '', '1', '2018-08-15 14:21:47', 'reslim', null, null);
INSERT INTO `customer_company` VALUES ('cgk', 'CC1937356852', 'BNI Life', '', 'Jakarta Timur', '1', '', '', 'Medi', '', '0.00', '0.00', '1000.90', '2', '', '1', '2018-08-24 16:13:54', 'reslim', '2018-08-24 20:05:04', 'reslim');

-- ----------------------------
-- Table structure for customer_mas_industry
-- ----------------------------
DROP TABLE IF EXISTS `customer_mas_industry`;
CREATE TABLE `customer_mas_industry` (
  `IndustryID` int(11) NOT NULL AUTO_INCREMENT,
  `Industry` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IndustryID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_mas_industry
-- ----------------------------
INSERT INTO `customer_mas_industry` VALUES ('1', 'Others');
INSERT INTO `customer_mas_industry` VALUES ('2', 'Banking');
INSERT INTO `customer_mas_industry` VALUES ('3', 'Insurance');
INSERT INTO `customer_mas_industry` VALUES ('4', 'Logistics');
INSERT INTO `customer_mas_industry` VALUES ('5', 'Entertainment');
INSERT INTO `customer_mas_industry` VALUES ('6', 'Hospital / Health Care');
INSERT INTO `customer_mas_industry` VALUES ('7', 'Advertising');
INSERT INTO `customer_mas_industry` VALUES ('8', 'Automotive');
INSERT INTO `customer_mas_industry` VALUES ('9', 'Publishing');
INSERT INTO `customer_mas_industry` VALUES ('10', 'Outsourcing');
INSERT INTO `customer_mas_industry` VALUES ('11', 'Transportation');
INSERT INTO `customer_mas_industry` VALUES ('12', 'Retail');
INSERT INTO `customer_mas_industry` VALUES ('13', 'Goverment');
INSERT INTO `customer_mas_industry` VALUES ('14', 'Manufacturing');
INSERT INTO `customer_mas_industry` VALUES ('15', 'Chemical / Pharmacy');
INSERT INTO `customer_mas_industry` VALUES ('16', 'Food and Beverages');
INSERT INTO `customer_mas_industry` VALUES ('17', 'Financial Institutions');
INSERT INTO `customer_mas_industry` VALUES ('18', 'General Trading');
INSERT INTO `customer_mas_industry` VALUES ('19', 'Consultant');
INSERT INTO `customer_mas_industry` VALUES ('20', 'Electronic');
INSERT INTO `customer_mas_industry` VALUES ('21', 'Aviation / Airlines');
INSERT INTO `customer_mas_industry` VALUES ('22', 'Business Supplies');
INSERT INTO `customer_mas_industry` VALUES ('23', 'Package / Courier / Delivery');
INSERT INTO `customer_mas_industry` VALUES ('24', 'Political Organization');
INSERT INTO `customer_mas_industry` VALUES ('25', 'Venture Capital');

-- ----------------------------
-- Table structure for customer_member
-- ----------------------------
DROP TABLE IF EXISTS `customer_member`;
CREATE TABLE `customer_member` (
  `BranchID` varchar(10) NOT NULL,
  `MemberID` varchar(20) NOT NULL,
  `Member_name` varchar(50) NOT NULL,
  `Member_name_alias` varchar(50) DEFAULT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Discount` decimal(7,2) NOT NULL,
  `Admin_cost` decimal(10,2) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MemberID`),
  KEY `BranchID` (`BranchID`),
  KEY `Name` (`MemberID`,`Member_name`,`Member_name_alias`),
  KEY `StatusID` (`StatusID`),
  KEY `Phone` (`Phone`),
  KEY `Created_by` (`Created_by`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer_member
-- ----------------------------
INSERT INTO `customer_member` VALUES ('cgk', 'MM3511920434', 'M Abd Aziz Alfian', 'Fian', 'Jl. H. Taiman Ujung No.08 Rt.06 Rw.04 Kel. Tengah Kec. Kramat Jati Jakarta Timur DKI Jakarta 17540', '083806075400', '', 'aalfiann@gmail.com', '5.30', '1000.00', '1', '2018-08-15 16:19:18', 'reslim', '2018-08-25 03:38:57', 'reslim');

-- ----------------------------
-- Table structure for data_bank
-- ----------------------------
DROP TABLE IF EXISTS `data_bank`;
CREATE TABLE `data_bank` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Bank_name` varchar(50) NOT NULL,
  `Bank_fullname` varchar(50) DEFAULT NULL,
  `Account_name` varchar(50) NOT NULL,
  `Account_no` varchar(20) NOT NULL,
  `Bank_address` varchar(253) DEFAULT NULL,
  `Custom_id` varchar(255) DEFAULT NULL,
  `Custom_field` text,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Custom_id` (`Custom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of data_bank
-- ----------------------------
INSERT INTO `data_bank` VALUES ('2', 'BCA', 'Bank Central Asia', 'M ABD AZIZ ALFIAN', '7480607729', '', '{\"BranchID\":\"cgt\"}', '', '2018-11-21 10:50:38', 'reslim', '2018-11-22 13:31:56', 'reslim', '2018-11-22 13:31:56');
INSERT INTO `data_bank` VALUES ('3', 'BCA', 'Bank Central Asia', 'M ABD AZIZ ALFIAN', '7480607729', '', '{\"BranchID\":\"cgk\"}', '', '2018-11-21 10:50:52', 'reslim', '2018-11-23 10:50:05', 'reslim', '2018-11-23 10:50:05');
INSERT INTO `data_bank` VALUES ('5', 'BRI', 'Bank BRI', 'TIKA', '5677654', 'Kramat Jati Jakarta', '{\"BranchID\":\"cgk\"}', '', '2018-11-22 14:29:51', 'reslim', null, null, '0000-00-00 00:00:00');
INSERT INTO `data_bank` VALUES ('6', 'Mandiri', 'Bank Mandiri', 'ALFIAN', '7544284543', '', '{\"BranchID\":\"cgk\"}', '', '2018-11-22 14:45:34', 'reslim', null, null, '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for data_page
-- ----------------------------
DROP TABLE IF EXISTS `data_page`;
CREATE TABLE `data_page` (
  `PageID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Content` text NOT NULL,
  `Tags` varchar(500) DEFAULT NULL,
  `Viewer` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Last_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PageID`),
  KEY `PageID` (`PageID`),
  KEY `Title` (`Title`),
  KEY `Tags` (`Tags`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `Created_at` (`Created_at`),
  CONSTRAINT `data_page_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `data_page_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of data_page
-- ----------------------------
INSERT INTO `data_page` VALUES ('3', 'Tester posting data page', 'http://files.softicons.com/download/culture-icons/popular-anime-icons-by-iconspedia/png/256x256/Fairy-Tail.png', 'hanya tester saja', '<p>hanya tester saja&nbsp;<br></p>', 'Tester,Posting,Page', '1', '51', 'reslim', '2018-03-03 14:16:06', '2018-07-26 18:50:20', 'reslim', '2018-08-01 02:30:00');
INSERT INTO `data_page` VALUES ('4', 'Test buat page dari form update keenam', 'http://server.cap-express.co.id/api/upload/07-2018/1044_4530339749914_1356376084_n.jpg', 'Test buat page dari form update keenam', '<p><img src=\"http://server.cap-express.co.id/api/upload/07-2018/1044_4530339749914_1356376084_n.jpg\" style=\"width: 480px;\"><br></p><p><br></p><p>Test buat page dari form update keenam<br></p>', 'Tester,Posting,Page', '0', '51', 'reslim', '2018-03-06 13:06:18', '2018-07-15 10:31:20', 'reslim', '2018-07-15 10:31:20');
INSERT INTO `data_page` VALUES ('5', 'Tester posting data page member', 'http://files.softicons.com/download/culture-icons/popular-anime-icons-by-iconspedia/png/256x256/Fairy-Tail.png', 'Tester posting data page member', '<p>Tester posting data page member edited a<br></p>', 'Tester,Posting,Page', '0', '51', 'xsilent', '2018-03-09 04:28:42', '2018-07-26 18:49:57', 'reslim', '2018-07-26 18:49:57');
INSERT INTO `data_page` VALUES ('6', 'Test buat page dari form update ketujuh', 'https://m.media-amazon.com/images/M/MV5BZjMxYjJiNDItNTZhMS00MTAxLWE1N2MtYmZkZWYzNzA3ZDk0XkEyXkFqcGdeQXVyNDQxNjcxNQ@@._V1_UY268_CR3,0,182,268_AL_.jpg', 'Test buat page dari form update ketujuh', '<p>Test buat page dari form update ketujuh<br></p>', 'Tester,Posting,Page', '0', '51', 'reslim', '2018-07-26 19:52:15', null, null, null);
INSERT INTO `data_page` VALUES ('7', 'Test buat page dari form update kedelapan', 'https://m.media-amazon.com/images/M/MV5BNGU2N2ZhNTgtMGQwNy00NjkxLWIwNGQtZWQzODMzZGM0MDRhXkEyXkFqcGdeQXVyNDQ5MTgzNzI@._V1_UX182_CR0,0,182,268_AL_.jpg', 'Test buat page dari form update kedelapan', 'Test buat page dari form update kedelapan', 'Comedy, Romance', '0', '51', 'reslim', '2018-07-26 19:52:41', null, null, null);
INSERT INTO `data_page` VALUES ('8', 'Test buat page dari form update kesembilan', 'https://m.media-amazon.com/images/M/MV5BM2UxNzU5ZGYtNzAzZS00YmYwLWJmMWMtMjg5ZmE3YmYzZWNlXkEyXkFqcGdeQXVyOTg4MDYyNw@@._V1_UX182_CR0,0,182,268_AL_.jpg', 'Test buat page dari form update kesembilan', 'Test buat page dari form update kesembilan', 'Tester,Posting, Page', '0', '51', 'reslim', '2018-07-26 19:53:00', null, null, null);
INSERT INTO `data_page` VALUES ('9', 'Test buat page dari form update kesepuluh', 'https://m.media-amazon.com/images/M/MV5BOGE0MDM4ODMtYzQxNi00YzM1LWFjZTktMWU2OTBiYTZlOGY0XkEyXkFqcGdeQXVyOTg4MDYyNw@@._V1_UY268_CR6,0,182,268_AL_.jpg', 'Test buat page dari form update kesepuluh', 'Test buat page dari form update kesepuluh', 'Drama', '1', '51', 'reslim', '2018-07-26 19:53:23', null, null, '2018-07-29 03:08:58');
INSERT INTO `data_page` VALUES ('10', 'Test buat page dari form update kesebelas', 'https://m.media-amazon.com/images/M/MV5BNzc4ODYwMjEwNV5BMl5BanBnXkFtZTgwNTg1Mjg1NDM@._V1_UX182_CR0,0,182,268_AL_.jpg', 'Test buat page dari form update kesebelas', 'Test buat page dari form update kesebelas', 'Tester,Posting,Page', '1', '51', 'reslim', '2018-07-26 19:53:39', null, null, '2018-07-29 03:02:39');
INSERT INTO `data_page` VALUES ('11', 'Test buat page dari form update keduabelas', 'http://server.cap-express.co.id/api/upload/07-2018/1044_4530339749914_1356376084_n.jpg', 'Test buat page dari form update keduabelas', '<p><img src=\"http://server.cap-express.co.id/api/upload/07-2018/1044_4530339749914_1356376084_n.jpg\" style=\"width: 480px;\">&nbsp;</p><p>Test buat page dari form update keduabelas...</p>', 'Comedy, Drama Korea', '3', '51', 'reslim', '2018-07-29 03:39:51', null, null, '2018-12-02 16:44:47');

-- ----------------------------
-- Table structure for deposit_balance
-- ----------------------------
DROP TABLE IF EXISTS `deposit_balance`;
CREATE TABLE `deposit_balance` (
  `DepositID` varchar(50) NOT NULL,
  `Balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`DepositID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_balance
-- ----------------------------
INSERT INTO `deposit_balance` VALUES ('a', '1.00');
INSERT INTO `deposit_balance` VALUES ('alfian', '96000.00');
INSERT INTO `deposit_balance` VALUES ('reslim', '230000.30');

-- ----------------------------
-- Table structure for deposit_history
-- ----------------------------
DROP TABLE IF EXISTS `deposit_history`;
CREATE TABLE `deposit_history` (
  `ReferenceID` varchar(50) NOT NULL,
  `Balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ReferenceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_history
-- ----------------------------
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/00011', '0.00');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/00015', '73500.00');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/00018', '103500.00');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/000180', '110500.30');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/0009', '100000.00');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/00091', '80000.00');
INSERT INTO `deposit_history` VALUES ('2018-05-24/TESTER/00092', '75000.00');
INSERT INTO `deposit_history` VALUES ('5b166b1d1a6386-10308965', '117500.30');
INSERT INTO `deposit_history` VALUES ('5b16f7887cb6f2-36348758', '135500.30');
INSERT INTO `deposit_history` VALUES ('5b16f7a9cffad8-53787386', '126500.30');
INSERT INTO `deposit_history` VALUES ('5b1788b6082d67-41460782', '176500.30');
INSERT INTO `deposit_history` VALUES ('5b178c26e86712-56092482', '209500.30');
INSERT INTO `deposit_history` VALUES ('5b17b25652d4c2-56373906', '218500.30');
INSERT INTO `deposit_history` VALUES ('5b17c8099c10d4-21739829', '0.00');
INSERT INTO `deposit_history` VALUES ('5b35cdf7697b67-26794438', '209500.30');
INSERT INTO `deposit_history` VALUES ('5b35ce2bde93c7-72863953', '200000.30');
INSERT INTO `deposit_history` VALUES ('5b36165baba959-28039382', '210000.30');
INSERT INTO `deposit_history` VALUES ('5b361ebd29d079-13160068', '240000.30');
INSERT INTO `deposit_history` VALUES ('5b39c096d94048-88573402', '238000.30');
INSERT INTO `deposit_history` VALUES ('5b39e8bedc4061-49698704', '236000.30');
INSERT INTO `deposit_history` VALUES ('5b3e747152de71-66322270', '234000.30');
INSERT INTO `deposit_history` VALUES ('5b426c153663f6-33718438', '0.00');
INSERT INTO `deposit_history` VALUES ('5b426c9642e2b8-49339927', '100000.00');
INSERT INTO `deposit_history` VALUES ('5b43467fda3bf3-23997260', '98000.00');

-- ----------------------------
-- Table structure for deposit_mutation
-- ----------------------------
DROP TABLE IF EXISTS `deposit_mutation`;
CREATE TABLE `deposit_mutation` (
  `DepositID` varchar(50) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `ReferenceID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Task` varchar(2) NOT NULL,
  `Mutation` decimal(10,2) NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  PRIMARY KEY (`ReferenceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of deposit_mutation
-- ----------------------------
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 11:01:34', '2018-05-24/TESTER/00011', 'Test pengisian saldo deposit', 'DB', '100000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 11:04:51', '2018-05-24/TESTER/00015', 'Test pengisian saldo deposit', 'DB', '30000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 14:22:07', '2018-05-24/TESTER/00018', 'Test pengisian saldo deposit', 'DB', '7000.30', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 14:30:37', '2018-05-24/TESTER/000180', 'Test pengisian saldo deposit', 'DB', '7000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 11:02:32', '2018-05-24/TESTER/0009', 'Test penarikan deposit', 'CR', '20000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 11:02:44', '2018-05-24/TESTER/00091', 'Test penarikan deposit', 'CR', '5000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-05-25 11:02:55', '2018-05-24/TESTER/00092', 'Test penarikan deposit', 'CR', '1500.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-05 17:49:46', '5b166b1d1a6386-10308965', 'Test debet saldo dari app', 'DB', '18000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-06 03:50:49', '5b16f7887cb6f2-36348758', 'Tester penarikan deposit', 'CR', '9000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-06 03:51:31', '5b16f7a9cffad8-53787386', 'Tester topup 50rb', 'DB', '50000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-06 14:10:58', '5b1788b6082d67-41460782', 'test validasi', 'DB', '33000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-06 17:07:16', '5b178c26e86712-56092482', 'Tester done', 'DB', '9000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-06 17:07:48', '5b17b25652d4c2-56373906', 'Penarikan ', 'CR', '9000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('a', '2018-06-06 18:43:12', '5b17c8099c10d4-21739829', 'a', 'DB', '1.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-29 13:14:03', '5b35cdf7697b67-26794438', 'Penarikan tester', 'CR', '9500.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-29 13:15:02', '5b35ce2bde93c7-72863953', 'tester lagi', 'DB', '10000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-29 18:22:48', '5b36165baba959-28039382', 'Test transaksi debet', 'DB', '30000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-06-29 18:57:49', '5b361ebd29d079-13160068', 'Pembayaran transaksi Waybill AGT3063424567', 'CR', '2000.00', '');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-07-02 13:05:10', '5b39c096d94048-88573402', 'Pembayaran transaksi Waybill AGT1018356469', 'CR', '2000.00', '');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-07-02 15:56:30', '5b39e8bedc4061-49698704', 'Pembayaran transaksi Waybill AGT3698630315', 'CR', '2000.00', '');
INSERT INTO `deposit_mutation` VALUES ('reslim', '2018-07-06 02:42:07', '5b3e747152de71-66322270', 'test penarikan', 'CR', '4000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('alfian', '2018-07-09 02:55:22', '5b426c153663f6-33718438', 'Topup Saldo 100000', 'DB', '100000.00', 'reslim');
INSERT INTO `deposit_mutation` VALUES ('alfian', '2018-07-09 02:57:10', '5b426c9642e2b8-49339927', 'Payment transaction Waybill AGT2014024565', 'CR', '2000.00', '');
INSERT INTO `deposit_mutation` VALUES ('alfian', '2018-07-09 18:26:55', '5b43467fda3bf3-23997260', 'Pembayaran transaksi Waybill AGT3188958511', 'CR', '2000.00', '');

-- ----------------------------
-- Table structure for imagehoster_data
-- ----------------------------
DROP TABLE IF EXISTS `imagehoster_data`;
CREATE TABLE `imagehoster_data` (
  `ID` varchar(20) NOT NULL,
  `ClientID` varchar(20) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Link` varchar(255) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Size` double DEFAULT NULL,
  `Width` double DEFAULT NULL,
  `Height` double DEFAULT NULL,
  `Data` text NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`,`ClientID`),
  KEY `Title` (`Title`) USING BTREE,
  KEY `Created_by` (`Created_by`),
  KEY `Created_at` (`Created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of imagehoster_data
-- ----------------------------
INSERT INTO `imagehoster_data` VALUES ('0oDhigu', '', 'Monster Party', 'https://i.imgur.com/0oDhigu.jpg', 'image/jpeg', '9563', '182', '268', '{\"id\":\"0oDhigu\",\"title\":\"Monster Party\",\"description\":\"Incredible Boss...\",\"datetime\":1542302738,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":9563,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"68FZL1YPqFTJkqy\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/0oDhigu.jpg\"}', '2018-11-16 00:21:59', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('52HXUBf', '', 'Gun City', 'https://i.imgur.com/52HXUBf.jpg', 'image/jpeg', '7331', '182', '268', '{\"id\":\"52HXUBf\",\"title\":\"Gun City\",\"description\":\"Tester saja bang\",\"datetime\":1542302099,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":7331,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"OUYbbPWuQ5UJ4p4\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/52HXUBf.jpg\"}', '2018-11-16 00:11:20', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('5hDyDTq', '', null, 'https://i.imgur.com/5hDyDTq.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"5hDyDTq\",\"title\":null,\"description\":null,\"datetime\":1541666143,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"4tRIm04k2qVghQJ\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/5hDyDTq.jpg\"}', '2018-11-08 15:32:03', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('7cE8Y6l', 'a94c8d5890af13e', null, 'https://i.imgur.com/7cE8Y6l.jpg', 'image/jpeg', '86871', '700', '990', '{\"id\":\"7cE8Y6l\",\"title\":null,\"description\":null,\"datetime\":1541648858,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":700,\"height\":990,\"size\":86871,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"ZHhzG0AuuSgCNfo\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/7cE8Y6l.jpg\"}', '2018-11-08 10:43:58', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('7FFdLf5', '', 'Neko Samurai', 'https://i.imgur.com/7FFdLf5.jpg', 'image/jpeg', '12005', '182', '268', '{\"id\":\"7FFdLf5\",\"title\":\"Neko Samurai\",\"description\":null,\"datetime\":1542302428,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":12005,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"f54ZA3bve1JIqVs\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/7FFdLf5.jpg\"}', '2018-11-16 00:16:49', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('b01lO2c', 'a94c8d5890af13e', null, 'https://i.imgur.com/b01lO2c.jpg', 'image/jpeg', '84480', '740', '1054', '{\"id\":\"b01lO2c\",\"title\":null,\"description\":null,\"datetime\":1541648875,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":740,\"height\":1054,\"size\":84480,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"nqFkHYfl7aBXRGV\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/b01lO2c.jpg\"}', '2018-11-08 10:44:15', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('bdGCMdD', '', 'Meet Sunset', 'https://i.imgur.com/bdGCMdD.jpg', 'image/jpeg', '10239', '182', '268', '{\"id\":\"bdGCMdD\",\"title\":\"Meet Sunset\",\"description\":null,\"datetime\":1542302608,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":10239,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"ksXW1dI6zkd6bbB\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/bdGCMdD.jpg\"}', '2018-11-16 00:19:49', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('bHd8j82', '', null, 'https://i.imgur.com/bHd8j82.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"bHd8j82\",\"title\":null,\"description\":null,\"datetime\":1541667156,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"6ZZ8iDbiynGIvak\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/bHd8j82.jpg\"}', '2018-11-08 15:48:55', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('ERIlfOC', '', null, 'https://i.imgur.com/ERIlfOC.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"ERIlfOC\",\"title\":null,\"description\":null,\"datetime\":1541667929,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"MIcA9DOtL5vAcNi\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/ERIlfOC.jpg\"}', '2018-11-08 16:01:49', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('ffGHSFJ', '', null, 'https://i.imgur.com/ffGHSFJ.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"ffGHSFJ\",\"title\":null,\"description\":null,\"datetime\":1541665385,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"Mn7FlEw2RkRjb4V\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/ffGHSFJ.jpg\"}', '2018-11-08 15:19:24', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('IrQ3w5y', 'a94c8d5890af13e', null, 'https://i.imgur.com/IrQ3w5y.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"IrQ3w5y\",\"title\":null,\"description\":null,\"datetime\":1541668731,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"wCcZMXxXcg6y3xK\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/IrQ3w5y.jpg\"}', '2018-11-08 16:15:11', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('Jp4VLwM', '', null, 'https://i.imgur.com/Jp4VLwM.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"Jp4VLwM\",\"title\":null,\"description\":null,\"datetime\":1541668023,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"TgbbAttYryf5qnr\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/Jp4VLwM.jpg\"}', '2018-11-08 16:03:23', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('jzrxRSc', '', null, 'https://i.imgur.com/jzrxRSc.jpg', 'image/jpeg', '8582', '182', '268', '{\"id\":\"jzrxRSc\",\"title\":null,\"description\":null,\"datetime\":1542301932,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":8582,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"N4inxnTzzwfpqAO\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/jzrxRSc.jpg\"}', '2018-11-16 00:08:33', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('kyrn71B', 'a94c8d5890af13e', 'Bed-Rella (2016)', 'https://i.imgur.com/kyrn71B.jpg', 'image/jpeg', '94077', '740', '1055', '{\"id\":\"kyrn71B\",\"title\":\"Bed-Rella (2016)\",\"description\":null,\"datetime\":1541648920,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":740,\"height\":1055,\"size\":94077,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"e6Et9fOkzo2LOa4\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/kyrn71B.jpg\"}', '2018-11-08 10:44:59', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('Oc8Zqky', '', null, 'https://i.imgur.com/Oc8Zqky.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"Oc8Zqky\",\"title\":null,\"description\":null,\"datetime\":1541667184,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"IP7afsxVbcooMZY\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/Oc8Zqky.jpg\"}', '2018-11-08 15:49:24', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('OssEdUt', '', null, 'https://i.imgur.com/OssEdUt.jpg', 'image/jpeg', '8165', '182', '268', '{\"id\":\"OssEdUt\",\"title\":null,\"description\":null,\"datetime\":1542301879,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":8165,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"1mKblxMy15x5KPz\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/OssEdUt.jpg\"}', '2018-11-16 00:07:40', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('RWoOEeh', '', 'Forget Me Not', 'https://i.imgur.com/RWoOEeh.jpg', 'image/jpeg', '11788', '182', '268', '{\"id\":\"RWoOEeh\",\"title\":\"Forget Me Not\",\"description\":null,\"datetime\":1542302245,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":11788,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"YAnQ3Hj9uzOy8GP\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/RWoOEeh.jpg\"}', '2018-11-16 00:13:46', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('t8N77ue', '', null, 'https://i.imgur.com/t8N77ue.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"t8N77ue\",\"title\":null,\"description\":null,\"datetime\":1541666905,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"QXgo3YSQg2v5us4\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/t8N77ue.jpg\"}', '2018-11-08 15:44:44', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('venvdnI', '', null, 'https://i.imgur.com/venvdnI.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"venvdnI\",\"title\":null,\"description\":null,\"datetime\":1541665444,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"DtTC43cToKPrs91\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/venvdnI.jpg\"}', '2018-11-08 15:20:23', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('Vm2F4n9', '', 'Reuni', 'https://i.imgur.com/Vm2F4n9.jpg', 'image/jpeg', '11609', '182', '268', '{\"id\":\"Vm2F4n9\",\"title\":\"Reuni\",\"description\":\"Sekolah\",\"datetime\":1542302681,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":182,\"height\":268,\"size\":11609,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"jk5ruRG9VUh6ujH\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/Vm2F4n9.jpg\"}', '2018-11-16 00:21:02', 'reslim', null, null, null);
INSERT INTO `imagehoster_data` VALUES ('XdQLi80', 'a94c8d5890af13e', null, 'https://i.imgur.com/XdQLi80.jpg', 'image/jpeg', '14828', '230', '329', '{\"id\":\"XdQLi80\",\"title\":null,\"description\":null,\"datetime\":1541667774,\"type\":\"image\\/jpeg\",\"animated\":false,\"width\":230,\"height\":329,\"size\":14828,\"views\":0,\"bandwidth\":0,\"vote\":null,\"favorite\":false,\"nsfw\":null,\"section\":null,\"account_url\":null,\"account_id\":0,\"is_ad\":false,\"in_most_viral\":false,\"has_sound\":false,\"tags\":[],\"ad_type\":0,\"ad_url\":\"\",\"in_gallery\":false,\"deletehash\":\"tXbqeeUA2oNtjEl\",\"name\":\"\",\"link\":\"https:\\/\\/i.imgur.com\\/XdQLi80.jpg\"}', '2018-11-08 15:59:13', 'reslim', null, null, null);

-- ----------------------------
-- Table structure for invoice_data
-- ----------------------------
DROP TABLE IF EXISTS `invoice_data`;
CREATE TABLE `invoice_data` (
  `InvoiceID` varchar(20) NOT NULL,
  `From_name` varchar(50) NOT NULL,
  `From_name_company` varchar(50) DEFAULT NULL,
  `From_address` varchar(255) NOT NULL,
  `From_phone` varchar(15) NOT NULL,
  `From_fax` varchar(15) DEFAULT NULL,
  `From_email` varchar(50) DEFAULT NULL,
  `From_website` varchar(50) DEFAULT NULL,
  `To_name` varchar(50) NOT NULL,
  `To_name_company` varchar(50) DEFAULT NULL,
  `To_address` varchar(255) NOT NULL,
  `To_phone` varchar(15) NOT NULL,
  `To_fax` varchar(15) DEFAULT NULL,
  `To_email` varchar(50) DEFAULT NULL,
  `To_website` varchar(50) DEFAULT NULL,
  `Custom_id` varchar(1000) DEFAULT NULL,
  `Custom_field` text,
  `Data_table` text NOT NULL,
  `Total_sub` decimal(20,2) NOT NULL,
  `Total` decimal(20,2) NOT NULL,
  `Term` int(11) NOT NULL,
  `Signature` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`InvoiceID`),
  KEY `From` (`From_name`,`From_name_company`),
  KEY `To` (`To_name`,`To_name_company`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `Custom_id` (`Custom_id`(767))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of invoice_data
-- ----------------------------
INSERT INTO `invoice_data` VALUES ('CGK201810310001', 'M ABD AZIZ ALFIAN', 'CAP Express', 'Jl. I Gusti Ngurah Rai Blok 1J No. 09\nKlender Jakarta Timur\nDKI Jakarta\nIndonesia ', '021', '021', 'cs@tkd.co.id', 'localhost.com', 'BUDI', 'PT, MAJU MUNDUR', 'Jakarta', '02112345', '', 'majumundur@gmail.com', '', '{\"BranchID\":\"CGK\",\"CustomerID\":\"CC1406593391\"}', '{\"Tax_rate\":\"1\",\"Tax_total\":\"500.00\",\"Bank_name\":\"BCA\",\"Bank_account_name\":\"M ABD AZIZ ALFIAN\",\"Bank_account_no\":\"12\",\"Bank_address\":\"\"}', '[{\"date\":\"2018-10-31\",\"po\":\"455765\",\"desc\":\"Sesuai dengan PO yang tertera\",\"qty\":\"1\",\"amount\":\"10000\",\"total\":\"10000\"},{\"date\":\"2018-10-31\",\"po\":\"455771\",\"desc\":\"Sesuai dengan PO yang tertera\",\"qty\":\"1\",\"amount\":\"25000\",\"total\":\"25000\"},{\"date\":\"2018-12-05\",\"po\":\"424131\",\"desc\":\"Penambahan item sesuai email\",\"qty\":\"1\",\"amount\":\"15000\",\"total\":\"15000\"}]', '50000.00', '50500.00', '14', 'M ABD AZIZ ALFIAN', '35', '2018-10-31 12:11:07', 'reslim', '2018-12-03 04:51:47', 'reslim', '2018-12-03 04:51:47');

-- ----------------------------
-- Table structure for log_data
-- ----------------------------
DROP TABLE IF EXISTS `log_data`;
CREATE TABLE `log_data` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data
-- ----------------------------
INSERT INTO `log_data` VALUES ('1', '2018-04-20 01:51:09', 'CGS1730306762', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('2', '2018-04-20 01:55:01', 'CGS1742420858', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('3', '2018-04-20 14:26:32', 'CGS3293109346', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('4', '2018-04-20 14:27:20', 'CGS1635155468', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('5', '2018-04-20 17:38:49', 'CGS1730306762', 'Transaksi pengiriman telah dibatalkan', '47', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('6', '2018-04-20 17:44:10', 'CGS1635155468', 'Barang telah diterima oleh: BUDI (AYAH)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('7', '2018-04-20 17:47:00', 'CGS1635155468', 'Barang telah diterima oleh: BUDI (AYAH)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('8', '2018-04-20 17:58:37', 'CGS1742420858', 'Alamat tidak ketemu', '19', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('9', '2018-04-20 17:59:28', 'CGS1742420858', 'Barang telah diterima oleh: RETNO (ISTRI)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('10', '2018-04-20 18:00:45', 'CGS2002930010', 'Sedang dalam proses retur ke origin', '53', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('11', '2018-04-24 13:35:15', 'CGS0765129222', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('12', '2018-04-24 13:35:55', 'CGS2282995794', 'Menunggu proses pengiriman', '27', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('13', '2018-04-24 14:36:07', 'CGS0765129222', 'Barang telah diterima oleh: INDAH PRAMESWARI (KAKAK)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('14', '2018-04-24 18:59:31', 'CGS3289786999', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('15', '2018-04-24 19:11:47', 'CGS3618295463', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('16', '2018-04-24 19:12:39', 'CGS3311404066', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('17', '2018-04-24 19:18:19', 'CGS1819229094', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('18', '2018-04-24 19:37:15', 'CGS3970334028', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('19', '2018-04-25 12:16:06', 'CGS0050675070', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('20', '2018-04-25 12:33:49', 'CGS3881934264', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('21', '2018-04-25 13:23:24', 'CGS1238441191', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('22', '2018-04-26 13:22:26', 'CGS1045330882', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('23', '2018-04-26 17:26:48', 'CGS3587711408', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('24', '2018-04-30 17:17:30', 'CGS3970334028', 'Transaksi pengiriman telah dibatalkan', '47', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('25', '2018-05-02 01:32:11', 'CGS0050675070', 'Alamat tidak ketemu', '19', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('26', '2018-05-02 01:35:14', 'CGS0050675070', 'antaran kedua gagal', '19', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('27', '2018-05-02 01:35:47', 'CGS0050675070', 'Antaran ketiga ditolak oleh security', '19', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('28', '2018-05-02 01:39:06', 'CGS0050675070', 'Barang telah diterima oleh: HARTONO (STAFF)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('29', '2018-05-02 01:44:33', 'CGS3781437160', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('30', '2018-05-02 02:00:33', 'CGS3613579852', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('31', '2018-05-02 02:01:14', 'CGS3613579852', 'Barang di retur sesuai permintaan penerima', '53', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('32', '2018-05-02 03:23:20', 'CGS2512214945', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('33', '2018-05-02 03:24:43', 'CGS2512214945', 'Barang telah diterima oleh: RANI (YBS)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('34', '2018-05-05 02:17:39', 'CGS3781437160', 'Transaksi pengiriman telah dibatalkan', '47', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('35', '2018-05-05 02:21:34', 'CGS0396713243', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('36', '2018-05-05 02:22:18', 'CGS0396713243', 'Alamat Tidak Ketemu', '19', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('37', '2018-05-05 04:09:00', 'CGS1199661389', 'Menunggu proses pengiriman', '29', 'xsilent', null, null, null);
INSERT INTO `log_data` VALUES ('38', '2018-05-05 04:10:05', 'CGS1199661389', 'Alamat tidak ketemu', '19', 'xsilent', null, null, null);
INSERT INTO `log_data` VALUES ('39', '2018-05-05 04:11:06', 'CGS1199661389', 'Barang telah diterima oleh: AGUNG (SAUDARA)', '41', 'xsilent', null, null, null);
INSERT INTO `log_data` VALUES ('40', '2018-05-05 04:16:45', 'CGS2434606192', 'Menunggu proses pengiriman', '29', 'xsilent', null, null, null);
INSERT INTO `log_data` VALUES ('41', '2018-05-07 17:29:42', 'CGS1428037464', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('42', '2018-05-14 17:21:02', 'CGK1662316569', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('43', '2018-05-14 17:23:41', 'CGK2127075927', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('44', '2018-05-14 17:42:02', 'CGK3727239811', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('45', '2018-05-21 09:54:25', 'CGK1662316569', 'Barang telah diterima oleh: ISWANDI (SECURITY)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('46', '2018-05-21 12:25:38', 'CGK3165277852', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('47', '2018-07-06 03:47:04', 'CGK2127075927', 'Barang telah diterima oleh: GOGON (SECURITY)', '41', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('48', '2018-08-10 13:27:22', 'CGK0282327482', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);
INSERT INTO `log_data` VALUES ('49', '2018-08-27 14:31:20', 'CGK3677011223', 'Menunggu proses pengiriman', '29', 'reslim', null, null, null);

-- ----------------------------
-- Table structure for log_data_pod
-- ----------------------------
DROP TABLE IF EXISTS `log_data_pod`;
CREATE TABLE `log_data_pod` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `BranchID` varchar(10) DEFAULT NULL,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `WayBill` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Recipient` varchar(50) DEFAULT NULL,
  `Relation` varchar(255) DEFAULT NULL,
  `DeliveryID` varchar(15) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `ItemID` (`ItemID`),
  KEY `WayBill` (`WayBill`) USING BTREE,
  KEY `BranchID` (`BranchID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_pod
-- ----------------------------
INSERT INTO `log_data_pod` VALUES ('1', 'cgs', '2018-04-20 17:44:10', 'CGS1635155468', 'Barang telah diterima oleh:', 'BUDI', 'AYAH', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('2', 'cgs', '2018-04-20 17:47:00', 'CGS1635155468', 'Barang telah diterima oleh:', 'BUDI', 'AYAH', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('3', 'cgs', '2018-04-20 17:58:37', 'CGS1742420858', 'Alamat tidak ketemu', '', '', '', '19', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('4', 'cgs', '2018-04-20 17:59:28', 'CGS1742420858', 'Barang telah diterima oleh:', 'RETNO', 'Istri', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('5', 'cgs', '2018-04-20 18:00:45', 'CGS2002930010', 'Sedang dalam proses retur ke origin', '', '', '', '53', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('6', 'cgs', '2018-04-24 14:36:07', 'CGS0765129222', 'Barang telah diterima oleh:', 'INDAH PRAMESWARI', 'KAKAK', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('7', 'cgs', '2018-05-02 01:32:11', 'CGS0050675070', 'Alamat tidak ketemu', '', '', '', '19', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('8', 'cgs', '2018-05-02 01:35:14', 'CGS0050675070', 'antaran kedua gagal', '', '', '', '19', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('9', 'cgs', '2018-05-02 01:35:47', 'CGS0050675070', 'Antaran ketiga ditolak oleh security', '', '', '', '19', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('10', 'cgs', '2018-05-02 01:39:06', 'CGS0050675070', 'Barang telah diterima oleh:', 'HARTONO', 'STAFF', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('11', 'cgs', '2018-05-02 02:01:14', 'CGS3613579852', 'Barang di retur sesuai permintaan penerima', '', '', '', '53', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('12', 'cgs', '2018-05-02 03:24:43', 'CGS2512214945', 'Barang telah diterima oleh:', 'RANI', 'YBS', '', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('13', 'cgs', '2018-05-05 02:22:18', 'CGS0396713243', 'Alamat Tidak Ketemu', '', '', '', '19', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('14', 'cgs', '2018-05-05 04:10:05', 'CGS1199661389', 'Alamat tidak ketemu', '', '', 'CGS1199661389', '19', 'xsilent', null, null, null);
INSERT INTO `log_data_pod` VALUES ('15', 'cgs', '2018-05-05 04:11:06', 'CGS1199661389', 'Barang telah diterima oleh:', 'AGUNG', 'SAUDARA', 'CGS1199661389', '41', 'xsilent', null, null, null);
INSERT INTO `log_data_pod` VALUES ('16', 'cgk', '2018-05-21 09:54:25', 'CGK1662316569', 'Barang telah diterima oleh:', 'ISWANDI', 'SECURITY', 'CGK1662316569', '41', 'reslim', null, null, null);
INSERT INTO `log_data_pod` VALUES ('17', 'cgk', '2018-07-06 03:47:04', 'CGK2127075927', 'Barang telah diterima oleh:', 'GOGON', 'SECURITY', 'CGK2127075927', '41', 'reslim', null, null, null);

-- ----------------------------
-- Table structure for log_data_void
-- ----------------------------
DROP TABLE IF EXISTS `log_data_void`;
CREATE TABLE `log_data_void` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_void
-- ----------------------------
INSERT INTO `log_data_void` VALUES ('1', '2018-04-20 17:38:49', 'CGS1730306762', 'Duit Kurang', '47', 'reslim', null, null, null);
INSERT INTO `log_data_void` VALUES ('2', '2018-04-30 17:17:30', 'CGS3970334028', 'Data input salah', '47', 'reslim', null, null, null);
INSERT INTO `log_data_void` VALUES ('3', '2018-05-05 02:17:39', 'CGS3781437160', 'Customer tidak jadi kirim barang', '47', 'reslim', null, null, null);

-- ----------------------------
-- Table structure for mas_insurance
-- ----------------------------
DROP TABLE IF EXISTS `mas_insurance`;
CREATE TABLE `mas_insurance` (
  `InsuranceID` int(11) NOT NULL AUTO_INCREMENT,
  `Insurance` varchar(255) NOT NULL,
  `Premium` decimal(10,0) NOT NULL,
  `Min_Premium` decimal(10,0) NOT NULL,
  PRIMARY KEY (`InsuranceID`),
  KEY `InsuranceID` (`InsuranceID`),
  KEY `Insurance` (`Insurance`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_insurance
-- ----------------------------

-- ----------------------------
-- Table structure for mas_mode
-- ----------------------------
DROP TABLE IF EXISTS `mas_mode`;
CREATE TABLE `mas_mode` (
  `ModeID` int(11) NOT NULL AUTO_INCREMENT,
  `Mode` varchar(20) NOT NULL,
  PRIMARY KEY (`ModeID`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_mode
-- ----------------------------
INSERT INTO `mas_mode` VALUES ('1', 'Air Freight');
INSERT INTO `mas_mode` VALUES ('2', 'Road Freight');
INSERT INTO `mas_mode` VALUES ('3', 'Sea Freight');

-- ----------------------------
-- Table structure for mas_payment
-- ----------------------------
DROP TABLE IF EXISTS `mas_payment`;
CREATE TABLE `mas_payment` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `Payment` varchar(50) NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `PaymentID` (`PaymentID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_payment
-- ----------------------------
INSERT INTO `mas_payment` VALUES ('1', 'Cash');
INSERT INTO `mas_payment` VALUES ('2', 'Cheque');
INSERT INTO `mas_payment` VALUES ('3', 'Cod');
INSERT INTO `mas_payment` VALUES ('4', 'Credit');
INSERT INTO `mas_payment` VALUES ('5', 'Transfer Bank');
INSERT INTO `mas_payment` VALUES ('6', 'Transfer Form');

-- ----------------------------
-- Table structure for mas_relation
-- ----------------------------
DROP TABLE IF EXISTS `mas_relation`;
CREATE TABLE `mas_relation` (
  `RelationID` int(11) NOT NULL AUTO_INCREMENT,
  `Relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RelationID`),
  KEY `RelationID` (`RelationID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_relation
-- ----------------------------
INSERT INTO `mas_relation` VALUES ('1', 'YBS');
INSERT INTO `mas_relation` VALUES ('2', 'AYAH');
INSERT INTO `mas_relation` VALUES ('3', 'IBU');
INSERT INTO `mas_relation` VALUES ('4', 'ANAK');
INSERT INTO `mas_relation` VALUES ('5', 'KAKAK');
INSERT INTO `mas_relation` VALUES ('6', 'ADIK');
INSERT INTO `mas_relation` VALUES ('7', 'KAKEK');
INSERT INTO `mas_relation` VALUES ('8', 'NENEK');
INSERT INTO `mas_relation` VALUES ('9', 'SAUDARA');
INSERT INTO `mas_relation` VALUES ('10', 'PEMBANTU');
INSERT INTO `mas_relation` VALUES ('11', 'SECURITY');
INSERT INTO `mas_relation` VALUES ('12', 'TETANGGA');
INSERT INTO `mas_relation` VALUES ('13', 'SUAMI');
INSERT INTO `mas_relation` VALUES ('14', 'ISTRI');
INSERT INTO `mas_relation` VALUES ('15', 'TEMAN');
INSERT INTO `mas_relation` VALUES ('16', 'CS');
INSERT INTO `mas_relation` VALUES ('17', 'STAFF');
INSERT INTO `mas_relation` VALUES ('18', 'FO');

-- ----------------------------
-- Table structure for sys_company
-- ----------------------------
DROP TABLE IF EXISTS `sys_company`;
CREATE TABLE `sys_company` (
  `BranchID` varchar(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Owner` varchar(50) DEFAULT NULL,
  `PIC` varchar(50) DEFAULT NULL,
  `TIN` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BranchID`),
  KEY `BranchID` (`BranchID`),
  KEY `StatusID` (`StatusID`),
  KEY `Name` (`Name`),
  KEY `Phone` (`Phone`),
  KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_company
-- ----------------------------
INSERT INTO `sys_company` VALUES ('amq', 'MATARAM', 'MATARAM', '123', '123', '', 'mardi', '', '', '1', '2018-08-24 11:50:55', 'reslim', null, null);
INSERT INTO `sys_company` VALUES ('cgb', 'Jakarta Barat', 'Jakarta Barat', '1', '', '', '', '', '', '1', '2018-08-24 11:51:38', 'reslim', '2018-08-25 02:44:09', 'reslim');
INSERT INTO `sys_company` VALUES ('cgk', 'Jakarta', 'Jl. I Gusti Ngurah Rai Blok 1J No. 09\nKlender Jakarta Timur\nDKI Jakarta\nIndonesia ', '021', '021', 'cs@tkd.co.id', 'Subagyo', 'Damar Kumboro', '12345', '1', '2018-03-16 05:59:16', 'reslim', '2018-10-23 19:30:58', 'reslim');
INSERT INTO `sys_company` VALUES ('cgp', 'Jakarta Pusat', 'Jakarta Pusat', '1', '', '', '', '', '', '1', '2018-08-24 11:51:16', 'reslim', '2018-08-25 02:43:49', 'reslim');
INSERT INTO `sys_company` VALUES ('cgs', 'Jakarta Selatan', 'Jl. Manggarai Jakarta', '021745678', '021', 'cs@cap-express.co.id', 'Turiman', 'Aji', '12345', '1', '2018-03-16 06:16:17', 'reslim', '2018-05-21 09:53:29', 'reslim');
INSERT INTO `sys_company` VALUES ('cgt', 'Jakarta Timur', 'Jl. I Gusti Ngurah Rai No. 1J Lt. 2 Klender Jakarta Timur\n(Ruko samping Mall Citra Klender)', '0215677588', '021765899', 'cgt@cap-express.co.id', 'Andi', 'Bagus', '123123231', '1', '2018-05-04 05:41:53', 'reslim', '2018-08-24 11:50:28', 'reslim');
INSERT INTO `sys_company` VALUES ('cgu', 'Jakarta Utara', 'Jakarta Utara', '1', '', '', '', '', '', '1', '2018-08-24 11:52:11', 'reslim', null, null);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `Username` varchar(50) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('abc', 'cgs', '42', '2018-03-16 08:17:42', 'reslim', '2018-03-16 08:19:58', 'reslim');
INSERT INTO `sys_user` VALUES ('reslim', 'cgk', '1', '2018-03-16 08:06:02', 'reslim', '2018-05-14 17:19:36', 'reslim');
INSERT INTO `sys_user` VALUES ('tester10', 'cgk', '1', '2018-07-05 12:32:58', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester11', 'cgk', '1', '2018-03-20 03:45:43', 'reslim', '2018-03-21 02:51:14', 'reslim');
INSERT INTO `sys_user` VALUES ('tester12', 'cgs', '1', '2018-07-05 12:33:27', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester2', 'cgk', '1', '2018-07-05 12:29:53', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester3', 'cgk', '1', '2018-07-05 12:30:37', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester4', 'cgs', '1', '2018-07-05 12:30:57', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester5', 'cgs', '1', '2018-07-05 12:31:21', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester6', 'cgs', '1', '2018-07-05 12:31:46', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester7', 'cgs', '1', '2018-07-05 12:32:01', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester8', 'cgs', '1', '2018-07-05 12:32:14', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('tester9', 'cgs', '1', '2018-07-05 12:32:26', 'reslim', null, null);
INSERT INTO `sys_user` VALUES ('xsilent', 'cgs', '1', '2018-03-16 07:51:16', 'reslim', '2018-03-21 02:51:26', 'reslim');
INSERT INTO `sys_user` VALUES ('xsilents', 'cgk', '42', '2018-03-19 08:20:21', 'reslim', '2018-03-19 13:47:09', 'xsilent');

-- ----------------------------
-- Table structure for tariff_data
-- ----------------------------
DROP TABLE IF EXISTS `tariff_data`;
CREATE TABLE `tariff_data` (
  `BranchID` varchar(10) NOT NULL,
  `Kabupaten` varchar(255) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  `Estimasi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`BranchID`,`Kabupaten`,`ModeID`),
  KEY `BranchID` (`BranchID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_data
-- ----------------------------
INSERT INTO `tariff_data` VALUES ('cgk', 'Bogor', '2', '20000', '1000', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Depok', '2', '25000', '1500', '25', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jakarta Barat', '2', '15000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jakarta Timur', '1', '75000', '75000', '1', '1');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jakarta Timur', '2', '30000', '1500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jakarta Timur', '3', '20000', '1500', '10', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'Jakarta Utara', '2', '10000', '1000', '7', '3');
INSERT INTO `tariff_data` VALUES ('cgk', 'Sukabumi', '2', '40000', '3000', '5', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'Surabaya', '1', '80000', '80000', '1', '2');
INSERT INTO `tariff_data` VALUES ('cgk', 'Surabaya', '2', '25000', '1500', '5', '5');
INSERT INTO `tariff_data` VALUES ('cgk', 'Surabaya', '3', '150000', '150000', '1', '7');
INSERT INTO `tariff_data` VALUES ('cgs', 'Bogor', '2', '25000', '1500', '5', '3');
INSERT INTO `tariff_data` VALUES ('cgs', 'Depok', '2', '30000', '1500', '25', '3');
INSERT INTO `tariff_data` VALUES ('cgs', 'Jakarta Barat', '2', '25000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgs', 'Jakarta Selatan', '2', '25000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgs', 'Jakarta Timur', '1', '25000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgs', 'Jakarta Timur', '2', '25000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgs', 'Jakarta Timur', '3', '25000', '1500', '5', '2');
INSERT INTO `tariff_data` VALUES ('cgs', 'Tangerang', '2', '20000', '1500', '5', '5');

-- ----------------------------
-- Table structure for tariff_handling
-- ----------------------------
DROP TABLE IF EXISTS `tariff_handling`;
CREATE TABLE `tariff_handling` (
  `Kabupaten` varchar(50) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  PRIMARY KEY (`Kabupaten`,`ModeID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_handling
-- ----------------------------
INSERT INTO `tariff_handling` VALUES ('Depok', '2', '1500', '500', '25');
INSERT INTO `tariff_handling` VALUES ('Jakarta Barat', '2', '2000', '1500', '6');
INSERT INTO `tariff_handling` VALUES ('Jakarta Selatan', '2', '1500', '500', '5');
INSERT INTO `tariff_handling` VALUES ('Surabaya', '1', '20000', '20000', '1');
INSERT INTO `tariff_handling` VALUES ('Surabaya', '2', '2000', '500', '1');
INSERT INTO `tariff_handling` VALUES ('Surabaya', '3', '25000', '25000', '1');

-- ----------------------------
-- Table structure for transaction_waybill
-- ----------------------------
DROP TABLE IF EXISTS `transaction_waybill`;
CREATE TABLE `transaction_waybill` (
  `Waybill` varchar(20) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `DestID` varchar(10) NOT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Consignor_name` varchar(50) NOT NULL,
  `Consignor_alias` varchar(50) DEFAULT NULL,
  `Consignor_address` varchar(255) NOT NULL,
  `Consignor_phone` varchar(15) NOT NULL,
  `Consignor_fax` varchar(15) DEFAULT NULL,
  `Consignor_email` varchar(50) DEFAULT NULL,
  `ReferenceID` varchar(20) DEFAULT NULL,
  `Consignee_name` varchar(50) NOT NULL,
  `Consignee_attention` varchar(50) DEFAULT NULL,
  `Consignee_address` varchar(255) NOT NULL,
  `Consignee_phone` varchar(15) NOT NULL,
  `Consignee_fax` varchar(15) DEFAULT NULL,
  `ModeID` int(11) NOT NULL,
  `Instruction` varchar(255) DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Goods_data` varchar(1000) NOT NULL,
  `Goods_koli` decimal(5,0) NOT NULL,
  `Goods_value` decimal(10,0) NOT NULL,
  `Weight` decimal(7,2) NOT NULL,
  `Weight_real` decimal(7,2) NOT NULL,
  `Origin` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Estimation` varchar(7) NOT NULL,
  `Insurance_rate` decimal(7,2) NOT NULL,
  `Shipping_cost` decimal(10,0) NOT NULL,
  `Shipping_insurance` decimal(10,0) NOT NULL,
  `Shipping_packing` decimal(10,0) NOT NULL,
  `Shipping_forward` decimal(10,0) NOT NULL,
  `Shipping_handling` decimal(10,0) NOT NULL,
  `Shipping_surcharge` decimal(10,0) NOT NULL,
  `Shipping_admin` decimal(10,0) NOT NULL,
  `Shipping_discount` decimal(10,0) NOT NULL,
  `Shipping_cost_total` decimal(10,0) NOT NULL,
  `Tariff_kgp` decimal(10,0) NOT NULL,
  `Tariff_kgs` decimal(10,0) NOT NULL,
  `Tariff_kgp_min` decimal(4,0) NOT NULL,
  `Tariff_hkgp` decimal(10,0) NOT NULL,
  `Tariff_hkgs` decimal(10,0) NOT NULL,
  `Tariff_hkgp_min` decimal(4,0) NOT NULL,
  `PaymentID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Waybill`),
  KEY `Waybill` (`Waybill`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Consignor_name` (`Consignor_name`),
  KEY `Consignor_phone` (`Consignor_phone`),
  KEY `ReferenceID` (`ReferenceID`),
  KEY `Consignee_name` (`Consignee_name`),
  KEY `Consignee_phone` (`Consignee_phone`),
  KEY `ModeID` (`ModeID`),
  KEY `Destination` (`Destination`),
  KEY `PaymentID` (`PaymentID`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `BranchID` (`BranchID`),
  KEY `DestID` (`DestID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of transaction_waybill
-- ----------------------------
INSERT INTO `transaction_waybill` VALUES ('CGK0282327482', 'cgk', 'cgk', '', 'M ABD AZIZ ALFIAN', 'Fian', 'Jl. H. Taiman Ujung Blok EJ801 No. 08 Rt. 04 Rw. 06 Kel. Tengah Kec. Kramat Jati \nJakarta Timur 17540\nDKI Jakarta \nIndonesia', '083806075400', '021123457', 'aalfiann@gmail.com', '', 'Tika Amelia Pratiwi, S.E', 'Ibu Tika', 'Jl. Candi Lontar Wetan Blok 44i No. 02 Rt.4 Rw. 10 Kel. Manukan Kec. Tandes\nSurabaya 60185\nJawa Timur\nIndonesia', '083804209333', '0317406035', '2', 'Segera diantar karena barang digunakan untuk resepsi pernikahan', 'Satu set perlengkapan baju pernikahan', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"5\",\"volume\":\"0.00\",\"total\":\"5\"}]', '1', '50000000', '5.00', '5.00', 'Jakarta', 'Surabaya', '5', '0.00', '25000', '1000', '0', '0', '4000', '0', '0', '0', '26000', '25000', '1500', '5', '2000', '500', '1', '1', '29', '2018-08-10 13:27:22', 'reslim', null, null, '2018-08-10 13:27:22');
INSERT INTO `transaction_waybill` VALUES ('CGK1662316569', 'cgk', 'cgk', '', '1', '', '1', '1', '', '', '', '1', '', '1', '1', '', '2', '', '1', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Surabaya', '5', '0.00', '25000', '0', '0', '0', '2000', '0', '0', '0', '25000', '25000', '1500', '5', '2000', '500', '1', '1', '41', '2018-05-14 17:21:02', 'reslim', '2018-05-21 09:54:25', 'reslim', '2018-05-21 09:54:25');
INSERT INTO `transaction_waybill` VALUES ('CGK2127075927', 'cgk', 'cgk', '', 'Kartolo', '', 'Jakarta', '1', '', '', '', 'Budi', '', 'Surabaya', '1', '', '1', '', 'dokumen invoice', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Surabaya', '2', '0.00', '80000', '0', '0', '0', '20000', '0', '0', '0', '80000', '80000', '80000', '1', '20000', '20000', '1', '1', '41', '2018-05-14 17:23:41', 'reslim', '2018-07-06 03:47:04', 'reslim', '2018-07-06 03:47:04');
INSERT INTO `transaction_waybill` VALUES ('CGK3165277852', 'cgk', 'cgk', '', '1', '', '1', '1', '', '', '', '1', '', '1', '1', '', '2', '', '1', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Bogor', '3', '0.00', '20000', '0', '0', '0', '0', '0', '0', '0', '20000', '20000', '1000', '5', '0', '0', '0', '1', '29', '2018-05-21 12:25:38', 'reslim', null, null, '2018-05-21 12:25:38');
INSERT INTO `transaction_waybill` VALUES ('CGK3677011223', 'cgk', 'cgk', 'MM3511920434', 'M Abd Aziz Alfian', 'Fian', 'Jl. H. Taiman Ujung No.08 Rt.06 Rw.04 Kel. Tengah Kec. Kramat Jati Jakarta Timur DKI Jakarta 17540', '083806075400', '', 'aalfiann@gmail.com', '', 'Yunita', '', 'Jakarta', '1', '', '2', '', 'surat', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-08-27 14:31:20', 'reslim', null, null, '2018-08-27 14:31:20');
INSERT INTO `transaction_waybill` VALUES ('CGK3727239811', 'cgk', 'cgk', '', 'Basri', '', 'Jakarta', '0838', '', '', 'CGK/2018-05-14/0001', 'Irqa', '', 'Surabaya', '1', '', '2', '', 'Paket Seragam', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"20\",\"height\":\"20\",\"actual\":\"5\",\"volume\":\"2.00\",\"total\":\"5\"}]', '1', '0', '5.00', '5.00', 'Jakarta', 'Surabaya', '5', '0.00', '25000', '0', '0', '0', '4000', '0', '0', '0', '25000', '25000', '1500', '5', '2000', '500', '1', '1', '29', '2018-05-14 17:42:02', 'reslim', null, null, '2018-05-14 17:42:02');
INSERT INTO `transaction_waybill` VALUES ('CGS0050675070', 'cgs', 'cgs', '', 'Budi Pratama', '', 'Pamulang Tangerang', '081517178989', '', 'budi@go.com', '', 'Rendi', '', 'Jl. Manukan Kulon 4 jakarta selatan', '7406035', '', '2', 'Segera Diantar ya bos', 'Barang Pecah Belah', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"40\",\"actual\":\"2\",\"volume\":\"6.00\",\"total\":\"6.00\"}]', '1', '2000000', '6.00', '6.00', 'Jakarta', 'Jakarta Barat', '2', '0.02', '16500', '1000', '15000', '0', '2000', '0', '2000', '500', '34000', '15000', '1500', '5', '2000', '1500', '6', '1', '41', '2018-04-25 01:16:06', 'reslim', '2018-05-01 14:39:06', 'reslim', '2018-05-01 14:39:06');
INSERT INTO `transaction_waybill` VALUES ('CGS0396713243', 'cgs', 'cgs', '', 'Hari', 'Potter', 'Jakarta', '12312312', '', '', '', 'Rudi', 'Sugiarto', 'Jl. Pesona Khayangan no.19 Depok Jawa Barat Indonesia', '8989689797', '', '2', 'Segera Diantar', 'Dokumen invoice', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '30000000', '1.00', '1.00', 'Jakarta selatan', 'Jakarta Selatan', '2', '0.02', '25000', '6000', '0', '0', '1500', '0', '0', '0', '31000', '25000', '1500', '5', '1500', '500', '5', '1', '19', '2018-05-04 15:21:34', 'reslim', '2018-05-04 15:22:18', 'reslim', '2018-05-04 15:22:18');
INSERT INTO `transaction_waybill` VALUES ('CGS0765129222', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Jaya', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '25', '2000', '1500', '25', '1', '41', '2018-04-24 02:35:15', 'reslim', '2018-04-24 03:36:07', 'reslim', '2018-04-24 03:36:07');
INSERT INTO `transaction_waybill` VALUES ('CGS1045330882', 'cgs', 'cgk', '', '1', '', '1', '1', '', '', '', '1', '', '1', '1', '', '3', '', '1', '[{\"no\":\"1\",\"length\":\"200\",\"width\":\"300\",\"height\":\"400\",\"actual\":\"40\",\"volume\":\"24.00\",\"total\":\"40\"}]', '1', '100000000', '40.00', '40.00', 'Jakarta', 'Jakarta Barat', '2', '0.02', '67500', '20000', '1000000', '0', '53000', '0', '2000', '9500', '1080000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-26 02:22:26', 'reslim', null, null, '2018-04-26 02:22:26');
INSERT INTO `transaction_waybill` VALUES ('CGS1199661389', 'cgs', 'cgs', '', 'Yani', '', 'Jakarta', '1', '', '', '', 'Wahyu', '', 'Jl. Pesona Khayangan no. 01 Depok Jawa Barat', '0838', '', '2', 'Jangan dibanting', 'Parcel ', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"40\",\"actual\":\"2\",\"volume\":\"6.00\",\"total\":\"6.00\"}]', '1', '15000000', '6.00', '6.00', 'Jakarta selatan', 'Depok', '3', '0.02', '30000', '3000', '15000', '0', '1500', '0', '2000', '0', '50000', '30000', '1500', '25', '1500', '500', '25', '1', '41', '2018-05-05 04:09:00', 'xsilent', '2018-05-05 04:11:06', 'xsilent', '2018-05-05 04:11:06');
INSERT INTO `transaction_waybill` VALUES ('CGS1238441191', 'cgs', 'cgk', '', 'Bambang Priambodo', '', 'Jl. H. Pitang No. 20 RT. 06 RW. 04 Sukapura Cilincing Jakarta Utara ', '111111111111', '', '', '', 'Rohmatun Inayah', '', 'Jl. Jenderal Sudirman No. 140 blok 41 A RT. 06 RW. 08 Grogol Jakarta Barat', '222222222222', '', '2', 'Segera Diantar', 'Paket Sepatu dan Seragam Kerja', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"40\",\"height\":\"60\",\"actual\":\"5\",\"volume\":\"12.00\",\"total\":\"12.00\"}]', '1', '12000000', '12.00', '12.00', 'Jakarta', 'Jakarta Barat', '2', '0.02', '25500', '2400', '0', '0', '11000', '0', '0', '0', '27900', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-25 02:23:24', 'reslim', null, null, '2018-04-25 02:23:24');
INSERT INTO `transaction_waybill` VALUES ('CGS1428037464', 'cgs', 'cgk', '', '1', '', '1', '1', '', '', '', '1', '', '1', '1', '', '2', '', '1', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta selatan', 'Jakarta Barat', '2', '0.00', '25000', '0', '0', '0', '2000', '0', '0', '0', '25000', '25000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-05-07 17:29:41', 'reslim', null, null, '2018-05-07 17:29:41');
INSERT INTO `transaction_waybill` VALUES ('CGS1635155468', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '41', '2018-04-20 03:27:20', 'reslim', '2018-04-20 06:47:00', 'reslim', '2018-04-20 06:47:00');
INSERT INTO `transaction_waybill` VALUES ('CGS1730306762', 'cgs', '', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '47', '2018-04-19 14:51:09', 'reslim', '2018-04-20 06:38:49', 'reslim', '2018-04-20 06:38:49');
INSERT INTO `transaction_waybill` VALUES ('CGS1742420858', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '41', '2018-04-19 14:55:01', 'reslim', '2018-04-20 06:59:28', 'reslim', '2018-04-20 06:59:28');
INSERT INTO `transaction_waybill` VALUES ('CGS1819229094', 'cgs', 'cgk', '', '3', '', '3', '3', '', '', '', '3', '', '3', '3', '', '2', '', '3', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"3\",\"volume\":\"0.00\",\"total\":\"3\"}]', '1', '0', '3.00', '3.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-24 08:18:19', 'reslim', null, null, '2018-04-24 08:18:19');
INSERT INTO `transaction_waybill` VALUES ('CGS2002930010', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '53', '2018-04-19 14:48:00', 'xsilent', '2018-04-20 07:00:45', 'reslim', '2018-04-28 03:43:49');
INSERT INTO `transaction_waybill` VALUES ('CGS2269360771', 'cgs', '', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Surat Undangan', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '2', '0.02', '15000', '0', '0', '0', '0', '0', '2000', '0', '17000', '15000', '1500', '0', '2000', '1500', '0', '1', '27', '2018-04-19 06:20:22', 'xsilent', null, null, '2018-04-28 03:43:52');
INSERT INTO `transaction_waybill` VALUES ('CGS2282995794', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Jaya', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '25', '2000', '1500', '25', '1', '27', '2018-04-24 02:35:55', 'reslim', null, null, '2018-04-24 02:35:55');
INSERT INTO `transaction_waybill` VALUES ('CGS2434606192', 'cgs', 'cgs', '', 'Aryani', '', 'Jakarta', '123123', '', '', '', 'Gandhi', '', 'Depok Jawa Barat', '123213', '', '2', '', 'Surat Undangan', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta selatan', 'Depok', '3', '0.00', '30000', '0', '0', '0', '1500', '0', '0', '0', '30000', '30000', '1500', '25', '1500', '500', '25', '1', '29', '2018-05-05 04:16:45', 'xsilent', null, null, '2018-05-05 04:16:45');
INSERT INTO `transaction_waybill` VALUES ('CGS2512214945', 'cgs', 'cgs', '', 'Shantika', '', 'Jakarta', '0838', '', '', '', 'Rani', '', 'Grogol Jakarta Barat', '098989', '', '2', 'Segera diantar ya', 'Gitar Kayu akustik', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"4\",\"volume\":\"0.00\",\"total\":\"4\"}]', '1', '0', '4.00', '4.00', 'Jakarta selatan', 'Jakarta Barat', '2', '0.00', '25000', '0', '0', '0', '2000', '0', '0', '0', '25000', '25000', '1500', '5', '2000', '1500', '6', '1', '41', '2018-05-01 16:23:20', 'reslim', '2018-05-01 16:24:43', 'reslim', '2018-05-01 16:24:43');
INSERT INTO `transaction_waybill` VALUES ('CGS3289786999', 'cgs', 'cgk', '', '1', '', '1', '1', '', '', '', '1', '', '1', '1', '', '2', '', '1', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-24 07:59:31', 'reslim', null, null, '2018-04-24 07:59:31');
INSERT INTO `transaction_waybill` VALUES ('CGS3293109346', 'cgs', 'cgk', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '27', '2018-04-20 03:26:32', 'reslim', null, null, '2018-04-20 03:26:32');
INSERT INTO `transaction_waybill` VALUES ('CGS3311404066', 'cgs', 'cgk', '', '3', '', '3', '3', '', '', '', '3', '', '3', '3', '', '2', '', '3', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"3\",\"volume\":\"0.00\",\"total\":\"3\"}]', '1', '0', '3.00', '3.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-24 08:12:39', 'reslim', null, null, '2018-04-24 08:12:39');
INSERT INTO `transaction_waybill` VALUES ('CGS3587711408', 'cgs', 'cgk', '', 'Abdul', '', 'Jl. H. Taiman Ujung No.08 RT. 04 RW.06\nKel. Tengah Kec. Kramat Jati\nJakarta Timur - 14540\nIndonesia', '083806075400', '', '', '', 'Tika Amelia', '', 'Dsn. Cimpaheun No.245 RT. 02 RW. 10 \nKel. Tapos Kec. Tapos\nDepok 23323\nJawa Barat Indonesia', '083807409333', '', '2', 'MAKANAN HARUS SEGERA DIANTAR Karena takut basi', 'Barang Elektronik', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-26 06:26:48', 'reslim', null, null, '2018-04-26 06:26:48');
INSERT INTO `transaction_waybill` VALUES ('CGS3613579852', 'cgs', 'cgs', '', 'Indra', '', 'Jakarta selatan', '123', '', '', '', 'Surti', '', 'Grogol Jakarta Barat', '123123', '', '2', 'Segera diantar', 'Makanan Kering', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '1', '0', '1.00', '1.00', 'Jakarta selatan', 'Jakarta Barat', '2', '0.00', '25000', '0', '0', '0', '2000', '0', '0', '0', '25000', '25000', '1500', '5', '2000', '1500', '6', '1', '53', '2018-05-01 15:00:33', 'reslim', '2018-05-01 15:01:14', 'reslim', '2018-05-01 15:01:14');
INSERT INTO `transaction_waybill` VALUES ('CGS3618295463', 'cgs', 'cgk', '', '2', '2', '2', '2', '', '', '', '2', '', '2', '2', '', '2', '', '2', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"2\",\"volume\":\"0.00\",\"total\":\"2\"}]', '1', '0', '2.00', '2.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-24 08:11:47', 'reslim', null, null, '2018-04-24 08:11:47');
INSERT INTO `transaction_waybill` VALUES ('CGS3651240848', 'cgs', 'cgs', '', 'M Abd Aziz Alfian', 'PT. TKD Express', 'Jakarta', '083806075400', '', 'aalfiann@gmail.com', '', 'PT. Maju Kencang', 'Dewi Sartika', 'Jakarta Barat', '02112345', '', '2', 'Segera Diantar', 'Paket Sepatu', '[{\"no\":\"1\",\"length\":\"20\",\"width\":\"30\",\"height\":\"49\",\"actual\":\"1\",\"volume\":\"7.35\",\"total\":\"7.35\"}]', '1', '0', '8.00', '7.35', 'Jakarta', 'Jakarta Barat', '2', '0.00', '19500', '0', '0', '0', '0', '0', '2000', '0', '21500', '15000', '1500', '0', '2000', '1500', '0', '1', '27', '2018-04-19 06:04:13', 'reslim', '2018-04-20 03:31:23', 'reslim', '2018-04-20 03:31:23');
INSERT INTO `transaction_waybill` VALUES ('CGS3781437160', 'cgs', 'cgk', '', 'Ratno', '', 'Jakarta', '12345', '', '', '', 'Endang', '', 'Jakarta Selatan', '0123', '', '2', '', 'surat undangan', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"1\",\"volume\":\"0.00\",\"total\":\"1\"}]', '3', '0', '1.00', '1.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '47', '2018-05-01 14:44:33', 'reslim', '2018-05-04 15:17:39', 'reslim', '2018-05-04 15:17:39');
INSERT INTO `transaction_waybill` VALUES ('CGS3881934264', 'cgs', 'cgk', '', 'Tika Amelia', '', 'Jl. Kramat jati kampung tengah', '083807409333', '', '', '', 'Aziz alfian', '', 'Jl. Klender Jakarta timur', '083806075400', '', '2', 'Segera Diantar', 'Up. To Bpk. Aziz ', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"2\",\"volume\":\"0.00\",\"total\":\"2\"}]', '1', '0', '2.00', '2.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '29', '2018-04-25 01:33:49', 'reslim', null, null, '2018-04-25 01:33:49');
INSERT INTO `transaction_waybill` VALUES ('CGS3970334028', 'cgs', 'cgk', '', '4', '', '4', '4', '', '', '', '4', '', '4', '4', '', '2', '', '4', '[{\"no\":\"1\",\"length\":\"0\",\"width\":\"0\",\"height\":\"0\",\"actual\":\"4\",\"volume\":\"0.00\",\"total\":\"4\"}]', '1', '0', '4.00', '4.00', 'Jakarta', 'Jakarta Barat', '2', '0.00', '15000', '0', '0', '0', '2000', '0', '0', '0', '15000', '15000', '1500', '5', '2000', '1500', '6', '1', '47', '2018-04-24 08:37:15', 'reslim', '2018-04-30 06:17:30', 'reslim', '2018-04-30 06:17:30');

-- ----------------------------
-- Table structure for user_api
-- ----------------------------
DROP TABLE IF EXISTS `user_api`;
CREATE TABLE `user_api` (
  `Domain` varchar(50) NOT NULL,
  `ApiKey` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Domain`),
  KEY `Domain` (`Domain`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `ApiKey` (`ApiKey`),
  CONSTRAINT `user_api_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_api_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_api
-- ----------------------------
INSERT INTO `user_api` VALUES ('abc', '138QClqUNWaDI5qIfI5aTIDSW7XZzBp0G', '1', '2018-03-02 12:52:16', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('admin', 'hUHAE8ql4vPrlcQpM4kL1S4WtIFEcRJjgKS', '1', '2018-03-06 01:17:02', 'xsilent', '2018-03-19 12:54:28', 'reslim');
INSERT INTO `user_api` VALUES ('cap-express.co.id', 'unAULmOob99TZfA9n7TCFMJGFC5F6XFqA5obZdWOSa2qPZNoO8h', '1', '2018-05-04 16:34:59', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('http://localhost:1337', '2pHslKjfVdHiJAf0cFRfNq5oZXBJRjHOdOQMifccm9GK3kq0xJ5sQygz9', '1', '2018-03-14 11:52:13', 'reslim', '2018-05-04 16:34:35', 'reslim');
INSERT INTO `user_api` VALUES ('localhost', '1vvyhfz3RtubHk4qWstEBFiOmO1Ct4CeVHdC9jBYv', '1', '2018-03-01 15:40:13', 'reslim', '2018-03-02 11:21:17', 'reslim');
INSERT INTO `user_api` VALUES ('tester1', '5T1heI1MCaFkmjp8xYSad5FDUE9Vi0BTRHzi72', '1', '2018-03-02 11:21:34', 'reslim', '2018-03-02 11:24:18', 'reslim');
INSERT INTO `user_api` VALUES ('tester10', 'ojbhaJNmJBEjRRaRba1QPBtB2iNDlokvBI5HaZb', '1', '2018-03-02 11:23:11', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester11', 'ojbhaJNmJBGKGNymo2dHav99X4ewWVnh83vYfbx', '1', '2018-03-02 11:23:27', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester12', 'ojbhaJNmJBJbvJVRAUpxvoOIRPFqysq2EoWfjnK', '1', '2018-03-02 11:23:34', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester2', '5T1heI1MCd69iGUlqaIv6LeyG53wP3nqd7Qmjg', '42', '2018-03-02 11:21:42', 'reslim', '2018-03-02 11:22:07', 'reslim');
INSERT INTO `user_api` VALUES ('tester3', '5T1heI1MCfwYf4pyimyQ0qNtrvX8m68Wyy7qrv', '1', '2018-03-02 11:21:49', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester4', '5T1heI1MChXNbrULaypaU6mocWQJT8UsTZwT5O', '1', '2018-03-02 11:22:44', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester5', '5T1heI1MCkoC7PpY2KfvNLViYnKlqbFZfpNXi1', '1', '2018-03-02 11:22:51', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester6', '5T1heI1MCmPr4cVaUW5QHrudJODWXervAQ51qe', '1', '2018-03-02 11:22:56', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester8', '5T1heI1MCrH4WXVAFjMwuMC3gGra1jYyhHLxS3', '1', '2018-03-02 11:23:03', 'reslim', null, null);
INSERT INTO `user_api` VALUES ('tester9', '5T1heI1MCu7TTlqNxvCRosaY27kLymK4D82C0f', '1', '2018-03-02 11:23:07', 'reslim', null, null);

-- ----------------------------
-- Table structure for user_auth
-- ----------------------------
DROP TABLE IF EXISTS `user_auth`;
CREATE TABLE `user_auth` (
  `Username` varchar(50) NOT NULL,
  `RS_Token` varchar(255) NOT NULL,
  `Created` datetime NOT NULL,
  `Expired` datetime NOT NULL,
  PRIMARY KEY (`Username`,`RS_Token`),
  KEY `token` (`Username`,`RS_Token`,`Expired`) USING BTREE,
  CONSTRAINT `user_token` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_auth
-- ----------------------------

-- ----------------------------
-- Table structure for user_data
-- ----------------------------
DROP TABLE IF EXISTS `user_data`;
CREATE TABLE `user_data` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fullname` varchar(50) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Aboutme` varchar(255) DEFAULT NULL,
  `Avatar` text,
  `BranchID` varchar(7) DEFAULT NULL,
  `RoleID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`UserID`,`Username`),
  KEY `user_data_ibfk_1` (`StatusID`),
  KEY `user_data_ibfk_2` (`RoleID`),
  KEY `Username` (`Username`),
  KEY `Fullname` (`Fullname`) USING BTREE,
  KEY `Password` (`Password`),
  KEY `Email` (`Email`),
  KEY `BranchID` (`BranchID`) USING BTREE,
  CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_data_ibfk_2` FOREIGN KEY (`RoleID`) REFERENCES `user_role` (`RoleID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_data
-- ----------------------------
INSERT INTO `user_data` VALUES ('1', 'reslim', '$2y$11$6fnVCVYeStQ1wlKp1yFlNOUoR8b0JTg6WfAiVWh4lwhK4YpAj8bAe', 'Master', 'INDONESIA', '123456', 'your@yourdomain.com', 'Master of reSlim Project', 'https://avatarfiles.alphacoders.com/500/50024.jpg', null, '1', '1', '2016-12-28 20:17:12', '2018-05-04 05:31:29');
INSERT INTO `user_data` VALUES ('2', 'xsilent', '$2y$08$pKjKHBAIfz9k725TXD4zW.kRrEV5GfFisWEe5ExQa.cKDcoDmvy12', 'xsilent', '', '', 'aalfiann@gmail.com', '', '', null, '6', '1', '2018-02-22 07:16:37', '2018-07-06 16:46:43');
INSERT INTO `user_data` VALUES ('4', 'tester2', '$2y$11$uVjUCW/SBJVxUAz4S2EGHupgvjSMqHGynIZL5XdIZNIKwjROQ8xV6', 'tester 2', '', '', 'a@b.co', '', '', null, '2', '1', '2018-02-27 12:47:13', '2018-03-09 15:16:52');
INSERT INTO `user_data` VALUES ('5', 'tester3', '$2y$11$3ranIRNC0wY3uEsTnkknX.nscobYlSF5rdNNyWYdHEJjrOko8U1Iq', 'tester3', '', '', 'a@b.co.id', '', '', null, '3', '1', '2018-02-27 12:48:36', null);
INSERT INTO `user_data` VALUES ('6', 'tester4', '$2y$11$1NyERRF8YfolrHO6ZUSso.n0mr54snkb8UMkH/5RVO.9YXfc5vSu.', 'tester4', '', '', 'a@b.co.nr', '', '', null, '3', '1', '2018-02-27 12:49:09', null);
INSERT INTO `user_data` VALUES ('7', 'tester5', '$2y$11$JwSWjuA2p69capcz8R/MLewdXnl50xFowrQ50ZuOLuiswqVYKibJG', 'tester5', '', '', 'a@b.co.uk', '', '', null, '3', '1', '2018-02-27 12:49:42', null);
INSERT INTO `user_data` VALUES ('8', 'tester6', '$2y$11$Yls6KDLSpFnLqIHiItM1j.R82BgITFgHHqgGHtq5Vs303nI3w0ukC', 'tester6', '', '', 'a@b.co.sg', '', '', null, '3', '1', '2018-02-27 12:50:42', null);
INSERT INTO `user_data` VALUES ('9', 'xsilents', '$2y$11$SNQfYDBdJEAfxK6MxyRcR.YjGJ1sNJtzYefDcB3AtZRUR79NyVmsa', 'xsilents', '', '', 'aalfianns@gmail.com', '', '', null, '3', '1', '2018-03-01 01:30:53', null);
INSERT INTO `user_data` VALUES ('10', 'tester7', '$2y$11$xyH9i7fJHF6tNs4lPjTbWuPkuoI3GdzEWBfBZNF5tTXBPqsWHIdW6', 'tester7', '', '', 'a@7.com', '', '', null, '3', '1', '2018-03-01 01:36:35', null);
INSERT INTO `user_data` VALUES ('11', 'tester8', '$2y$11$tUJRuOZFdvAPio8ljwgl.eQ613mYnGmXDdPZgOVp6jyt0fl23F7Ma', 'tester8', '', '', 'a@8.com', '', '', null, '3', '1', '2018-03-01 01:36:57', null);
INSERT INTO `user_data` VALUES ('12', 'tester9', '$2y$11$CsJoU1pfzpS9sOz5lCD8V.wauFtxn44PAFs5UBcn3WWgf7Ha5WLNa', 'tester9', '', '', 'a@9.com', '', '', null, '3', '1', '2018-03-01 01:37:10', null);
INSERT INTO `user_data` VALUES ('13', 'tester10', '$2y$11$J8ZmmrFD4BC83hpVTI.BT.PePax9zCZYuKbFfxZhATHi0mkyaPSq2', 'tester10', '', '', 'a@10.com', '', '', null, '3', '1', '2018-03-01 01:37:39', null);
INSERT INTO `user_data` VALUES ('14', 'tester11', '$2y$11$81adhTB3VpTTd0YUdZezB..pH8YPoj3u6xSyLzjrHVTaABKaGrQGK', 'tester11', '', '', 'a@11.com', 'abc', '', null, '3', '1', '2018-03-01 01:38:15', '2018-03-10 14:22:47');
INSERT INTO `user_data` VALUES ('15', 'tester12', '$2y$11$FM0pb/NoCaVlc2jVBmioW.UmYH9f/mOeotPrM4bocCKXPf8E8.Hne', 'tester12', '', '', 'a@12.com', '', '', null, '3', '1', '2018-03-01 01:41:20', null);
INSERT INTO `user_data` VALUES ('16', 'tester13', '$2y$11$zmnajL171kxOhuNbIxkgQuBwHdUgBo1AYAOKNfS.zfDjdnupQ61ti', 'tester13', '', '', 'a@13.com', '', '', null, '2', '1', '2018-03-01 01:42:54', null);
INSERT INTO `user_data` VALUES ('17', 'xxx', '$2y$11$FF4vu9FKYZd/K4KUc04fvOdj56xMQYH49SB8IjJjYDF0l/nxy4MTS', 'xxx', '', '', 'xxx@x.com', '', '', null, '3', '1', '2018-03-06 23:26:27', null);
INSERT INTO `user_data` VALUES ('18', 'shans', '$2y$11$jbRRmlj04p2fPRZcxVkleeHPMtbMRNGNZiNbbloktdVU7aAWA1KCO', 'shans', '', '', 'allfiann@gmail.co.id', '', '', null, '5', '1', '2018-03-21 00:04:58', null);
INSERT INTO `user_data` VALUES ('19', 'shantika', '$2y$11$W./SbCjGY6URpMxjXOkRyua8cd7FR3DOB9BEPKSZL2U2jDN0y0pGC', 'shantika', '', '', 'shantika@gmail.com', '', '', null, '5', '42', '2018-03-21 00:11:50', '2018-07-27 13:26:40');
INSERT INTO `user_data` VALUES ('20', 'alfian', '$2y$08$oFXEu0WSe4P0q7f/Ja8joeyaVdUTZEfLyqpoIbKgDOsWUmdYOe0Se', 'alfian', '', '', 'a@b.com', '', '', null, '9', '1', '2018-07-06 16:45:18', '2018-07-09 01:47:56');
INSERT INTO `user_data` VALUES ('21', 'reslim2', '$2y$08$jBFPsB3F2dC4qbFUb79GfeVTfvS4lfIRjutMk2kSsUH85u0dXpp6.', 'reslim2', '', '', 'b@b.com', '', '', null, '1', '1', '2018-07-23 13:56:49', null);

-- ----------------------------
-- Table structure for user_forgot
-- ----------------------------
DROP TABLE IF EXISTS `user_forgot`;
CREATE TABLE `user_forgot` (
  `Email` varchar(50) NOT NULL,
  `Verifylink` varchar(255) NOT NULL,
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `Expired` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Email`,`Verifylink`),
  KEY `Email` (`Email`),
  KEY `Verifylink` (`Verifylink`),
  CONSTRAINT `user_forgot_ibfk_1` FOREIGN KEY (`Email`) REFERENCES `user_data` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_forgot
-- ----------------------------
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFCw6ZryT0SAdMTrJjb', '2018-07-06 16:46:43', '2018-07-06 16:46:43');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFucUTZPFqaqrUbLRL6', '2018-02-23 02:06:11', '2018-02-23 02:06:11');
INSERT INTO `user_forgot` VALUES ('aalfiann@gmail.com', '1YUU1YauKcoZW1lHNEuIpmRaBGFOrdIA6IsFucUTZPFqaqrUgjs6J', '2018-02-23 01:45:49', '2018-02-26 01:45:49');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `RoleID` int(11) NOT NULL AUTO_INCREMENT,
  `Role` varchar(255) NOT NULL,
  PRIMARY KEY (`RoleID`),
  KEY `ID` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', 'superuser');
INSERT INTO `user_role` VALUES ('2', 'admin');
INSERT INTO `user_role` VALUES ('3', 'member');
INSERT INTO `user_role` VALUES ('4', 'developer');
INSERT INTO `user_role` VALUES ('5', 'applicant');
INSERT INTO `user_role` VALUES ('6', 'master');
INSERT INTO `user_role` VALUES ('7', 'standart');
INSERT INTO `user_role` VALUES ('8', 'customer');
INSERT INTO `user_role` VALUES ('9', 'Agent');

-- ----------------------------
-- Table structure for user_upload
-- ----------------------------
DROP TABLE IF EXISTS `user_upload`;
CREATE TABLE `user_upload` (
  `ItemID` int(11) NOT NULL AUTO_INCREMENT,
  `Date_Upload` datetime NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Alternate` varchar(255) DEFAULT NULL,
  `External_link` varchar(255) DEFAULT NULL,
  `Filename` varchar(255) NOT NULL,
  `Filepath` varchar(255) NOT NULL,
  `Filetype` varchar(255) NOT NULL,
  `Filesize` double NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  PRIMARY KEY (`ItemID`),
  KEY `ItemID` (`ItemID`),
  KEY `Date_Upload` (`Date_Upload`),
  KEY `Filename` (`Filename`),
  KEY `Filetype` (`Filetype`),
  KEY `Username` (`Username`) USING BTREE,
  KEY `StatusID` (`StatusID`) USING BTREE,
  CONSTRAINT `user_upload_ibfk_1` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_upload_ibfk_2` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_upload
-- ----------------------------
INSERT INTO `user_upload` VALUES ('1', '2018-03-05 03:13:40', 'test', 'test', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('2', '2018-03-05 03:19:08', 'test', 'test', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('3', '2018-03-05 03:22:04', 'test', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('4', '2018-03-05 03:23:45', 'test', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('5', '2018-03-05 03:24:18', 'aaa', 'aaa', '', 'Invoice-27408.pdf', 'upload/03-2018/Invoice-27408.pdf', 'application/pdf', '30214', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('6', '2018-03-05 03:24:25', 'aaa', 'aaa', '', 'Invoice-27408.pdf', 'upload/03-2018/Invoice-27408.pdf', 'application/pdf', '30214', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('7', '2018-03-05 03:30:44', 'aaa', 'aaa', '', 'Invoice-27408.pdf', 'upload/03-2018/Invoice-27408.pdf', 'application/pdf', '30214', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('8', '2018-03-05 03:31:06', 'bbb', '', '', 'Invoice-27408.pdf', 'upload/03-2018/Invoice-27408.pdf', 'application/pdf', '30214', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('10', '2018-03-05 03:32:34', 'ccc', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('11', '2018-03-05 03:32:48', 'ccc', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('12', '2018-03-05 03:35:08', 'asdasdasd', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('13', '2018-03-05 03:36:49', 'aaaa', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('14', '2018-03-05 03:37:09', 'bbbb', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('15', '2018-03-05 03:37:18', 'bbbb', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('16', '2018-03-05 03:39:56', 'bbbb', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('17', '2018-03-05 03:40:17', 'qqq', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('18', '2018-03-05 03:40:26', 'qqq', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('19', '2018-03-05 03:44:12', 'qqq', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('21', '2018-03-05 03:52:02', 'ttt', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('22', '2018-03-05 03:52:08', 'ttt', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('23', '2018-03-05 03:59:49', 'zzz', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('24', '2018-03-05 04:03:39', 'gggg', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('25', '2018-03-05 04:04:03', 'avcscs', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('26', '2018-03-05 04:13:44', 'asdasdasdasdasd', '', '', 'Invoice-27434.pdf', 'upload/03-2018/Invoice-27434.pdf', 'application/pdf', '29998', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('27', '2018-03-05 04:15:16', 'asd', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('28', '2018-03-05 04:15:51', 'aaaaaaaaaaaaaaaaaaaaa', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('29', '2018-03-05 04:16:06', 'bbbbbbbbbbbb', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('30', '2018-03-05 04:18:43', 'ccccccccccccc', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('31', '2018-03-05 04:24:40', 'ddddddddddddd', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('32', '2018-03-05 04:31:53', 'ffffffffffffffffffff', '', '', 'Invoice-27483.pdf', 'upload/03-2018/Invoice-27483.pdf', 'application/pdf', '30222', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('37', '2018-03-05 06:14:47', 'Endgame (2015)', '', '', '15220_4530780640936_2129982770_n.jpg', 'upload/03-2018/15220_4530780640936_2129982770_n.jpg', 'image/jpeg', '53032', 'reslim', '2018-03-06 00:41:47', 'reslim', '50');
INSERT INTO `user_upload` VALUES ('38', '2018-03-05 06:23:34', 'Endgame (2015)', '', '', '16065_4547799746403_1162326722_n.jpg', 'upload/03-2018/16065_4547799746403_1162326722_n.jpg', 'image/jpeg', '82849', 'reslim', '2018-03-06 03:29:41', 'reslim', '50');
INSERT INTO `user_upload` VALUES ('39', '2018-03-06 14:32:59', 'apartemen', 'apartemen', '', '68452_4530331749714_380416327_n.jpg', 'upload/03-2018/68452_4530331749714_380416327_n.jpg', 'image/jpeg', '50272', 'xsilent', '2018-03-19 04:17:59', 'xsilent', '49');
INSERT INTO `user_upload` VALUES ('40', '2018-03-12 02:06:27', 'apartemen', 'apartemen', '', 'Film-Apartmen-2015.jpg', 'upload/03-2018/Film-Apartmen-2015.jpg', 'image/jpeg', '84928', 'reslim', '2018-03-19 03:12:56', 'reslim', '49');
INSERT INTO `user_upload` VALUES ('41', '2018-04-02 03:07:41', 'In The Shadow of Women 2', 'In The Shadow of Women 2', '', 'film-in-the-shadow-of-women-2015.jpg', 'upload/04-2018/film-in-the-shadow-of-women-2015.jpg', 'image/jpeg', '17226', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('42', '2018-05-04 05:33:05', 'Film Massan', 'asd', '', 'film-masaan-fly-away-solo-2015.jpg', 'upload/05-2018/film-masaan-fly-away-solo-2015.jpg', 'image/jpeg', '14444', 'reslim', '2018-07-12 15:57:21', 'reslim', '49');
INSERT INTO `user_upload` VALUES ('43', '2018-07-12 15:58:03', 'asdsdsd', 'asdasd', '', 'logo-bank-bni.png', 'upload/07-2018/logo-bank-bni.png', 'image/png', '10180', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('44', '2018-07-12 16:32:26', 'asdasd', '', '', '1044_4530339749914_1356376084_n.jpg', 'upload/07-2018/1044_4530339749914_1356376084_n.jpg', 'image/jpeg', '14630', 'reslim', null, null, '49');
INSERT INTO `user_upload` VALUES ('45', '2018-07-12 16:41:47', 'asdasdasd', '', '', '68452_4530331749714_380416327_n.jpg', 'upload/07-2018/68452_4530331749714_380416327_n.jpg', 'image/jpeg', '50272', 'reslim', null, null, '49');

-- ----------------------------
-- Event structure for delete_all_expired_auth
-- ----------------------------
DROP EVENT IF EXISTS `delete_all_expired_auth`;
DELIMITER ;;
CREATE DEFINER=`cap_dev`@`%` EVENT `delete_all_expired_auth` ON SCHEDULE EVERY 1 DAY STARTS '2018-02-19 18:56:44' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM user_auth WHERE DATE_ADD(Expired,INTERVAL 7 DAY) < CURRENT_TIMESTAMP
;;
DELIMITER ;
SET FOREIGN_KEY_CHECKS=1;
