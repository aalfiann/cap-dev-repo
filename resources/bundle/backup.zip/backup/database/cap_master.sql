/*
Navicat MariaDB Data Transfer

Source Server         : CAP-EXPRESS
Source Server Version : 100131
Source Host           : server.cap-express.co.id:3306
Source Database       : cap_master

Target Server Type    : MariaDB
Target Server Version : 100131
File Encoding         : 65001

Date: 2019-01-14 03:11:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for core_status
-- ----------------------------
DROP TABLE IF EXISTS `core_status`;
CREATE TABLE `core_status` (
  `StatusID` int(11) NOT NULL AUTO_INCREMENT,
  `Status` varchar(255) NOT NULL,
  PRIMARY KEY (`StatusID`),
  KEY `StatusID` (`StatusID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of core_status
-- ----------------------------
INSERT INTO `core_status` VALUES ('1', 'active');
INSERT INTO `core_status` VALUES ('2', 'allocated');
INSERT INTO `core_status` VALUES ('3', 'approved');
INSERT INTO `core_status` VALUES ('4', 'authorized');
INSERT INTO `core_status` VALUES ('5', 'banned');
INSERT INTO `core_status` VALUES ('6', 'blank');
INSERT INTO `core_status` VALUES ('7', 'canceled');
INSERT INTO `core_status` VALUES ('8', 'checked');
INSERT INTO `core_status` VALUES ('9', 'closed');
INSERT INTO `core_status` VALUES ('10', 'commented');
INSERT INTO `core_status` VALUES ('11', 'compared');
INSERT INTO `core_status` VALUES ('12', 'deleted');
INSERT INTO `core_status` VALUES ('13', 'disabled');
INSERT INTO `core_status` VALUES ('14', 'downloaded');
INSERT INTO `core_status` VALUES ('15', 'edited');
INSERT INTO `core_status` VALUES ('16', 'enabled');
INSERT INTO `core_status` VALUES ('17', 'error');
INSERT INTO `core_status` VALUES ('18', 'expired');
INSERT INTO `core_status` VALUES ('19', 'failed');
INSERT INTO `core_status` VALUES ('20', 'hidden');
INSERT INTO `core_status` VALUES ('21', 'installed');
INSERT INTO `core_status` VALUES ('22', 'listed');
INSERT INTO `core_status` VALUES ('23', 'locked');
INSERT INTO `core_status` VALUES ('24', 'maintenance');
INSERT INTO `core_status` VALUES ('25', 'merged');
INSERT INTO `core_status` VALUES ('26', 'moved');
INSERT INTO `core_status` VALUES ('27', 'ok');
INSERT INTO `core_status` VALUES ('28', 'on hold');
INSERT INTO `core_status` VALUES ('29', 'on process');
INSERT INTO `core_status` VALUES ('30', 'on request');
INSERT INTO `core_status` VALUES ('31', 'open');
INSERT INTO `core_status` VALUES ('32', 'outstanding');
INSERT INTO `core_status` VALUES ('33', 'overdue');
INSERT INTO `core_status` VALUES ('34', 'paid');
INSERT INTO `core_status` VALUES ('35', 'pending');
INSERT INTO `core_status` VALUES ('36', 'registered');
INSERT INTO `core_status` VALUES ('37', 'rejected');
INSERT INTO `core_status` VALUES ('38', 'removed');
INSERT INTO `core_status` VALUES ('39', 'signed');
INSERT INTO `core_status` VALUES ('40', 'stopped');
INSERT INTO `core_status` VALUES ('41', 'success');
INSERT INTO `core_status` VALUES ('42', 'suspended');
INSERT INTO `core_status` VALUES ('43', 'unauthorized');
INSERT INTO `core_status` VALUES ('44', 'unknown');
INSERT INTO `core_status` VALUES ('45', 'uploaded');
INSERT INTO `core_status` VALUES ('46', 'viewed');
INSERT INTO `core_status` VALUES ('47', 'void');
INSERT INTO `core_status` VALUES ('48', 'waiting');
INSERT INTO `core_status` VALUES ('49', 'public');
INSERT INTO `core_status` VALUES ('50', 'private');
INSERT INTO `core_status` VALUES ('51', 'publish');
INSERT INTO `core_status` VALUES ('52', 'draft');
INSERT INTO `core_status` VALUES ('53', 'return');

-- ----------------------------
-- Table structure for data_page
-- ----------------------------
DROP TABLE IF EXISTS `data_page`;
CREATE TABLE `data_page` (
  `PageID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Content` text NOT NULL,
  `Tags` varchar(500) DEFAULT NULL,
  `Viewer` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Created_at` datetime NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Last_updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PageID`),
  KEY `PageID` (`PageID`),
  KEY `Title` (`Title`),
  KEY `Tags` (`Tags`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `Created_at` (`Created_at`),
  CONSTRAINT `data_page_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `data_page_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of data_page
-- ----------------------------

-- ----------------------------
-- Table structure for log_data
-- ----------------------------
DROP TABLE IF EXISTS `log_data`;
CREATE TABLE `log_data` (
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Username` varchar(50) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data
-- ----------------------------

-- ----------------------------
-- Table structure for log_data_pod
-- ----------------------------
DROP TABLE IF EXISTS `log_data_pod`;
CREATE TABLE `log_data_pod` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `BranchID` varchar(10) DEFAULT NULL,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `WayBill` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Recipient` varchar(50) DEFAULT NULL,
  `Relation` varchar(255) DEFAULT NULL,
  `DeliveryID` varchar(15) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `ItemID` (`ItemID`),
  KEY `WayBill` (`WayBill`) USING BTREE,
  KEY `BranchID` (`BranchID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_pod
-- ----------------------------

-- ----------------------------
-- Table structure for log_data_void
-- ----------------------------
DROP TABLE IF EXISTS `log_data_void`;
CREATE TABLE `log_data_void` (
  `ItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `CodeID` varchar(50) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ItemID`),
  KEY `StatusID` (`StatusID`),
  KEY `CodeID` (`CodeID`) USING BTREE,
  KEY `ItemID` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of log_data_void
-- ----------------------------

-- ----------------------------
-- Table structure for mas_insurance
-- ----------------------------
DROP TABLE IF EXISTS `mas_insurance`;
CREATE TABLE `mas_insurance` (
  `InsuranceID` int(11) NOT NULL AUTO_INCREMENT,
  `Insurance` varchar(255) NOT NULL,
  `Premium` decimal(10,0) NOT NULL,
  `Min_Premium` decimal(10,0) NOT NULL,
  PRIMARY KEY (`InsuranceID`),
  KEY `InsuranceID` (`InsuranceID`),
  KEY `Insurance` (`Insurance`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_insurance
-- ----------------------------

-- ----------------------------
-- Table structure for mas_mode
-- ----------------------------
DROP TABLE IF EXISTS `mas_mode`;
CREATE TABLE `mas_mode` (
  `ModeID` int(11) NOT NULL AUTO_INCREMENT,
  `Mode` varchar(20) NOT NULL,
  PRIMARY KEY (`ModeID`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_mode
-- ----------------------------
INSERT INTO `mas_mode` VALUES ('1', 'Air Freight');
INSERT INTO `mas_mode` VALUES ('2', 'Road Freight');
INSERT INTO `mas_mode` VALUES ('3', 'Sea Freight');

-- ----------------------------
-- Table structure for mas_payment
-- ----------------------------
DROP TABLE IF EXISTS `mas_payment`;
CREATE TABLE `mas_payment` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `Payment` varchar(50) NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `PaymentID` (`PaymentID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_payment
-- ----------------------------
INSERT INTO `mas_payment` VALUES ('1', 'Cash');
INSERT INTO `mas_payment` VALUES ('2', 'Cheque');
INSERT INTO `mas_payment` VALUES ('3', 'Cod');
INSERT INTO `mas_payment` VALUES ('4', 'Credit');
INSERT INTO `mas_payment` VALUES ('5', 'Transfer Bank');
INSERT INTO `mas_payment` VALUES ('6', 'Transfer Form');

-- ----------------------------
-- Table structure for mas_relation
-- ----------------------------
DROP TABLE IF EXISTS `mas_relation`;
CREATE TABLE `mas_relation` (
  `RelationID` int(11) NOT NULL AUTO_INCREMENT,
  `Relation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`RelationID`),
  KEY `RelationID` (`RelationID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of mas_relation
-- ----------------------------

-- ----------------------------
-- Table structure for sys_company
-- ----------------------------
DROP TABLE IF EXISTS `sys_company`;
CREATE TABLE `sys_company` (
  `BranchID` varchar(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) NOT NULL,
  `Fax` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Owner` varchar(50) DEFAULT NULL,
  `PIC` varchar(50) DEFAULT NULL,
  `TIN` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BranchID`),
  KEY `BranchID` (`BranchID`),
  KEY `StatusID` (`StatusID`),
  KEY `Name` (`Name`),
  KEY `Phone` (`Phone`),
  KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_company
-- ----------------------------

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `Username` varchar(50) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sys_user
-- ----------------------------

-- ----------------------------
-- Table structure for tariff_data
-- ----------------------------
DROP TABLE IF EXISTS `tariff_data`;
CREATE TABLE `tariff_data` (
  `BranchID` varchar(10) NOT NULL,
  `Kabupaten` varchar(255) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  `Estimasi` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`BranchID`,`Kabupaten`,`ModeID`),
  KEY `BranchID` (`BranchID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_data
-- ----------------------------

-- ----------------------------
-- Table structure for tariff_handling
-- ----------------------------
DROP TABLE IF EXISTS `tariff_handling`;
CREATE TABLE `tariff_handling` (
  `Kabupaten` varchar(50) NOT NULL,
  `ModeID` int(11) NOT NULL,
  `KGP` decimal(10,0) NOT NULL,
  `KGS` decimal(10,0) NOT NULL,
  `Min_Kg` decimal(5,0) NOT NULL,
  PRIMARY KEY (`Kabupaten`,`ModeID`),
  KEY `Kabupaten` (`Kabupaten`),
  KEY `ModeID` (`ModeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of tariff_handling
-- ----------------------------

-- ----------------------------
-- Table structure for transaction_waybill
-- ----------------------------
DROP TABLE IF EXISTS `transaction_waybill`;
CREATE TABLE `transaction_waybill` (
  `Waybill` varchar(20) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `DestID` varchar(10) NOT NULL,
  `CustomerID` varchar(20) DEFAULT NULL,
  `Consignor_name` varchar(50) NOT NULL,
  `Consignor_alias` varchar(50) DEFAULT NULL,
  `Consignor_address` varchar(255) NOT NULL,
  `Consignor_phone` varchar(15) NOT NULL,
  `Consignor_fax` varchar(15) DEFAULT NULL,
  `Consignor_email` varchar(50) DEFAULT NULL,
  `ReferenceID` varchar(20) DEFAULT NULL,
  `Consignee_name` varchar(50) NOT NULL,
  `Consignee_attention` varchar(50) DEFAULT NULL,
  `Consignee_address` varchar(255) NOT NULL,
  `Consignee_phone` varchar(15) NOT NULL,
  `Consignee_fax` varchar(15) DEFAULT NULL,
  `ModeID` int(11) NOT NULL,
  `Instruction` varchar(255) DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Goods_data` varchar(1000) NOT NULL,
  `Goods_koli` decimal(5,0) NOT NULL,
  `Goods_value` decimal(10,0) NOT NULL,
  `Weight` decimal(7,2) NOT NULL,
  `Weight_real` decimal(7,2) NOT NULL,
  `Origin` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Estimation` varchar(7) NOT NULL,
  `Insurance_rate` decimal(7,2) NOT NULL,
  `Shipping_cost` decimal(10,0) NOT NULL,
  `Shipping_insurance` decimal(10,0) NOT NULL,
  `Shipping_packing` decimal(10,0) NOT NULL,
  `Shipping_forward` decimal(10,0) NOT NULL,
  `Shipping_handling` decimal(10,0) NOT NULL,
  `Shipping_surcharge` decimal(10,0) NOT NULL,
  `Shipping_admin` decimal(10,0) NOT NULL,
  `Shipping_discount` decimal(10,0) NOT NULL,
  `Shipping_cost_total` decimal(10,0) NOT NULL,
  `Tariff_kgp` decimal(10,0) NOT NULL,
  `Tariff_kgs` decimal(10,0) NOT NULL,
  `Tariff_kgp_min` decimal(4,0) NOT NULL,
  `Tariff_hkgp` decimal(10,0) NOT NULL,
  `Tariff_hkgs` decimal(10,0) NOT NULL,
  `Tariff_hkgp_min` decimal(4,0) NOT NULL,
  `PaymentID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Created_by` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL,
  `Updated_by` varchar(50) DEFAULT NULL,
  `Updated_sys` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Waybill`),
  KEY `Waybill` (`Waybill`),
  KEY `CustomerID` (`CustomerID`),
  KEY `Consignor_name` (`Consignor_name`),
  KEY `Consignor_phone` (`Consignor_phone`),
  KEY `ReferenceID` (`ReferenceID`),
  KEY `Consignee_name` (`Consignee_name`),
  KEY `Consignee_phone` (`Consignee_phone`),
  KEY `ModeID` (`ModeID`),
  KEY `Destination` (`Destination`),
  KEY `PaymentID` (`PaymentID`),
  KEY `StatusID` (`StatusID`),
  KEY `Created_at` (`Created_at`),
  KEY `Created_by` (`Created_by`),
  KEY `BranchID` (`BranchID`),
  KEY `DestID` (`DestID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of transaction_waybill
-- ----------------------------

-- ----------------------------
-- Table structure for user_api
-- ----------------------------
DROP TABLE IF EXISTS `user_api`;
CREATE TABLE `user_api` (
  `Domain` varchar(50) NOT NULL,
  `ApiKey` varchar(255) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Username` varchar(50) NOT NULL,
  `Updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Domain`),
  KEY `Domain` (`Domain`),
  KEY `StatusID` (`StatusID`),
  KEY `Username` (`Username`),
  KEY `ApiKey` (`ApiKey`),
  CONSTRAINT `user_api_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_api_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_api
-- ----------------------------

-- ----------------------------
-- Table structure for user_auth
-- ----------------------------
DROP TABLE IF EXISTS `user_auth`;
CREATE TABLE `user_auth` (
  `Username` varchar(50) NOT NULL,
  `RS_Token` varchar(255) NOT NULL,
  `Created` datetime NOT NULL,
  `Expired` datetime NOT NULL,
  PRIMARY KEY (`Username`,`RS_Token`),
  KEY `token` (`Username`,`RS_Token`,`Expired`) USING BTREE,
  CONSTRAINT `user_token` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_auth
-- ----------------------------

-- ----------------------------
-- Table structure for user_data
-- ----------------------------
DROP TABLE IF EXISTS `user_data`;
CREATE TABLE `user_data` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Fullname` varchar(50) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Aboutme` varchar(255) DEFAULT NULL,
  `Avatar` text,
  `BranchID` varchar(7) DEFAULT NULL,
  `RoleID` int(11) NOT NULL,
  `StatusID` int(11) NOT NULL,
  `Created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`UserID`,`Username`),
  KEY `user_data_ibfk_1` (`StatusID`),
  KEY `user_data_ibfk_2` (`RoleID`),
  KEY `Username` (`Username`),
  KEY `Fullname` (`Fullname`) USING BTREE,
  KEY `Password` (`Password`),
  KEY `Email` (`Email`),
  KEY `BranchID` (`BranchID`) USING BTREE,
  CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_data_ibfk_2` FOREIGN KEY (`RoleID`) REFERENCES `user_role` (`RoleID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_data
-- ----------------------------
INSERT INTO `user_data` VALUES ('1', 'reslim', '$2y$11$D9ZWJOhKvLoor7RyUA70hOVzbwJ9RA.nk909QLENotxq26F6k/Qxu', 'Master', 'INDONESIA', '12345', 'your@yourdomain.com', 'Master of reSlim Project', '', null, '1', '1', '2016-12-28 20:17:12', '2016-12-28 20:17:38');

-- ----------------------------
-- Table structure for user_forgot
-- ----------------------------
DROP TABLE IF EXISTS `user_forgot`;
CREATE TABLE `user_forgot` (
  `Email` varchar(50) NOT NULL,
  `Verifylink` varchar(255) NOT NULL,
  `Created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `Expired` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Email`,`Verifylink`),
  KEY `Email` (`Email`),
  KEY `Verifylink` (`Verifylink`),
  CONSTRAINT `user_forgot_ibfk_1` FOREIGN KEY (`Email`) REFERENCES `user_data` (`Email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_forgot
-- ----------------------------

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `RoleID` int(11) NOT NULL AUTO_INCREMENT,
  `Role` varchar(255) NOT NULL,
  PRIMARY KEY (`RoleID`),
  KEY `ID` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES ('1', 'superuser');
INSERT INTO `user_role` VALUES ('2', 'admin');
INSERT INTO `user_role` VALUES ('3', 'member');
INSERT INTO `user_role` VALUES ('4', 'developer');
INSERT INTO `user_role` VALUES ('5', 'applicant');
INSERT INTO `user_role` VALUES ('6', 'master');
INSERT INTO `user_role` VALUES ('7', 'standart');
INSERT INTO `user_role` VALUES ('8', 'customer');

-- ----------------------------
-- Table structure for user_upload
-- ----------------------------
DROP TABLE IF EXISTS `user_upload`;
CREATE TABLE `user_upload` (
  `ItemID` int(11) NOT NULL AUTO_INCREMENT,
  `Date_Upload` datetime NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Alternate` varchar(255) DEFAULT NULL,
  `External_link` varchar(255) DEFAULT NULL,
  `Filename` varchar(255) NOT NULL,
  `Filepath` varchar(255) NOT NULL,
  `Filetype` varchar(255) NOT NULL,
  `Filesize` double NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `Updated_by` varchar(50) DEFAULT NULL,
  `StatusID` int(11) NOT NULL,
  PRIMARY KEY (`ItemID`),
  KEY `ItemID` (`ItemID`),
  KEY `Date_Upload` (`Date_Upload`),
  KEY `Filename` (`Filename`),
  KEY `Filetype` (`Filetype`),
  KEY `Username` (`Username`) USING BTREE,
  KEY `StatusID` (`StatusID`) USING BTREE,
  CONSTRAINT `user_upload_ibfk_1` FOREIGN KEY (`Username`) REFERENCES `user_data` (`Username`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_upload_ibfk_2` FOREIGN KEY (`StatusID`) REFERENCES `core_status` (`StatusID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user_upload
-- ----------------------------

-- ----------------------------
-- Event structure for delete_all_expired_auth
-- ----------------------------
DROP EVENT IF EXISTS `delete_all_expired_auth`;
DELIMITER ;;
CREATE DEFINER=`cap_dev`@`%` EVENT `delete_all_expired_auth` ON SCHEDULE EVERY 1 DAY STARTS '2018-02-19 20:18:07' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM user_auth WHERE DATE_ADD(Expired,INTERVAL 7 DAY) < CURRENT_TIMESTAMP
;;
DELIMITER ;
SET FOREIGN_KEY_CHECKS=1;
