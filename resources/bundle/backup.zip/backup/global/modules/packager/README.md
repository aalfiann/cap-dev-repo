### How to Integrate this module into reSlim?

1. Download zip then upload to reSlim server to the **modules/**
2. Extract zip then you will get new folder like **reSlim-modules-packager-master**
3. Rename foldername **reSlim-modules-packager-master** to **packager**
4. Done