### Detail module information

1. Namespace >> **modules/flexibleconfig**
2. Zip Archive source >> 
    https://github.com/aalfiann/reSlim-modules-flexibleconfig/archive/master.zip

### How to Integrate this module into reSlim?

1. Download zip then upload to reSlim server to the **modules/**
2. Extract zip then you will get new folder like **reSlim-modules-flexibleconfig-master**
3. Rename foldername **reSlim-modules-flexibleconfig-master** to **flexibleconfig**
4. Done

### How to Integrate this module into reSlim with Packager?

1. Make AJAX GET request to >>
    http://**{yourdomain.com}**/api/packager/install/zip/safely/**{yourusername}**/**{yourtoken}**/?lang=en&source=**{zip archive source}**&namespace=**{modul namespace}**