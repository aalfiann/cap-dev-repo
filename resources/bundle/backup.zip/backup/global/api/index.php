<?php
require __DIR__.'/../app/app.php';